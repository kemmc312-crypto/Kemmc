package com.gamehelper.resolution.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Autorenew
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gamehelper.resolution.data.AppStore
import com.gamehelper.resolution.data.Presets
import com.gamehelper.resolution.shizuku.ShizukuHelper
import com.gamehelper.resolution.tile.TileHelper
import com.gamehelper.resolution.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(padding: PaddingValues) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val s by AppStore.settings.collectAsStateWithLifecycle()
    val shizuku by ShizukuHelper.status.collectAsStateWithLifecycle()

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            AppStore.updateSettings { it.copy(videoUri = uri.toString(), videoBgEnabled = true) }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 16.dp, end = 16.dp,
            top = padding.calculateTopPadding() + 12.dp,
            bottom = padding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Text("Cài đặt", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }

        // ------------------------------------------------ Thông số gốc
        item {
            GlassCard {
                SectionTitle("Thông số gốc của máy")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField("Default Width", s.defaultWidth, { v -> AppStore.updateSettings { it.copy(defaultWidth = v) } }, Modifier.weight(1f))
                    NumberField("Default Height", s.defaultHeight, { v -> AppStore.updateSettings { it.copy(defaultHeight = v) } }, Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField("Default DPI", s.defaultDpi, { v -> AppStore.updateSettings { it.copy(defaultDpi = v) } }, Modifier.weight(1f))
                    NumberField("Default Hz", s.defaultHz, { v -> AppStore.updateSettings { it.copy(defaultHz = v) } }, Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                FilledTonalButton(
                    enabled = shizuku == ShizukuHelper.Status.READY,
                    onClick = {
                        scope.launch {
                            val ok = detectDeviceDisplay(ctx)
                            ctx.toast(if (ok) "Đã đọc thông số thật của máy" else "Không đọc được thông số", long = !ok)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.Autorenew, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Tự nhận diện từ máy (cần Shizuku)")
                }
                Text(
                    "Hãy bấm nhận diện khi máy đang ở độ phân giải gốc. Đây là mốc để tính tỷ lệ & preset.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }

        // ------------------------------------------------ Tính năng
        item {
            GlassCard {
                SectionTitle("Tính năng")

                SwitchRow(
                    "Resolution Safety Guard",
                    "Không cho cạnh ngắn dưới 250px (giữ nguyên tỷ lệ 16:9, 4:3…) để tránh kẹt màn hình / mất nút lệnh",
                    s.safetyGuard, { v -> AppStore.updateSettings { it.copy(safetyGuard = v) } }
                )
                SwitchRow(
                    "Lock Aspect Ratio",
                    "Khi đổi Width, Height tự tính theo tỷ lệ màn hình gốc",
                    s.lockAspect, { v -> AppStore.updateSettings { it.copy(lockAspect = v) } }
                )
                SwitchRow(
                    "Preset Profiles",
                    "Hiện các mẫu Max Performance / Balanced / Graphic Hub khi sửa game",
                    s.presetsEnabled, { v -> AppStore.updateSettings { it.copy(presetsEnabled = v) } }
                )
                SwitchRow(
                    "Auto-Reset Monitor",
                    "Tự theo dõi khi bạn thoát game rồi khôi phục phân giải gốc (chỉ chạy trong phiên chơi)",
                    s.autoResetMonitor, { v -> AppStore.updateSettings { it.copy(autoResetMonitor = v) } }
                )
                SwitchRow(
                    "Nút nổi 2-trong-1",
                    "Bấm vào để khôi phục hiển thị và force-stop game đang chơi",
                    s.floatingEnabled, { v -> AppStore.updateSettings { it.copy(floatingEnabled = v) } }
                )
                AnimatedVisibility(
                    visible = s.floatingEnabled && !AndroidSettings.canDrawOverlays(ctx),
                    enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()
                ) {
                    OutlinedButton(
                        onClick = {
                            ctx.startActivity(
                                Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Cấp quyền hiển thị trên ứng dụng khác") }
                }
                SwitchRow(
                    "Dọn RAM trước khi vào game",
                    "Dùng am force-stop cho các app đã cài (trừ launcher, bàn phím, Shizuku, Termux, game và danh sách loại trừ)",
                    s.ramCleanEnabled, { v -> AppStore.updateSettings { it.copy(ramCleanEnabled = v) } }
                )
                AnimatedVisibility(
                    visible = s.ramCleanEnabled,
                    enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()
                ) {
                    OutlinedTextField(
                        value = s.ramExclusions,
                        onValueChange = { v -> AppStore.updateSettings { it.copy(ramExclusions = v) } },
                        label = { Text("Package loại trừ (cách nhau bằng dấu phẩy)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(Modifier.height(8.dp))
                NumberField(
                    "Delay mặc định trước khi mở game",
                    s.defaultDelaySec,
                    { v -> AppStore.updateSettings { it.copy(defaultDelaySec = v.coerceAtMost(60)) } },
                    Modifier.fillMaxWidth(), suffix = "giây"
                )
            }
        }

        // ------------------------------------------------ Quick Settings Tile
        item {
            GlassCard {
                SectionTitle("Quick Settings Tile")
                SwitchRow(
                    "Ô “Reset màn hình” trên thanh trạng thái",
                    "Vuốt xuống, chạm một lần là về độ phân giải gốc, không cần mở app",
                    s.tileEnabled,
                    { v ->
                        AppStore.updateSettings { it.copy(tileEnabled = v) }
                        TileHelper.setEnabled(ctx, v)
                    }
                )
                AnimatedVisibility(visible = s.tileEnabled, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                    OutlinedButton(
                        onClick = {
                            if (!TileHelper.requestAdd(ctx)) {
                                ctx.toast("Hãy kéo thanh trạng thái > biểu tượng bút chì > thêm ô “Reset màn hình”", long = true)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Thêm ô vào Cài đặt nhanh") }
                }
            }
        }

        // ------------------------------------------------ Navigation
        item {
            GlassCard {
                SectionTitle("Navigation Mode Switch")
                SwitchRow(
                    "Hiện công cụ chuyển điều hướng",
                    "Chuyển nhanh Cử chỉ ⇄ 3 phím qua Shizuku (hữu ích khi hạ phân giải)",
                    s.navSwitchEnabled, { v -> AppStore.updateSettings { it.copy(navSwitchEnabled = v) } }
                )
                AnimatedVisibility(visible = s.navSwitchEnabled, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            modifier = Modifier.weight(1f),
                            enabled = shizuku == ShizukuHelper.Status.READY,
                            onClick = {
                                scope.launch {
                                    val r = withContext(Dispatchers.IO) { ShizukuHelper.setNavigationMode(gesture = true) }
                                    ctx.toast(if (r.ok) "Đã chuyển sang Cử chỉ" else "Thất bại: ${r.err.ifBlank { r.out }}", long = !r.ok)
                                }
                            }
                        ) { Text("Cử chỉ") }
                        Button(
                            modifier = Modifier.weight(1f),
                            enabled = shizuku == ShizukuHelper.Status.READY,
                            onClick = {
                                scope.launch {
                                    val r = withContext(Dispatchers.IO) { ShizukuHelper.setNavigationMode(gesture = false) }
                                    ctx.toast(if (r.ok) "Đã chuyển sang 3 phím" else "Thất bại: ${r.err.ifBlank { r.out }}", long = !r.ok)
                                }
                            }
                        ) { Text("3 phím") }
                    }
                }
            }
        }

        // ------------------------------------------------ Giao diện
        item {
            GlassCard {
                SectionTitle("Giao diện")
                SwitchRow(
                    "Glassmorphism",
                    "Làm các khung Card trong suốt như kính mờ",
                    s.glassEnabled, { v -> AppStore.updateSettings { it.copy(glassEnabled = v) } }
                )

                SwitchRow(
                    "Live Video Background",
                    if (s.videoUri.isBlank()) "Chưa chọn video" else "Đã chọn video nền",
                    s.videoBgEnabled,
                    { v ->
                        if (v && s.videoUri.isBlank()) videoPicker.launch(arrayOf("video/mp4", "video/*"))
                        else AppStore.updateSettings { it.copy(videoBgEnabled = v) }
                    }
                )
                OutlinedButton(
                    onClick = { videoPicker.launch(arrayOf("video/mp4", "video/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.Movie, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Chọn file video MP4")
                }
                AnimatedVisibility(visible = s.videoBgEnabled, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                    Column {
                        SwitchRow(
                            "Âm thanh của video nền",
                            "Mặc định tắt tiếng",
                            s.videoAudioEnabled, { v -> AppStore.updateSettings { it.copy(videoAudioEnabled = v) } }
                        )
                        Text(
                            "Âm lượng: ${(s.videoVolume * 100).toInt()}%",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (s.videoAudioEnabled) 1f else 0.5f)
                        )
                        Slider(
                            value = s.videoVolume,
                            onValueChange = { v -> AppStore.updateSettings { it.copy(videoVolume = v) } },
                            enabled = s.videoAudioEnabled
                        )
                    }
                }
            }
        }

        item {
            GlassCard {
                SectionTitle("Về preset")
                Presets.all.forEach { p ->
                    val v = p.resolve(s)
                    Text("${p.name}: ${v.width}×${v.height} · ${v.dpi} dpi · ${v.hz} Hz", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        p.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
    }
}
