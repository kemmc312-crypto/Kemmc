package com.gamehelper.resolution.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Công tắc Glassmorphism toàn app (đặt ở MainScreen). */
val LocalGlass = compositionLocalOf { true }

private val White = Color.White

/**
 * Khung Card. Khi bật Glassmorphism: nền trong suốt dạng kính + viền sáng chuyển màu.
 * [highlight] làm viền sáng hơn (dùng cho game đang chạy).
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    highlight: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val glass = LocalGlass.current
    val shape = RoundedCornerShape(24.dp)
    val fill: Brush = if (glass) {
        Brush.linearGradient(listOf(White.copy(alpha = 0.10f), White.copy(alpha = 0.03f)))
    } else {
        SolidColor(Color(0xFF111111))
    }
    val stroke: Brush = when {
        highlight -> SolidColor(White.copy(alpha = 0.90f))
        glass -> Brush.linearGradient(listOf(White.copy(alpha = 0.40f), White.copy(alpha = 0.06f)))
        else -> SolidColor(MaterialTheme.colorScheme.outlineVariant)
    }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(fill, shape)
            .border(BorderStroke(if (highlight) 1.5.dp else 1.dp, stroke), shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(16.dp)
            .animateContentSize(),
        content = content
    )
}

/** Tiêu đề mục: chữ nhỏ, in hoa, giãn chữ, màu xám sáng. */
@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        color = White.copy(alpha = 0.60f),
        modifier = modifier.padding(bottom = 8.dp)
    )
}

// ----------------------------------------------------------------------
// Công tắc trong suốt
// ----------------------------------------------------------------------

/**
 * Công tắc trong suốt: thân gần như không có nền, chỉ có viền trắng; bật lên thì viền và nút gạt sáng trắng.
 * Truyền [onCheckedChange] = null nếu cả hàng đã bấm được (như trong [SwitchRow]).
 */
@Composable
fun GlassSwitch(
    checked: Boolean,
    onCheckedChange: ((Boolean) -> Unit)?,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val progress by animateFloatAsState(if (checked) 1f else 0f, tween(220), label = "glass-switch")
    val trackW = 52.dp
    val trackH = 30.dp
    val pad = 4.dp
    val thumb = trackH - pad * 2

    val borderColor = lerp(White.copy(alpha = 0.28f), White.copy(alpha = 0.95f), progress)
    val fillColor = White.copy(alpha = 0.03f + 0.15f * progress)
    val thumbColor = lerp(White.copy(alpha = 0.45f), White, progress)

    Box(
        modifier = modifier
            .graphicsLayer { alpha = if (enabled) 1f else 0.38f }
            .size(trackW, trackH)
            .clip(CircleShape)
            .background(fillColor, CircleShape)
            .border(1.5.dp, borderColor, CircleShape)
            .then(
                if (onCheckedChange != null)
                    Modifier.toggleable(
                        value = checked, enabled = enabled, role = Role.Switch, onValueChange = onCheckedChange
                    )
                else Modifier
            )
            .padding(pad),
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            Modifier
                .offset(x = (trackW - pad * 2 - thumb) * progress)
                .size(thumb)
                .background(thumbColor, CircleShape)
        )
    }
}

@Composable
fun SwitchRow(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = enabled) { onCheckedChange(!checked) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        GlassSwitch(checked = checked, onCheckedChange = null, enabled = enabled)
    }
}

// ----------------------------------------------------------------------
// Nút trong suốt
// ----------------------------------------------------------------------

/**
 * Nút trong suốt viền trắng. [emphasis] = nút chính (nền kính sáng hơn, viền đậm);
 * [danger] = nút nguy hiểm (viền và chữ đỏ nhạt). Có hiệu ứng thu nhỏ nhẹ khi bấm.
 */
@Composable
fun GlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    emphasis: Boolean = false,
    danger: Boolean = false,
    content: @Composable RowScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val accent = if (danger) MaterialTheme.colorScheme.error else White
    val fill = when {
        danger -> accent.copy(alpha = 0.10f)
        emphasis -> White.copy(alpha = 0.14f)
        else -> White.copy(alpha = 0.04f)
    }
    val stroke = accent.copy(alpha = if (emphasis || danger) 0.85f else 0.35f)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, tween(120), label = "btn-scale")

    Row(
        modifier = modifier
            .heightIn(min = 46.dp)
            .graphicsLayer {
                alpha = if (enabled) 1f else 0.38f
                scaleX = scale
                scaleY = scale
            }
            .clip(shape)
            .background(fill, shape)
            .border(1.dp, stroke, shape)
            .clickable(
                interactionSource = interaction,
                indication = androidx.compose.foundation.LocalIndication.current,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick
            )
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val rowScope = this
        CompositionLocalProvider(LocalContentColor provides accent) {
            ProvideTextStyle(MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)) {
                rowScope.content()
            }
        }
    }
}

/** Nút chữ, không viền, không nền. */
@Composable
fun GlassTextButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit
) {
    Row(
        modifier = modifier
            .heightIn(min = 40.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.38f }
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val rowScope = this
        CompositionLocalProvider(LocalContentColor provides White) {
            ProvideTextStyle(MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)) {
                rowScope.content()
            }
        }
    }
}

/** Nút icon tròn trong suốt viền trắng. */
@Composable
fun GlassIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .size(46.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.38f }
            .clip(CircleShape)
            .background(White.copy(alpha = 0.04f), CircleShape)
            .border(1.dp, White.copy(alpha = 0.35f), CircleShape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalContentColor provides White, content = content)
    }
}

/** Nút icon dạng bật/tắt: bật thì nền kính sáng và viền đậm. */
@Composable
fun GlassIconToggle(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .size(46.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.38f }
            .clip(CircleShape)
            .background(White.copy(alpha = if (checked) 0.22f else 0.04f), CircleShape)
            .border(1.dp, White.copy(alpha = if (checked) 0.95f else 0.35f), CircleShape)
            .toggleable(value = checked, enabled = enabled, role = Role.Switch, onValueChange = onCheckedChange),
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalContentColor provides White, content = content)
    }
}

/** Nút nổi “Thêm …” trong suốt. Có lớp đen mờ phía sau để chữ luôn đọc được trên video nền. */
@Composable
fun GlassFab(
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
    text: @Composable () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier = modifier
            .clip(shape)
            .background(Color.Black.copy(alpha = 0.55f), shape)
            .background(White.copy(alpha = 0.10f), shape)
            .border(1.dp, White.copy(alpha = 0.70f), shape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CompositionLocalProvider(LocalContentColor provides White) {
            icon()
            Spacer(Modifier.width(8.dp))
            ProvideTextStyle(MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)) { text() }
        }
    }
}

// ----------------------------------------------------------------------
// Ô nhập + slider
// ----------------------------------------------------------------------

@Composable
private fun glassFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = White,
    unfocusedTextColor = White,
    disabledTextColor = White.copy(alpha = 0.4f),
    focusedContainerColor = Color.Transparent,
    unfocusedContainerColor = Color.Transparent,
    disabledContainerColor = Color.Transparent,
    focusedBorderColor = White.copy(alpha = 0.90f),
    unfocusedBorderColor = White.copy(alpha = 0.30f),
    disabledBorderColor = White.copy(alpha = 0.12f),
    cursorColor = White,
    focusedLabelColor = White,
    unfocusedLabelColor = White.copy(alpha = 0.6f),
    disabledLabelColor = White.copy(alpha = 0.3f),
    focusedSuffixColor = White.copy(alpha = 0.7f),
    unfocusedSuffixColor = White.copy(alpha = 0.7f)
)

/** Ô nhập trong suốt viền trắng. */
@Composable
fun GlassTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    label: (@Composable () -> Unit)? = null,
    suffix: (@Composable () -> Unit)? = null,
    singleLine: Boolean = false,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        enabled = enabled,
        label = label,
        suffix = suffix,
        singleLine = singleLine,
        keyboardOptions = keyboardOptions,
        shape = RoundedCornerShape(14.dp),
        colors = glassFieldColors()
    )
}

/** Slider trắng – đen: thanh sáng trắng, phần còn lại trong suốt. */
@Composable
fun GlassSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f
) {
    Slider(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        enabled = enabled,
        valueRange = valueRange,
        colors = SliderDefaults.colors(
            thumbColor = White,
            activeTrackColor = White,
            inactiveTrackColor = White.copy(alpha = 0.22f),
            disabledThumbColor = White.copy(alpha = 0.35f),
            disabledActiveTrackColor = White.copy(alpha = 0.35f),
            disabledInactiveTrackColor = White.copy(alpha = 0.10f)
        )
    )
}

@Composable
fun NumberField(
    label: String,
    value: Int,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    suffix: String? = null
) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    GlassTextField(
        value = text,
        onValueChange = { raw ->
            val digits = raw.filter { it.isDigit() }.take(5)
            text = digits
            digits.toIntOrNull()?.let(onValueChange)
        },
        label = { Text(label) },
        singleLine = true,
        enabled = enabled,
        suffix = if (suffix != null) {
            { Text(suffix) }
        } else null,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier
    )
}

/** Icon của một ứng dụng (tải bất đồng bộ). */
@Composable
fun AppIcon(packageName: String, size: Dp = 44.dp) {
    val ctx = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(initialValue = null, packageName) {
        value = withContext(Dispatchers.IO) {
            try {
                ctx.packageManager.getApplicationIcon(packageName).toBitmap(96, 96).asImageBitmap()
            } catch (_: Exception) {
                null
            }
        }
    }
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .size(size)
            .clip(shape)
            .background(White.copy(alpha = 0.08f))
            .border(1.dp, White.copy(alpha = 0.18f), shape)
    ) {
        bitmap?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.fillMaxSize()) }
    }
}
