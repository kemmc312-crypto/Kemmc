package com.gamehelper.resolution.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.gamehelper.resolution.core.PermState
import com.gamehelper.resolution.core.PermissionChecker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(PermissionChecker.check(app))
    val state: StateFlow<PermState> = _state.asStateFlow()

    fun refresh() { _state.value = PermissionChecker.check(getApplication()) }
}
