package com.gamehelper.resolution.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import com.gamehelper.resolution.R
import com.gamehelper.resolution.ui.MainActivity
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

/** Chạy các script .py nền (Chaquopy) trong một foreground service duy nhất. */
class PythonRunnerService : Service() {

    companion object {
        const val ACTION_START = "com.gamehelper.resolution.PY_START"
        const val ACTION_STOP = "com.gamehelper.resolution.PY_STOP"
        const val ACTION_STOP_ALL = "com.gamehelper.resolution.PY_STOP_ALL"
        const val EXTRA_PATH = "path"
        private const val CHANNEL = "scripts"
        private const val NOTIF_ID = 42

        /** Tập đường dẫn tuyệt đối của các script đang chạy (UI quan sát trực tiếp). */
        val running = MutableStateFlow<Set<String>>(emptySet())
        val errors = MutableSharedFlow<String>(extraBufferCapacity = 8)

        private fun intent(c: Context, action: String, path: String? = null) =
            Intent(c, PythonRunnerService::class.java).setAction(action).apply { path?.let { putExtra(EXTRA_PATH, it) } }

        fun start(c: Context, path: String) = ContextCompat.startForegroundService(c, intent(c, ACTION_START, path))
        fun stop(c: Context, path: String) { c.startService(intent(c, ACTION_STOP, path)) }
    }

    private val threads = ConcurrentHashMap<String, Thread>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Script Python", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                ServiceCompat.startForeground(this, NOTIF_ID, notification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                intent.getStringExtra(EXTRA_PATH)?.let(::startScript)
            }
            ACTION_STOP -> intent.getStringExtra(EXTRA_PATH)?.let(::stopScript)
            ACTION_STOP_ALL -> running.value.toList().forEach(::stopScript)
        }
        if (running.value.isEmpty()) stopSelf()
        return START_NOT_STICKY
    }

    private fun startScript(path: String) {
        if (threads.containsKey(path)) return
        try {
            if (!Python.isStarted()) Python.start(AndroidPlatform(applicationContext))
        } catch (t: Throwable) {
            errors.tryEmit("Không khởi động được Python: ${t.message}"); return
        }
        running.update { it + path }
        threads[path] = thread(name = "py-${File(path).name}") {
            val err = try {
                Python.getInstance().getModule("runner").callAttr("run_blocking", path).toString()
            } catch (t: Throwable) { t.message ?: t.toString() }
            threads.remove(path)
            running.update { it - path }
            if (err.isNotBlank())
                errors.tryEmit("${File(path).name}: ${err.lines().lastOrNull { it.isNotBlank() }}")
            if (running.value.isEmpty()) stopSelf()
            else getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification())
        }
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification())
    }

    private fun stopScript(path: String) {
        if (Python.isStarted()) runCatching { Python.getInstance().getModule("runner").callAttr("stop", path) }
    }

    private fun notification(): Notification {
        val stopAll = PendingIntent.getService(this, 0, intent(this, ACTION_STOP_ALL), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_script)
            .setContentTitle("Script Python đang chạy")
            .setContentText("${running.value.size} script")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(R.drawable.ic_stop, "Dừng tất cả", stopAll)
            .build()
    }
}
