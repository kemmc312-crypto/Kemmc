package com.gamehelper.resolution

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun NumField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit)) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier
    )
}

@Composable
fun GameEditDialog(
    initial: GameConfig?,
    settings: AppSettings,
    installed: List<InstalledApp>,
    onLoadInstalled: () -> Unit,
    onDismiss: () -> Unit,
    onSave: (GameConfig) -> Unit
) {
    var pkg by remember { mutableStateOf(initial?.packageName ?: "") }
    var name by remember { mutableStateOf(initial?.displayName ?: "") }
    var w by remember { mutableStateOf((initial?.width ?: settings.defWidth).toString()) }
    var h by remember { mutableStateOf((initial?.height ?: settings.defHeight).toString()) }
    var dpi by remember { mutableStateOf((initial?.dpi ?: settings.defDpi).toString()) }
    var hz by remember { mutableStateOf((initial?.hz ?: settings.defHz).toString()) }
    var delay by remember {
        mutableStateOf(if (initial != null && initial.delayMs >= 0) initial.delayMs.toString() else "")
    }
    var picker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Thêm game" else "Sửa game") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onLoadInstalled(); picker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Chọn từ ứng dụng đã cài")
                }
                OutlinedTextField(name, { name = it }, label = { Text("Tên hiển thị") }, singleLine = true)
                OutlinedTextField(pkg, { pkg = it.trim() }, label = { Text("Package name") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField("Width", w, { w = it }, Modifier.weight(1f))
                    NumField("Height", h, { h = it }, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumField("DPI", dpi, { dpi = it }, Modifier.weight(1f))
                    NumField("Hz", hz, { hz = it }, Modifier.weight(1f))
                }
                NumField("Delay riêng (ms) - để trống = mặc định", delay, { delay = it })
            }
        },
        confirmButton = {
            TextButton(
                enabled = pkg.isNotBlank() && w.isNotBlank() && h.isNotBlank() && dpi.isNotBlank() && hz.isNotBlank(),
                onClick = {
                    onSave(GameConfig(
                        pkg, name.ifBlank { pkg },
                        w.toInt(), h.toInt(), dpi.toInt(), hz.toInt(),
                        delay.toLongOrNull() ?: -1
                    ))
                }
            ) { Text("Lưu") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )

    if (picker) AppPickerDialog(installed, { picker = false }) {
        pkg = it.packageName; if (name.isBlank()) name = it.label; picker = false
    }
}

@Composable
fun AppPickerDialog(apps: List<InstalledApp>, onDismiss: () -> Unit, onPick: (InstalledApp) -> Unit) {
    var q by remember { mutableStateOf("") }
    val filtered = remember(apps, q) {
        apps.filter { it.label.contains(q, true) || it.packageName.contains(q, true) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chọn ứng dụng") },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, label = { Text("Tìm kiếm") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(filtered, key = { it.packageName }) { a ->
                        Column(Modifier.fillMaxWidth().clickable { onPick(a) }.padding(vertical = 8.dp)) {
                            Text(a.label, style = MaterialTheme.typography.bodyLarge)
                            Text(a.packageName, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Đóng") } }
    )
}

@Composable
fun ConfirmDeleteDialog(name: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Xóa game?") },
        text = { Text("Xóa \"$name\" khỏi danh sách.") },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Xóa") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}
