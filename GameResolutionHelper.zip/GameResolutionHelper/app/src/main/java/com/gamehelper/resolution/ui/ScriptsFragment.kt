package com.gamehelper.resolution.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.gamehelper.resolution.core.ScriptStore
import com.gamehelper.resolution.databinding.FragmentScriptsBinding
import com.gamehelper.resolution.service.PythonRunnerService
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch
import java.io.File

class ScriptsFragment : Fragment() {
    private var _b: FragmentScriptsBinding? = null
    private val b get() = _b!!
    private lateinit var adapter: ScriptAdapter
    private var files: List<File> = emptyList()
    private var running: Set<String> = emptySet()

    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        ScriptStore.import(requireContext(), uri)
            .onSuccess { refreshFiles(false); snack("Đã nhập ${it.name}") }
            .onFailure { snack(it.message ?: "Nhập file thất bại") }
    }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); useFadeThrough() }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentScriptsBinding.inflate(i, c, false).also { _b = it }.root

    override fun onViewCreated(view: View, s: Bundle?) {
        val ctx = requireContext()
        ScriptStore.ensureSample(ctx)
        adapter = ScriptAdapter(onToggle = ::toggle, onDelete = ::confirmDelete)
        b.rvScripts.layoutManager = LinearLayoutManager(ctx)
        b.rvScripts.adapter = adapter
        b.fabImport.setOnClickListener { importLauncher.launch(arrayOf("*/*")) }
        refreshFiles(true)
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { PythonRunnerService.running.collect { running = it; render() } }
                launch { PythonRunnerService.errors.collect { snack(it) } }
            }
        }
    }

    private fun refreshFiles(animate: Boolean) {
        files = ScriptStore.list(requireContext())
        render()
        if (animate) b.rvScripts.scheduleLayoutAnimation()
    }

    private fun render() {
        if (_b == null) return
        adapter.submitList(files.map { ScriptItem(it, it.absolutePath in running) })
        b.emptyView.isVisible = files.isEmpty()
    }

    private fun toggle(item: ScriptItem) {
        val ctx = requireContext()
        val path = item.file.absolutePath
        if (item.running) { PythonRunnerService.stop(ctx, path); return }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        PythonRunnerService.start(ctx, path)
    }

    private fun confirmDelete(item: ScriptItem) {
        MaterialAlertDialogBuilder(requireContext()).setTitle("Xóa ${item.file.name}?")
            .setPositiveButton("Xóa") { _, _ ->
                if (item.running) PythonRunnerService.stop(requireContext(), item.file.absolutePath)
                item.file.delete(); refreshFiles(false)
            }.setNegativeButton("Hủy", null).show()
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
