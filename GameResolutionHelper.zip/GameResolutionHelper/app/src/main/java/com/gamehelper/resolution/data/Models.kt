package com.gamehelper.resolution.data

import org.json.JSONObject

/** Cấu hình riêng cho từng game. */
data class GameConfig(
    val packageName: String,
    val displayName: String,
    val width: Int,
    val height: Int,
    val dpi: Int,
    val hz: Int,
    val delaySec: Int,
    val lockRatio: Boolean
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("pkg", packageName)
        put("name", displayName)
        put("w", width)
        put("h", height)
        put("dpi", dpi)
        put("hz", hz)
        put("delay", delaySec)
        put("lock", lockRatio)
    }

    companion object {
        fun fromJson(o: JSONObject): GameConfig {
            val pkg = o.getString("pkg")
            return GameConfig(
                packageName = pkg,
                displayName = o.optString("name", pkg),
                width = o.optInt("w", 1080),
                height = o.optInt("h", 2400),
                dpi = o.optInt("dpi", 440),
                hz = o.optInt("hz", 60),
                delaySec = o.optInt("delay", 2),
                lockRatio = o.optBoolean("lock", true)
            )
        }
    }
}

/** Toàn bộ cài đặt ứng dụng. */
data class AppSettings(
    // Thông số gốc
    val defaultWidth: Int = 1080,
    val defaultHeight: Int = 2400,
    val defaultDpi: Int = 440,
    val defaultHz: Int = 60,

    // Giao diện
    val glassEnabled: Boolean = true,
    val videoBgEnabled: Boolean = false,
    val videoUri: String = "",
    val videoAudioEnabled: Boolean = false,
    val videoVolume: Float = 0.5f,

    // Tính năng
    val safetyGuard: Boolean = true,
    val lockAspect: Boolean = true,
    val navSwitchEnabled: Boolean = false,
    val autoResetMonitor: Boolean = true,
    val tileEnabled: Boolean = true,
    val ramCleanEnabled: Boolean = false,
    val ramExclusions: String = "",
    val floatingEnabled: Boolean = true,
    val defaultDelaySec: Int = 2,
    val presetsEnabled: Boolean = true
)

/** Giá trị đã tính xong từ một preset. */
data class PresetValues(val width: Int, val height: Int, val dpi: Int, val hz: Int)

/** Mẫu cấu hình nhanh, tính theo % của thông số gốc. */
data class Preset(
    val id: String,
    val name: String,
    val description: String,
    val scalePercent: Int,
    val hz: Int
) {
    fun resolve(s: AppSettings): PresetValues {
        fun even(v: Int) = (v + 1) / 2 * 2
        return PresetValues(
            width = even(s.defaultWidth * scalePercent / 100),
            height = even(s.defaultHeight * scalePercent / 100),
            dpi = (s.defaultDpi * scalePercent / 100).coerceAtLeast(72),
            hz = hz
        )
    }
}

object Presets {
    val all = listOf(
        Preset("max", "Max Performance", "Giảm mạnh độ phân giải để tối đa FPS", 55, 120),
        Preset("balanced", "Balanced", "Cân bằng giữa mượt và đẹp", 75, 90),
        Preset("graphic", "Graphic Hub", "Giữ độ nét gốc, ưu tiên đồ họa", 100, 60)
    )
}
