package com.gamehelper.resolution

import android.app.Activity
import android.os.Bundle

/** Shortcut ngoài màn hình chính trỏ vào đây: bắt đầu session rồi đóng ngay. */
class LaunchActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        intent.getStringExtra(GameSessionService.EXTRA_PKG)?.let { GameSessionService.start(this, it) }
        finish()
    }
}
