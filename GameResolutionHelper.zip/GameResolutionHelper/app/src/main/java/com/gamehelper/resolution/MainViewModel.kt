package com.gamehelper.resolution

import android.app.Application
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)

    var settings by mutableStateOf(repo.loadSettings()); private set
    val games = mutableStateListOf<GameConfig>().apply { addAll(repo.loadGames()) }
    var shizuku by mutableStateOf(ShizukuState.NOT_RUNNING); private set
    var installed by mutableStateOf<List<InstalledApp>>(emptyList()); private set
    val terminal = mutableStateListOf("Terminal sẵn sàng. Lệnh thường chạy qua Shizuku (shell).",
        "Gõ 'termux <lệnh>' để chạy trong Termux, vd: termux python ~/test.py")

    init {
        TermuxBus.onResult = { terminal.add(it) }
        refreshShizuku()
    }

    fun refreshShizuku() { shizuku = ShizukuHelper.state() }

    fun updateSettings(s: AppSettings) { settings = s; repo.saveSettings(s) }

    fun saveGame(g: GameConfig, oldPkg: String?) {
        val idx = games.indexOfFirst { it.packageName == (oldPkg ?: g.packageName) }
        if (idx >= 0) games[idx] = g else games.add(g)
        repo.saveGames(games.toList())
    }

    fun deleteGame(g: GameConfig) { games.remove(g); repo.saveGames(games.toList()) }

    fun loadInstalled() {
        if (installed.isNotEmpty()) return
        viewModelScope.launch {
            installed = withContext(Dispatchers.IO) {
                val pm = app.packageManager
                val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                pm.queryIntentActivities(i, 0)
                    .map { InstalledApp(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                    .filter { it.packageName != app.packageName }
                    .distinctBy { it.packageName }
                    .sortedBy { it.label.lowercase() }
            }
        }
    }

    fun runTerminal(cmd: String) {
        val c = cmd.trim()
        if (c.isEmpty()) return
        terminal.add("$ $c")
        if (c == "clear") { terminal.clear(); return }
        if (c.startsWith("termux ")) {
            TermuxRunner.run(app, c.removePrefix("termux ").trim())?.let { terminal.add(it) }
            return
        }
        if (ShizukuHelper.state() != ShizukuState.READY) {
            terminal.add("Shizuku chưa sẵn sàng."); return
        }
        viewModelScope.launch { terminal.add(ShizukuHelper.exec(c).text) }
    }

    fun resetDisplayNow(onDone: (String) -> Unit) {
        if (ShizukuHelper.state() != ShizukuState.READY) { onDone("Shizuku chưa sẵn sàng"); return }
        viewModelScope.launch {
            val r = DisplayController.restore(settings)
            onDone(if (r.code == 0) "Đã khôi phục hiển thị" else r.text)
        }
    }

    override fun onCleared() { TermuxBus.onResult = null }
}
