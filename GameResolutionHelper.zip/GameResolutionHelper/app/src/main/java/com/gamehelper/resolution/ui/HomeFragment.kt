package com.gamehelper.resolution.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.gamehelper.resolution.core.DisplayController
import com.gamehelper.resolution.core.PermState
import com.gamehelper.resolution.databinding.FragmentHomeBinding
import com.gamehelper.resolution.databinding.ViewPermissionCardBinding
import com.gamehelper.resolution.R
import com.gamehelper.resolution.shizuku.ShizukuHelper
import com.gamehelper.resolution.shizuku.ShizukuHelper.State
import com.google.android.material.color.MaterialColors
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {
    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!
    private val vm: MainViewModel by activityViewModels()
    private val cards = mutableListOf<ViewPermissionCardBinding>()
    private val lastOk = BooleanArray(3)

    private class Item(val title: String, val desc: String, val ok: Boolean, val btn: String, val action: () -> Unit)

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); useFadeThrough() }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentHomeBinding.inflate(i, c, false).also { _b = it }.root

    override fun onViewCreated(view: View, s: Bundle?) {
        repeat(3) { i ->
            val c = ViewPermissionCardBinding.inflate(layoutInflater, b.permList, false)
            b.permList.addView(c.root)
            cards += c
            c.root.alpha = 0f; c.root.translationY = 56f           // hiệu ứng xuất hiện lần lượt
            c.root.animate().alpha(1f).translationY(0f).setStartDelay(90L * i).setDuration(450)
                .setInterpolator(DecelerateInterpolator()).start()
        }
        b.btnEmergency.setOnClickListener {
            if (ShizukuHelper.state() != State.READY) { snack("Cần cấp quyền Shizuku trước"); return@setOnClickListener }
            viewLifecycleOwner.lifecycleScope.launch {
                val r = DisplayController.restore(null)
                snack(if (r.ok) "Đã khôi phục độ phân giải / DPI / Hz" else "Lỗi: ${r.output}")
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) { vm.state.collect(::render) }
        }
    }

    private fun render(s: PermState) {
        val ctx = requireContext()
        val items = listOf(
            when (s.shizuku) {
                State.READY -> Item("Shizuku", "Đã kết nối và được cấp quyền.", true, "") {}
                State.NO_PERMISSION -> Item("Shizuku", "Shizuku đang chạy. Cho phép ứng dụng này sử dụng Shizuku để đổi cấu hình màn hình.",
                    false, "Cấp quyền") { ShizukuHelper.requestPermission() }
                State.NOT_RUNNING -> Item("Shizuku", "Shizuku chưa chạy. Mở Shizuku và khởi động (Wireless debugging hoặc root), rồi quay lại đây.",
                    false, "Mở Shizuku") { openShizuku() }
            },
            Item("Dịch vụ Trợ năng",
                if (s.accessibility) "Đã bật - ứng dụng có thể nhận biết game đang mở."
                else "Bật \"Game Resolution Helper\" trong Trợ năng. Android 13+: nếu bị chặn, vào Thông tin ứng dụng → ⋮ → Cho phép cài đặt bị hạn chế.",
                s.accessibility, "Mở Trợ năng") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            Item("Hiển thị trên ứng dụng khác",
                if (s.overlay) "Đã cho phép - nút nổi khôi phục sẽ hiển thị khi vào game."
                else "Cần để hiển thị nút nổi khôi phục độ phân giải khi đang chơi game.",
                s.overlay, "Cấp quyền") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }
        )
        val primary = MaterialColors.getColor(b.root, com.google.android.material.R.attr.colorPrimary)
        val error = MaterialColors.getColor(b.root, com.google.android.material.R.attr.colorError)
        items.forEachIndexed { i, it ->
            val c = cards.getOrNull(i) ?: return@forEachIndexed
            c.txtTitle.text = it.title
            c.txtDesc.text = it.desc
            c.btnAction.isVisible = !it.ok
            c.btnAction.text = it.btn
            c.btnAction.setOnClickListener { _ -> it.action() }
            c.imgStatus.setImageResource(if (it.ok) R.drawable.ic_check_circle else R.drawable.ic_warning)
            c.imgStatus.setColorFilter(if (it.ok) primary else error)
            if (it.ok && !lastOk[i]) {                              // hiệu ứng "pop" khi vừa được cấp
                c.imgStatus.scaleX = 0f; c.imgStatus.scaleY = 0f
                c.imgStatus.animate().scaleX(1f).scaleY(1f).setDuration(450).setInterpolator(OvershootInterpolator()).start()
            }
            lastOk[i] = it.ok
        }
        val n = s.grantedCount
        b.txtProgress.text = "Đã cấp $n/3 quyền"
        b.progress.setProgressCompat(n * 100 / 3, true)
        b.txtSummary.text = if (s.allGranted) "Mọi thứ đã sẵn sàng. Thêm game ở tab Game."
        else "Cấp đủ 3 quyền bên dưới để ứng dụng hoạt động."
    }

    private fun openShizuku() {
        val pm = requireContext().packageManager
        val i = pm.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
        startActivity(i)
    }

    override fun onDestroyView() { super.onDestroyView(); cards.clear(); _b = null }
}
