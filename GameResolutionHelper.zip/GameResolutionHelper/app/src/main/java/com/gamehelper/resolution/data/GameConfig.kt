package com.gamehelper.resolution.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Cấu hình riêng cho từng game. Giá trị 0 = không thay đổi / dùng reset hệ thống. */
data class GameConfig(
    val packageName: String,
    val label: String,
    val width: Int,
    val height: Int,
    val gameDpi: Int,
    val defaultDpi: Int,
    val gameHz: Int,
    val defaultHz: Int,
    val delaySec: Int,
    val enabled: Boolean = true
) {
    fun toJson(): JSONObject = JSONObject()
        .put("pkg", packageName).put("label", label)
        .put("w", width).put("h", height)
        .put("dpi", gameDpi).put("ddpi", defaultDpi)
        .put("hz", gameHz).put("dhz", defaultHz)
        .put("delay", delaySec).put("on", enabled)

    companion object {
        fun fromJson(o: JSONObject) = GameConfig(
            o.getString("pkg"), o.optString("label", o.getString("pkg")),
            o.optInt("w"), o.optInt("h"),
            o.optInt("dpi"), o.optInt("ddpi"),
            o.optInt("hz"), o.optInt("dhz"),
            o.optInt("delay", 5), o.optBoolean("on", true)
        )
    }
}

object GameRepository {
    private const val PREF = "games"
    private const val KEY = "list"

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun all(c: Context): List<GameConfig> = runCatching {
        val arr = JSONArray(prefs(c).getString(KEY, "[]"))
        List(arr.length()) { GameConfig.fromJson(arr.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    fun find(c: Context, pkg: String): GameConfig? = all(c).firstOrNull { it.packageName == pkg }

    private fun save(c: Context, list: List<GameConfig>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(c).edit().putString(KEY, arr.toString()).apply()
    }

    fun upsert(c: Context, cfg: GameConfig) {
        val list = all(c).toMutableList()
        val i = list.indexOfFirst { it.packageName == cfg.packageName }
        if (i >= 0) list[i] = cfg else list.add(cfg)
        save(c, list)
    }

    fun remove(c: Context, pkg: String) = save(c, all(c).filterNot { it.packageName == pkg })
}
