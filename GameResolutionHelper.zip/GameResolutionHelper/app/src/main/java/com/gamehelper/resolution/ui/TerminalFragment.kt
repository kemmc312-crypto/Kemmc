package com.gamehelper.resolution.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.gamehelper.resolution.R
import com.gamehelper.resolution.databinding.FragmentTerminalBinding
import com.google.android.material.chip.Chip
import kotlinx.coroutines.launch

class TerminalFragment : Fragment() {
    private var _b: FragmentTerminalBinding? = null
    private val b get() = _b!!
    private val vm: TerminalViewModel by activityViewModels()

    private val quick = listOf(
        "wm size", "wm density", "dumpsys display | grep -i fps",
        "getprop ro.product.model", "pm list packages -3", "dumpsys window | grep mCurrentFocus"
    )

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); useFadeThrough() }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentTerminalBinding.inflate(i, c, false).also { _b = it }.root

    override fun onViewCreated(view: View, s: Bundle?) {
        quick.forEach { cmd ->
            b.quickChips.addView(Chip(requireContext()).apply {
                text = cmd
                setOnClickListener { b.edtCmd.setText(cmd); b.edtCmd.setSelection(cmd.length) }
            })
        }
        b.btnRun.setOnClickListener { if (vm.running.value) vm.stop() else run() }
        b.btnClear.setOnClickListener { vm.clear() }
        b.edtCmd.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { run(); true } else false
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    vm.log.collect { text ->
                        b.txtOutput.text = text.ifEmpty { "# Kết quả lệnh sẽ hiển thị tại đây theo thời gian thực…" }
                        b.scroll.post { b.scroll.fullScroll(View.FOCUS_DOWN) }
                    }
                }
                launch {
                    vm.running.collect { r ->
                        b.btnRun.text = if (r) "Dừng" else "Chạy"
                        b.btnRun.setIconResource(if (r) R.drawable.ic_stop else R.drawable.ic_play)
                    }
                }
            }
        }
    }

    private fun run() {
        vm.run(b.edtCmd.text?.toString().orEmpty())
        b.edtCmd.text?.clear()
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
