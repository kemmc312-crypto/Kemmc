package com.gamehelper.resolution.service

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs

/**
 * Nút nổi 2-trong-1: kéo thả tự do; bấm một lần => khôi phục hiển thị + force-stop game
 * (việc xử lý nằm trong [onClick], do GameSessionService cung cấp).
 */
class FloatingButton(
    private val context: Context,
    private val onClick: () -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: View? = null

    val isShowing: Boolean get() = view != null

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (view != null) return

        // Lấy metrics thật SAU khi đã đổi phân giải để kích thước nút luôn hợp lý
        val dm = DisplayMetrics()
        val display = (context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)
        @Suppress("DEPRECATION")
        display.getRealMetrics(dm)

        val size = (52 * dm.density).toInt().coerceAtLeast(96)
        val screenW = dm.widthPixels
        val screenH = dm.heightPixels

        val button = TextView(context).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE6D32F2F.toInt())
                setStroke((2 * dm.density).toInt().coerceAtLeast(2), 0x88FFFFFF.toInt())
            }
            elevation = 8 * dm.density
        }

        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenW - size - 16 * dm.density).toInt().coerceAtLeast(0)
            y = (screenH * 0.25f).toInt()
        }

        val slop = ViewConfiguration.get(context).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        button.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        params.x = (startX + dx).toInt().coerceIn(0, (screenW - size).coerceAtLeast(0))
                        params.y = (startY + dy).toInt().coerceIn(0, (screenH - size).coerceAtLeast(0))
                        try {
                            windowManager.updateViewLayout(v, params)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                    if (e.actionMasked == MotionEvent.ACTION_UP && !moved) onClick()
                    true
                }
                else -> false
            }
        }

        try {
            windowManager.addView(button, params)
            view = button
        } catch (_: Exception) {
            view = null
        }
    }

    fun hide() {
        view?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        view = null
    }
}
