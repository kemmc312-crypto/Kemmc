package com.gamehelper.resolution.service

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import com.gamehelper.resolution.R
import kotlin.math.abs

/** Nút nổi kéo thả (TYPE_APPLICATION_OVERLAY). Bấm = onClick, kéo = di chuyển rồi hít vào cạnh màn hình. */
class FloatingButton(private val ctx: Context, private val onClick: () -> Unit) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private var view: View? = null
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 320 }

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (view != null || !Settings.canDrawOverlays(ctx)) return
        val v = LayoutInflater.from(ctx).inflate(R.layout.view_floating_button, null)
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) { lp.x = startX + dx.toInt(); lp.y = startY + dy.toInt(); update(v) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (moved) snap(v) else onClick(); true }
                else -> false
            }
        }
        try { wm.addView(v, lp) } catch (_: Exception) { return }
        view = v
        v.alpha = 0f; v.scaleX = 0.4f; v.scaleY = 0.4f
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(350).setInterpolator(OvershootInterpolator()).start()
    }

    fun hide() {
        val v = view ?: return
        view = null
        v.animate().alpha(0f).scaleX(0.4f).scaleY(0.4f).setDuration(200).withEndAction {
            try { wm.removeView(v) } catch (_: Exception) {}
        }.start()
    }

    private fun update(v: View) { try { wm.updateViewLayout(v, lp) } catch (_: Exception) {} }

    private fun snap(v: View) {
        val screenW = ctx.resources.displayMetrics.widthPixels
        val target = if (lp.x + v.width / 2 < screenW / 2) 0 else screenW - v.width
        ValueAnimator.ofInt(lp.x, target).apply {
            duration = 220
            addUpdateListener { lp.x = it.animatedValue as Int; update(v) }
        }.start()
    }
}
