package com.gamehelper.resolution.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.gamehelper.resolution.data.GameConfig
import com.gamehelper.resolution.data.GameRepository
import com.gamehelper.resolution.databinding.FragmentGamesBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class GamesFragment : Fragment() {
    private var _b: FragmentGamesBinding? = null
    private val b get() = _b!!
    private lateinit var adapter: GameAdapter

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); useFadeThrough() }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        FragmentGamesBinding.inflate(i, c, false).also { _b = it }.root

    override fun onViewCreated(view: View, s: Bundle?) {
        val ctx = requireContext()
        adapter = GameAdapter(
            onToggle = { cfg, on -> GameRepository.upsert(ctx, cfg.copy(enabled = on)); refresh(false) },
            onEdit = { cfg -> GameConfigDialog.show(ctx, cfg) { save(it) } },
            onDelete = { cfg ->
                MaterialAlertDialogBuilder(ctx).setTitle("Xóa ${cfg.label}?")
                    .setPositiveButton("Xóa") { _, _ -> GameRepository.remove(ctx, cfg.packageName); refresh(false) }
                    .setNegativeButton("Hủy", null).show()
            }
        )
        b.rvGames.layoutManager = LinearLayoutManager(ctx)
        b.rvGames.adapter = adapter
        b.fabAdd.setOnClickListener {
            AppPickerDialog.show(ctx, viewLifecycleOwner.lifecycleScope) { app ->
                val cfg: GameConfig = GameRepository.find(ctx, app.packageName) ?: GameConfigDialog.defaults(ctx, app)
                GameConfigDialog.show(ctx, cfg) { save(it) }
            }
        }
        refresh(true)
    }

    private fun save(cfg: GameConfig) { GameRepository.upsert(requireContext(), cfg); refresh(false) }

    private fun refresh(animate: Boolean) {
        val list = GameRepository.all(requireContext())
        adapter.submitList(list)
        b.emptyView.isVisible = list.isEmpty()
        if (animate) b.rvGames.scheduleLayoutAnimation()
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
