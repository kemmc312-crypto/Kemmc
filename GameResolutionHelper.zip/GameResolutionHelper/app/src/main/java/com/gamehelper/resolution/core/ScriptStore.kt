package com.gamehelper.resolution.core

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

object ScriptStore {
    fun dir(c: Context) = File(c.filesDir, "scripts").apply { mkdirs() }

    fun list(c: Context): List<File> =
        dir(c).listFiles { f -> f.isFile && f.extension.equals("py", true) }?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    fun ensureSample(c: Context) {
        val prefs = c.getSharedPreferences("scripts", Context.MODE_PRIVATE)
        if (prefs.getBoolean("sample_done", false)) return
        runCatching {
            c.assets.open("sample_music.py").use { i -> File(dir(c), "sample_music.py").outputStream().use { i.copyTo(it) } }
        }
        prefs.edit().putBoolean("sample_done", true).apply()
    }

    fun import(c: Context, uri: Uri): Result<File> = runCatching {
        val name = c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: uri.lastPathSegment ?: "script.py"
        require(name.endsWith(".py", true)) { "Chỉ nhận file .py" }
        val out = File(dir(c), File(name).name) // File(name).name chặn path traversal
        c.contentResolver.openInputStream(uri)!!.use { i -> out.outputStream().use { i.copyTo(it) } }
        out
    }
}
