package com.gamehelper.resolution.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppColors = darkColorScheme(
    primary = Color(0xFF6EE7B7),
    onPrimary = Color(0xFF00382A),
    primaryContainer = Color(0xFF0F5C47),
    onPrimaryContainer = Color(0xFFB8F5DF),
    secondary = Color(0xFF93C5FD),
    onSecondary = Color(0xFF0B2A4A),
    secondaryContainer = Color(0xFF24456B),
    onSecondaryContainer = Color(0xFFD3E6FF),
    tertiary = Color(0xFFF9A8D4),
    background = Color(0xFF0B1020),
    onBackground = Color(0xFFE8ECF8),
    surface = Color(0xFF121829),
    onSurface = Color(0xFFE8ECF8),
    surfaceVariant = Color(0xFF1C2338),
    onSurfaceVariant = Color(0xFFB9C0D6),
    surfaceContainer = Color(0xFF171E33),
    surfaceContainerHigh = Color(0xFF1E263D),
    surfaceContainerHighest = Color(0xFF273049),
    outline = Color(0x40FFFFFF),
    outlineVariant = Color(0x22FFFFFF),
    error = Color(0xFFFF8A80),
    onError = Color(0xFF410002)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AppColors, content = content)
}
