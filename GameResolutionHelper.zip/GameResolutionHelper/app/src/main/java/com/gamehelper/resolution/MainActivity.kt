package com.gamehelper.resolution

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.graphics.drawable.toBitmap
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val binderReceived = Shizuku.OnBinderReceivedListener { vm.refreshShizuku() }
    private val binderDead = Shizuku.OnBinderDeadListener { vm.refreshShizuku() }
    private val permResult = Shizuku.OnRequestPermissionResultListener { _, _ -> vm.refreshShizuku() }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permResult)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                var inSettings by remember { mutableStateOf(false) }
                if (inSettings) {
                    BackHandler { inSettings = false }
                    SettingsScreen(
                        settings = vm.settings,
                        onSave = vm::updateSettings,
                        onResetNow = { vm.resetDisplayNow { toast(it) } },
                        onBack = { inSettings = false }
                    )
                } else {
                    MainScreen(
                        vm = vm,
                        onOpenSettings = { inSettings = true },
                        onPlay = ::play,
                        onShortcut = ::createShortcut,
                        onGrantShizuku = ::grantShizuku
                    )
                }
            }
        }
    }

    override fun onResume() { super.onResume(); vm.refreshShizuku() }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permResult)
        super.onDestroy()
    }

    private fun grantShizuku() {
        if (!ShizukuHelper.requestPermission()) toast("Hãy cấp quyền thủ công trong app Shizuku")
    }

    private fun play(g: GameConfig) {
        when (ShizukuHelper.state()) {
            ShizukuState.NOT_RUNNING -> { toast("Shizuku chưa chạy"); return }
            ShizukuState.NO_PERMISSION -> { grantShizuku(); return }
            ShizukuState.READY -> {}
        }
        if (vm.settings.showFloating && !Settings.canDrawOverlays(this)) {
            toast("Hãy cấp quyền 'Hiển thị trên ứng dụng khác'")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        GameSessionService.start(this, g.packageName)
    }

    private fun createShortcut(g: GameConfig) {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
            toast("Launcher không hỗ trợ ghim shortcut"); return
        }
        val launch = Intent(this, LaunchActivity::class.java)
            .setAction(Intent.ACTION_VIEW)
            .putExtra(GameSessionService.EXTRA_PKG, g.packageName)
        val icon = runCatching { IconCompat.createWithBitmap(packageManager.getApplicationIcon(g.packageName).toBitmap(192, 192)) }
            .getOrElse { IconCompat.createWithResource(this, android.R.drawable.sym_def_app_icon) }
        val info = ShortcutInfoCompat.Builder(this, "game_${g.packageName}")
            .setShortLabel(g.displayName)
            .setLongLabel(g.displayName)
            .setIcon(icon)
            .setIntent(launch)
            .build()
        ShortcutManagerCompat.requestPinShortcut(this, info, null)
        toast("Nếu shortcut không xuất hiện: Cài đặt ColorOS > ứng dụng > Quyền > 'Tạo lối tắt' = Cho phép")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
