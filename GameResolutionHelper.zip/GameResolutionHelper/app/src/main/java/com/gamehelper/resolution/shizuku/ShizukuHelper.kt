package com.gamehelper.resolution.shizuku

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.lang.reflect.Method

object ShizukuHelper {
    enum class State { NOT_RUNNING, NO_PERMISSION, READY }
    data class ShellResult(val code: Int, val output: String) { val ok get() = code == 0 }

    const val REQUEST_CODE = 1001

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() || Shizuku.isPreV11() -> State.NOT_RUNNING
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NO_PERMISSION
        }
    } catch (t: Throwable) {
        State.NOT_RUNNING
    }

    fun requestPermission() {
        try { Shizuku.requestPermission(REQUEST_CODE) } catch (_: Throwable) {}
    }

    // Shizuku 13.x đặt newProcess ở chế độ private -> gọi qua reflection (cách phổ biến, chạy với quyền shell)
    private val newProcessMethod: Method by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
    }

    private fun newProcess(cmd: String): Process =
        newProcessMethod.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process

    /** Chạy lệnh, đợi kết thúc, trả toàn bộ output (stdout + stderr). */
    suspend fun exec(cmd: String): ShellResult = withContext(Dispatchers.IO) {
        try {
            val p = newProcess(cmd)
            val out = p.inputStream.bufferedReader().readText()
            ShellResult(p.waitFor(), out.trim())
        } catch (t: Throwable) {
            ShellResult(-1, t.message ?: t.toString())
        }
    }

    /** Chạy lệnh và đẩy từng dòng output theo thời gian thực. */
    suspend fun stream(cmd: String, onStart: (Process) -> Unit, onLine: (String) -> Unit): Int =
        withContext(Dispatchers.IO) {
            val p = newProcess(cmd)
            onStart(p)
            p.inputStream.bufferedReader().forEachLine(onLine)
            p.waitFor()
        }
}
