package com.gamehelper.resolution.ui

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import com.gamehelper.resolution.data.GameConfig
import com.gamehelper.resolution.databinding.DialogAppPickerBinding
import com.gamehelper.resolution.databinding.DialogGameConfigBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object AppPickerDialog {
    fun show(ctx: Context, scope: CoroutineScope, onPick: (AppItem) -> Unit) {
        val vb = DialogAppPickerBinding.inflate(LayoutInflater.from(ctx))
        val dialog = MaterialAlertDialogBuilder(ctx).setTitle("Chọn game / ứng dụng")
            .setView(vb.root).setNegativeButton("Hủy", null).create()
        val adapter = AppAdapter(ctx.packageManager) { dialog.dismiss(); onPick(it) }
        vb.rvApps.layoutManager = LinearLayoutManager(ctx)
        vb.rvApps.adapter = adapter
        vb.edtSearch.doAfterTextChanged { adapter.filter(it?.toString().orEmpty()) }
        dialog.show()
        scope.launch {
            val apps = withContext(Dispatchers.IO) {
                val pm = ctx.packageManager
                val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                pm.queryIntentActivities(i, 0)
                    .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                    .filter { it.packageName != ctx.packageName }
                    .distinctBy { it.packageName }
                    .sortedBy { it.label.lowercase() }
            }
            vb.progress.visibility = View.GONE
            adapter.setData(apps)
        }
    }
}

object GameConfigDialog {

    /** Cấu hình mặc định lấy theo màn hình hiện tại. */
    @Suppress("DEPRECATION")
    fun defaults(ctx: Context, app: AppItem): GameConfig {
        val wm = ctx.getSystemService(WindowManager::class.java)
        val dm = DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
        val w = min(dm.widthPixels, dm.heightPixels); val h = max(dm.widthPixels, dm.heightPixels)
        val hz = wm.defaultDisplay.refreshRate.roundToInt()
        return GameConfig(app.packageName, app.label, w * 3 / 4, h * 3 / 4, dm.densityDpi * 3 / 4, dm.densityDpi, hz, hz, 5)
    }

    fun show(ctx: Context, cfg: GameConfig, onSave: (GameConfig) -> Unit) {
        val v = DialogGameConfigBinding.inflate(LayoutInflater.from(ctx))
        v.txtGame.text = "${cfg.label}\n${cfg.packageName}"
        v.edtWidth.setText(cfg.width.toString()); v.edtHeight.setText(cfg.height.toString())
        v.edtGameDpi.setText(cfg.gameDpi.toString()); v.edtDefaultDpi.setText(cfg.defaultDpi.toString())
        v.edtGameHz.setText(cfg.gameHz.toString()); v.edtDefaultHz.setText(cfg.defaultHz.toString())
        v.swEnabled.isChecked = cfg.enabled
        v.sliderDelay.value = cfg.delaySec.toFloat().coerceIn(0f, 10f)
        fun updDelay() { v.txtDelay.text = "Game Load Delay: ${v.sliderDelay.value.toInt()} giây" }
        updDelay()
        v.sliderDelay.addOnChangeListener { _, _, _ -> updDelay() }

        fun field(e: TextInputEditText, min: Int, max: Int): Int? {
            val n = e.text?.toString()?.trim()?.toIntOrNull()
            return if (n == null || n !in min..max) { e.error = "$min – $max"; null } else n
        }

        val d = MaterialAlertDialogBuilder(ctx).setTitle("Cấu hình game").setView(v.root)
            .setPositiveButton("Lưu", null).setNegativeButton("Hủy", null).create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val w = field(v.edtWidth, 200, 10000); val h = field(v.edtHeight, 200, 10000)
                val gd = field(v.edtGameDpi, 0, 1200); val dd = field(v.edtDefaultDpi, 0, 1200)
                val gh = field(v.edtGameHz, 0, 360); val dh = field(v.edtDefaultHz, 0, 360)
                if (listOf(w, h, gd, dd, gh, dh).any { it == null }) return@setOnClickListener
                onSave(cfg.copy(width = w!!, height = h!!, gameDpi = gd!!, defaultDpi = dd!!, gameHz = gh!!, defaultHz = dh!!,
                    delaySec = v.sliderDelay.value.toInt(), enabled = v.swEnabled.isChecked))
                d.dismiss()
            }
        }
        d.show()
    }
}
