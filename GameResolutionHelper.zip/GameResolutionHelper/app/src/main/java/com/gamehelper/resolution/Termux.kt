package com.gamehelper.resolution

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

object TermuxBus { var onResult: ((String) -> Unit)? = null }

class TermuxResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val b = intent.getBundleExtra("result")
        val text = if (b == null) "(Termux không trả kết quả)" else buildString {
            b.getString("stdout")?.takeIf { it.isNotBlank() }?.let { append(it.trimEnd()) }
            b.getString("stderr")?.takeIf { it.isNotBlank() }?.let { if (isNotEmpty()) append('\n'); append(it.trimEnd()) }
            b.getString("errmsg")?.takeIf { it.isNotBlank() }?.let { if (isNotEmpty()) append('\n'); append(it) }
            if (isEmpty()) append("(exit ${b.getInt("exitCode", 0)})")
        }
        TermuxBus.onResult?.invoke(text)
    }
}

/**
 * Chạy lệnh trong Termux (ví dụ: python script.py). Yêu cầu trong Termux:
 *   echo "allow-external-apps=true" >> ~/.termux/termux.properties
 * và cấp quyền "Run commands in Termux environment" cho app này.
 */
object TermuxRunner {
    fun run(ctx: Context, command: String): String? {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getBroadcast(
            ctx, command.hashCode(), Intent(ctx, TermuxResultReceiver::class.java), flags
        )
        val i = Intent("com.termux.RUN_COMMAND").apply {
            setClassName("com.termux", "com.termux.app.RunCommandService")
            putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
            putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", command))
            putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
            putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
            putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pi)
        }
        return try { ctx.startService(i); null } catch (e: Throwable) { e.message ?: "Termux error" }
    }
}
