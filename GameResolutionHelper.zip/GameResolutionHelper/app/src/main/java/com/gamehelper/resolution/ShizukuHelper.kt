package com.gamehelper.resolution

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import android.content.pm.PackageManager

data class ShellResult(val code: Int, val out: String, val err: String) {
    val text get() = buildString {
        if (out.isNotBlank()) append(out.trimEnd())
        if (err.isNotBlank()) { if (isNotEmpty()) append('\n'); append(err.trimEnd()) }
        if (isEmpty()) append("(exit $code)")
    }
}

object ShizukuHelper {
    const val REQUEST_CODE = 1001

    fun state(): ShizukuState = try {
        when {
            !Shizuku.pingBinder() -> ShizukuState.NOT_RUNNING
            Shizuku.isPreV11() -> ShizukuState.NOT_RUNNING
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> ShizukuState.READY
            else -> ShizukuState.NO_PERMISSION
        }
    } catch (_: Throwable) { ShizukuState.NOT_RUNNING }

    /** @return false nếu người dùng đã chọn "Từ chối vĩnh viễn" (phải cấp trong app Shizuku). */
    fun requestPermission(): Boolean = try {
        if (Shizuku.shouldShowRequestPermissionRationale()) false
        else { Shizuku.requestPermission(REQUEST_CODE); true }
    } catch (_: Throwable) { false }

    // Shizuku.newProcess là private từ 13.x -> gọi bằng reflection (cách phổ biến, hoạt động ổn định).
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
    }

    suspend fun exec(cmd: String): ShellResult = withContext(Dispatchers.IO) {
        try {
            val p = newProcess.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            coroutineScope {
                val out = async { p.inputStream.bufferedReader().readText() }
                val err = async { p.errorStream.bufferedReader().readText() }
                val code = p.waitFor()
                ShellResult(code, out.await(), err.await())
            }
        } catch (e: Throwable) {
            ShellResult(-1, "", "Shizuku error: ${e.cause?.message ?: e.message}")
        }
    }

    suspend fun execAll(cmds: List<String>) = exec(cmds.joinToString("; "))

    suspend fun forceStop(pkg: String) = exec("am force-stop $pkg")
}

object DisplayController {
    private fun hz(v: Int) = listOf(
        "settings put system peak_refresh_rate $v",
        "settings put system min_refresh_rate $v",
        "settings put system refresh_rate $v"
    )

    suspend fun apply(g: GameConfig) = ShizukuHelper.execAll(
        listOf("wm size ${g.width}x${g.height}", "wm density ${g.dpi}") + hz(g.hz)
    )

    suspend fun restore(s: AppSettings) = ShizukuHelper.execAll(
        listOf("wm size reset", "wm density reset") + hz(s.defHz)
    )
}
