package com.gamehelper.resolution

import android.app.Application
import com.google.android.material.color.DynamicColors

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        DynamicColors.applyToActivitiesIfAvailable(this) // Material You trên Android 12+, còn lại dùng palette trong themes.xml
    }
}
