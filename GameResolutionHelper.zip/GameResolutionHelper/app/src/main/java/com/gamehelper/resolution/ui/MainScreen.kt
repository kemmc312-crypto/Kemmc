package com.gamehelper.resolution.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gamehelper.resolution.data.AppSettings
import com.gamehelper.resolution.data.AppStore

enum class Tab(val label: String, val icon: ImageVector) {
    Home("Trang chủ", Icons.Rounded.Home),
    Games("Game", Icons.Rounded.SportsEsports),
    Music("Nhạc", Icons.Rounded.MusicNote),
    Settings("Cài đặt", Icons.Rounded.Settings)
}

@Composable
fun MainScreen() {
    val settings by AppStore.settings.collectAsStateWithLifecycle()
    var tabIndex by rememberSaveable { mutableIntStateOf(0) }
    val tab = Tab.entries[tabIndex]

    BackHandler(enabled = tabIndex != 0) { tabIndex = 0 }

    CompositionLocalProvider(LocalGlass provides settings.glassEnabled) {
        Box(Modifier.fillMaxSize()) {
            AppBackground(settings)

            Scaffold(
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.onBackground,
                bottomBar = {
                    NavigationBar(
                        containerColor = if (settings.glassEnabled) Color.Black.copy(alpha = 0.55f)
                        else MaterialTheme.colorScheme.surfaceContainer
                    ) {
                        Tab.entries.forEach { t ->
                            NavigationBarItem(
                                selected = t == tab,
                                onClick = { tabIndex = t.ordinal },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = Color.White,
                                    unselectedIconColor = Color.White.copy(alpha = 0.5f),
                                    unselectedTextColor = Color.White.copy(alpha = 0.5f),
                                    indicatorColor = Color.White.copy(alpha = 0.14f)
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = {
                        val dir = if (targetState.ordinal > initialState.ordinal) 1 else -1
                        (slideInHorizontally(tween(320)) { full -> full / 4 * dir } + fadeIn(tween(320)))
                            .togetherWith(
                                slideOutHorizontally(tween(320)) { full -> -full / 4 * dir } + fadeOut(tween(200))
                            )
                    },
                    label = "tab-transition",
                    modifier = Modifier.fillMaxSize()
                ) { current ->
                    when (current) {
                        Tab.Home -> HomeScreen(padding)
                        Tab.Games -> GamesScreen(padding)
                        Tab.Music -> MusicScreen(padding)
                        Tab.Settings -> SettingsScreen(padding)
                    }
                }
            }
        }
    }
}

/** Nền: gradient mặc định, hoặc Live Video Background (có lớp tối để chữ dễ đọc). */
@Composable
private fun AppBackground(settings: AppSettings) {
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF000000), Color(0xFF0C0C0C), Color(0xFF1A1A1A))
                )
            )
    )
    if (settings.videoBgEnabled && settings.videoUri.isNotBlank()) {
        VideoBackground(
            uri = settings.videoUri,
            audioEnabled = settings.videoAudioEnabled,
            volume = settings.videoVolume,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.38f))
        )
    }
}
