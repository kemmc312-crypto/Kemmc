package com.gamehelper.resolution.core

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import com.gamehelper.resolution.service.GameWatcherService
import com.gamehelper.resolution.shizuku.ShizukuHelper

data class PermState(
    val shizuku: ShizukuHelper.State,
    val accessibility: Boolean,
    val overlay: Boolean
) {
    val grantedCount get() = listOf(shizuku == ShizukuHelper.State.READY, accessibility, overlay).count { it }
    val allGranted get() = grantedCount == 3
}

object PermissionChecker {
    fun check(c: Context) = PermState(ShizukuHelper.state(), isAccessibilityEnabled(c), Settings.canDrawOverlays(c))

    fun isAccessibilityEnabled(c: Context): Boolean {
        val enabled = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(c, GameWatcherService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }
}
