package com.gamehelper.resolution

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: AppSettings,
    onSave: (AppSettings) -> Unit,
    onResetNow: () -> Unit,
    onBack: () -> Unit
) {
    var w by remember { mutableStateOf(settings.defWidth.toString()) }
    var h by remember { mutableStateOf(settings.defHeight.toString()) }
    var dpi by remember { mutableStateOf(settings.defDpi.toString()) }
    var hz by remember { mutableStateOf(settings.defHz.toString()) }
    var delay by remember { mutableStateOf(settings.delayMs.toString()) }
    var clean by remember { mutableStateOf(settings.cleanRam) }
    var floating by remember { mutableStateOf(settings.showFloating) }

    fun save() = onSave(
        AppSettings(
            w.toIntOrNull() ?: settings.defWidth, h.toIntOrNull() ?: settings.defHeight,
            dpi.toIntOrNull() ?: settings.defDpi, hz.toIntOrNull() ?: settings.defHz,
            clean, floating, delay.toLongOrNull() ?: settings.delayMs
        )
    )

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Cài đặt") },
            navigationIcon = {
                IconButton(onClick = { save(); onBack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Hiển thị gốc của máy", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("Default Width", w, { w = it }, Modifier.weight(1f))
                NumField("Default Height", h, { h = it }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("DPI gốc", dpi, { dpi = it }, Modifier.weight(1f))
                NumField("Hz gốc", hz, { hz = it }, Modifier.weight(1f))
            }
            HorizontalDivider()
            SwitchRow("Dọn RAM trước khi vào game (am force-stop)", clean) { clean = it }
            SwitchRow("Hiện nút nổi khi chạy game", floating) { floating = it }
            NumField("Delay mặc định (ms) trước khi mở game", delay, { delay = it }, Modifier.fillMaxWidth())
            HorizontalDivider()
            Button(onClick = { save() }, modifier = Modifier.fillMaxWidth()) { Text("Lưu cài đặt") }
            OutlinedButton(onClick = { save(); onResetNow() }, modifier = Modifier.fillMaxWidth()) {
                Text("Khôi phục hiển thị ngay")
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}
