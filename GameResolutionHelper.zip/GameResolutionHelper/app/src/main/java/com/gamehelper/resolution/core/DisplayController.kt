package com.gamehelper.resolution.core

import com.gamehelper.resolution.data.GameConfig
import com.gamehelper.resolution.shizuku.ShizukuHelper
import com.gamehelper.resolution.shizuku.ShizukuHelper.ShellResult

object DisplayController {
    // Lưu ý: khóa refresh rate khác nhau tùy hãng (Samsung/Xiaomi/Oppo có thể dùng khóa riêng).
    private fun hz(v: Int) = "settings put system min_refresh_rate $v; settings put system peak_refresh_rate $v"

    suspend fun apply(c: GameConfig): ShellResult {
        val cmds = mutableListOf<String>()
        if (c.width > 0 && c.height > 0) cmds += "wm size ${c.width}x${c.height}"
        if (c.gameDpi > 0) cmds += "wm density ${c.gameDpi}"
        if (c.gameHz > 0) cmds += hz(c.gameHz)
        return if (cmds.isEmpty()) ShellResult(0, "") else ShizukuHelper.exec(cmds.joinToString("; "))
    }

    /** c = null: khôi phục khẩn cấp (reset size/density, xóa khóa Hz). */
    suspend fun restore(c: GameConfig?): ShellResult {
        val cmds = mutableListOf("wm size reset")
        cmds += if ((c?.defaultDpi ?: 0) > 0) "wm density ${c!!.defaultDpi}" else "wm density reset"
        cmds += if ((c?.defaultHz ?: 0) > 0) hz(c!!.defaultHz)
        else "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
        return ShizukuHelper.exec(cmds.joinToString("; "))
    }
}
