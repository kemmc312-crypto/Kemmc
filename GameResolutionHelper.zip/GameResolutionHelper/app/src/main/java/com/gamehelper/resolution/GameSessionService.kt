package com.gamehelper.resolution

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

/**
 * Chạy theo yêu cầu (Play / Shortcut). Không chạy nền khi không có phiên game.
 * Trình tự: dọn RAM -> đổi hiển thị -> nút nổi -> delay -> mở game.
 */
class GameSessionService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var floating: FloatingButton? = null
    private var currentPkg: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val pkg = intent?.getStringExtra(EXTRA_PKG)
        startAsForeground(pkg ?: "")
        if (pkg == null) { stopSelf(); return START_NOT_STICKY }
        job?.cancel()
        floating?.hide()
        currentPkg = pkg
        job = scope.launch { runSession(pkg) }
        return START_NOT_STICKY
    }

    private suspend fun runSession(pkg: String) {
        val repo = Repo(this)
        val settings = repo.loadSettings()
        val game = repo.loadGames().firstOrNull { it.packageName == pkg }
        if (game == null) { toast("Không tìm thấy cấu hình game"); stopSelf(); return }
        if (ShizukuHelper.state() != ShizukuState.READY) {
            toast("Shizuku chưa chạy hoặc chưa cấp quyền"); stopSelf(); return
        }
        // Bước 1: dọn RAM
        if (settings.cleanRam) ShizukuHelper.forceStop(pkg)
        // Bước 2: đổi độ phân giải / DPI / Hz
        val r = DisplayController.apply(game)
        if (r.code != 0) toast("Lỗi đổi hiển thị: ${r.text.take(120)}")
        // Bước 3: nút nổi
        if (settings.showFloating) {
            if (Settings.canDrawOverlays(this)) {
                floating = FloatingButton(this) { onFloatingTap(pkg, settings) }.also { it.show() }
            } else toast("Chưa cấp quyền hiển thị trên ứng dụng khác")
        }
        // Bước 4: chờ
        delay(game.effectiveDelay(settings))
        // Bước 5: mở game
        launchGame(pkg)
        if (floating == null) stopSelf() // không có nút nổi -> không cần giữ service
    }

    private fun launchGame(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent == null) { toast("Không mở được $pkg"); return }
        try {
            startActivity(intent)
        } catch (_: Throwable) {
            // Dự phòng khi ColorOS chặn mở activity từ nền
            scope.launch { ShizukuHelper.exec("monkey -p $pkg -c android.intent.category.LAUNCHER 1") }
        }
    }

    /** Chạm nút nổi: khôi phục hiển thị + force-stop game song song, rồi ẩn nút. */
    private fun onFloatingTap(pkg: String, settings: AppSettings) {
        scope.launch {
            coroutineScope {
                launch { DisplayController.restore(settings) }
                launch { ShizukuHelper.forceStop(pkg) }
            }
            floating?.hide(); floating = null
            stopSelf()
        }
    }

    private fun startAsForeground(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Game session", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("GameResolutionHelper")
            .setContentText(text)
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, n, type)
    }

    private fun toast(msg: String) = Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        floating?.hide()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_PKG = "pkg"
        private const val CHANNEL = "session"
        fun start(ctx: Context, pkg: String) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, GameSessionService::class.java).putExtra(EXTRA_PKG, pkg)
            )
        }
    }
}
