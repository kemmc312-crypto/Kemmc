package com.gamehelper.resolution.ui

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.fragment.app.Fragment
import com.gamehelper.resolution.R
import com.gamehelper.resolution.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val vm: MainViewModel by viewModels()

    private val onBinder = Shizuku.OnBinderReceivedListener { vm.refresh() }
    private val onDead = Shizuku.OnBinderDeadListener { vm.refresh() }
    private val onPermResult = Shizuku.OnRequestPermissionResultListener { _, _ -> vm.refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.updatePadding(top = bars.top, left = bars.left, right = bars.right)
            insets
        }

        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPermResult)

        b.nav.setOnItemSelectedListener { item ->
            val f: Fragment = when (item.itemId) {
                R.id.nav_home -> HomeFragment()
                R.id.nav_games -> GamesFragment()
                R.id.nav_terminal -> TerminalFragment()
                R.id.nav_scripts -> ScriptsFragment()
                else -> return@setOnItemSelectedListener false
            }
            show(f); true
        }
        b.nav.setOnItemReselectedListener { }

        if (savedInstanceState == null) {
            // Mở app: kiểm tra quyền ngay và đưa người dùng về màn hình hướng dẫn cấp quyền
            vm.refresh()
            show(HomeFragment())
            if (!vm.state.value.allGranted) {
                b.root.post {
                    Snackbar.make(b.container, "Cần cấp đủ 3 quyền để ứng dụng hoạt động", Snackbar.LENGTH_LONG)
                        .setAnchorView(b.nav).show()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh() // quay lại từ màn hình Cài đặt -> cập nhật trạng thái quyền
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPermResult)
        super.onDestroy()
    }

    private fun show(f: Fragment) {
        supportFragmentManager.beginTransaction().replace(R.id.container, f).commit()
    }
}
