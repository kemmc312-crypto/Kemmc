package com.gamehelper.resolution.ui

import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.transition.MaterialFadeThrough

fun Fragment.useFadeThrough() {
    enterTransition = MaterialFadeThrough()
    exitTransition = MaterialFadeThrough()
}

fun Fragment.snack(msg: String) {
    view?.let { Snackbar.make(it, msg, Snackbar.LENGTH_LONG).show() }
}
