package com.gamehelper.resolution

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Cài đặt chung. delayMs = thời gian chờ mặc định trước khi mở game. */
data class AppSettings(
    val defWidth: Int = 1080,
    val defHeight: Int = 2400,
    val defDpi: Int = 480,
    val defHz: Int = 120,
    val cleanRam: Boolean = true,
    val showFloating: Boolean = true,
    val delayMs: Long = 3000
)

/** Cấu hình riêng từng game. delayMs < 0 nghĩa là dùng delay mặc định. */
data class GameConfig(
    val packageName: String,
    val displayName: String,
    val width: Int,
    val height: Int,
    val dpi: Int,
    val hz: Int,
    val delayMs: Long = -1
) {
    fun effectiveDelay(s: AppSettings) = if (delayMs >= 0) delayMs else s.delayMs
}

data class InstalledApp(val packageName: String, val label: String)

enum class ShizukuState { NOT_RUNNING, NO_PERMISSION, READY }

class Repo(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("grh", Context.MODE_PRIVATE)

    fun loadSettings() = AppSettings(
        defWidth = sp.getInt("w", 1080),
        defHeight = sp.getInt("h", 2400),
        defDpi = sp.getInt("dpi", 480),
        defHz = sp.getInt("hz", 120),
        cleanRam = sp.getBoolean("clean", true),
        showFloating = sp.getBoolean("float", true),
        delayMs = sp.getLong("delay", 3000)
    )

    fun saveSettings(s: AppSettings) = sp.edit()
        .putInt("w", s.defWidth).putInt("h", s.defHeight)
        .putInt("dpi", s.defDpi).putInt("hz", s.defHz)
        .putBoolean("clean", s.cleanRam).putBoolean("float", s.showFloating)
        .putLong("delay", s.delayMs).apply()

    fun loadGames(): List<GameConfig> = runCatching {
        val arr = JSONArray(sp.getString("games", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            GameConfig(
                o.getString("pkg"), o.getString("name"),
                o.getInt("w"), o.getInt("h"), o.getInt("dpi"), o.getInt("hz"),
                o.optLong("delay", -1)
            )
        }
    }.getOrDefault(emptyList())

    fun saveGames(list: List<GameConfig>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("pkg", it.packageName).put("name", it.displayName)
                .put("w", it.width).put("h", it.height).put("dpi", it.dpi)
                .put("hz", it.hz).put("delay", it.delayMs))
        }
        sp.edit().putString("games", arr.toString()).apply()
    }
}
