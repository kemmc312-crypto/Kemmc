package com.gamehelper.resolution

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    vm: MainViewModel,
    onOpenSettings: () -> Unit,
    onPlay: (GameConfig) -> Unit,
    onShortcut: (GameConfig) -> Unit,
    onGrantShizuku: () -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<GameConfig?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<GameConfig?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("GameResolutionHelper") },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Cài đặt")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = {}, label = { Text("Games") }, alwaysShowLabel = true)
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = {}, label = { Text("Terminal") }, alwaysShowLabel = true)
            }
        },
        floatingActionButton = {
            if (tab == 0) FloatingActionButton(onClick = { adding = true }) {
                Icon(Icons.Default.Add, contentDescription = "Thêm game")
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            ShizukuBanner(vm.shizuku, onGrantShizuku, vm::refreshShizuku)
            if (tab == 0) GameList(vm, onPlay, onShortcut, { editing = it }, { deleting = it })
            else TerminalTab(vm)
        }
    }

    if (adding) GameEditDialog(null, vm.settings, vm.installed, vm::loadInstalled, { adding = false }) {
        vm.saveGame(it, null); adding = false
    }
    editing?.let { g ->
        GameEditDialog(g, vm.settings, vm.installed, vm::loadInstalled, { editing = null }) {
            vm.saveGame(it, g.packageName); editing = null
        }
    }
    deleting?.let { g ->
        ConfirmDeleteDialog(g.displayName, { deleting = null }) { vm.deleteGame(g); deleting = null }
    }
}

@Composable
private fun ShizukuBanner(state: ShizukuState, onGrant: () -> Unit, onRefresh: () -> Unit) {
    if (state == ShizukuState.READY) return
    Card(
        Modifier.fillMaxWidth().padding(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (state == ShizukuState.NOT_RUNNING) {
                Text("Shizuku chưa chạy. Hãy mở app Shizuku và khởi động (Wireless debugging).")
                TextButton(onClick = onRefresh) { Text("Kiểm tra lại") }
            } else {
                Text("Chưa cấp quyền Shizuku cho ứng dụng.")
                Button(onClick = onGrant) { Text("Cấp quyền") }
            }
        }
    }
}

@Composable
private fun GameList(
    vm: MainViewModel,
    onPlay: (GameConfig) -> Unit,
    onShortcut: (GameConfig) -> Unit,
    onEdit: (GameConfig) -> Unit,
    onDelete: (GameConfig) -> Unit
) {
    if (vm.games.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp)) {
            Text("Chưa có game. Nhấn + để thêm.", style = MaterialTheme.typography.bodyLarge)
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(12.dp, 8.dp, 12.dp, 88.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(vm.games, key = { it.packageName }) { g ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(g.displayName, style = MaterialTheme.typography.titleMedium)
                    Text(g.packageName, style = MaterialTheme.typography.bodySmall)
                    val d = if (g.delayMs >= 0) "${g.delayMs}ms" else "mặc định"
                    Text("${g.width}x${g.height} · ${g.dpi}dpi · ${g.hz}Hz · delay $d",
                        style = MaterialTheme.typography.bodyMedium)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        OutlinedButton(onClick = { onShortcut(g) }) { Text("Create Shortcut") }
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { onPlay(g) }) {
                            Icon(Icons.Default.PlayArrow, null); Text("Play")
                        }
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = { onEdit(g) }) { Icon(Icons.Default.Edit, "Sửa") }
                        IconButton(onClick = { onDelete(g) }) { Icon(Icons.Default.Delete, "Xóa") }
                    }
                }
            }
        }
    }
}

@Composable
private fun TerminalTab(vm: MainViewModel) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(vm.terminal.size) {
        if (vm.terminal.isNotEmpty()) listState.animateScrollToItem(vm.terminal.lastIndex)
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
            items(vm.terminal.size) { i ->
                Text(vm.terminal[i], fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), singleLine = true,
                placeholder = { Text("wm size / termux python x.py") }
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.runTerminal(input); input = "" }) { Text("Run") }
        }
    }
}
