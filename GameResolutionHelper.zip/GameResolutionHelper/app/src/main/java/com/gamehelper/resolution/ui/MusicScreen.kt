package com.gamehelper.resolution.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.FilledIconToggleButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gamehelper.resolution.formatTime
import com.gamehelper.resolution.termux.DownloadKind
import com.gamehelper.resolution.termux.MusicController
import com.gamehelper.resolution.termux.TermuxBridge
import com.gamehelper.resolution.toast
import kotlinx.coroutines.delay

private enum class MusicMode(val label: String) { Library("Thư viện"), Download("Tải media") }

@Composable
fun MusicScreen(padding: PaddingValues) {
    val ctx = LocalContext.current
    val st by MusicController.state.collectAsStateWithLifecycle()
    var mode by remember { mutableStateOf(MusicMode.Library) }
    var permTick by remember { mutableLongStateOf(0L) }

    val installed = remember(permTick) { TermuxBridge.isInstalled(ctx) }
    val permitted = remember(permTick) { TermuxBridge.hasPermission(ctx) }

    val permLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { permTick++ }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 16.dp, end = 16.dp,
            top = padding.calculateTopPadding() + 12.dp,
            bottom = padding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text("Nhạc & Tải media", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Điều khiển mpv · ffprobe · yt-dlp trong Termux",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f)
                )
            }
        }

        // Điều kiện cần của Termux
        item {
            AnimatedVisibility(visible = !installed || !permitted, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                GlassCard {
                    SectionTitle("Cần thiết lập Termux")
                    Text(
                        if (!installed) "Chưa cài Termux (nên dùng bản F-Droid / GitHub, không phải Play Store)."
                        else "Chưa cấp quyền chạy lệnh Termux cho app.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(8.dp))
                    if (installed && !permitted) {
                        Button(onClick = { permLauncher.launch(TermuxBridge.PERMISSION) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Cấp quyền RUN_COMMAND")
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    Text(
                        "Trong Termux, chạy lần lượt:\n" +
                                "1) termux-setup-storage\n" +
                                "2) pkg install mpv ffmpeg yt-dlp\n" +
                                "3) mkdir -p ~/.termux && echo \"allow-external-apps = true\" >> ~/.termux/termux.properties\n" +
                                "Rồi đóng hẳn và mở lại Termux.",
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // Trạng thái + cài gói
        item {
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SectionTitle("Trạng thái")
                        Text(st.status.ifBlank { "Sẵn sàng" }, style = MaterialTheme.typography.bodyMedium)
                    }
                    OutlinedButton(
                        onClick = { MusicController.installPackages(ctx) },
                        enabled = installed && permitted && !st.busy
                    ) { Text("Cài mpv/yt-dlp") }
                }
                if (st.busy || st.scanning) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
        }

        // Bộ điều khiển phát
        item {
            AnimatedVisibility(visible = st.nowPlaying != null, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                PlayerCard()
            }
        }

        // Chuyển chế độ
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MusicMode.entries.forEach { m ->
                    if (m == mode) {
                        Button(onClick = { mode = m }, modifier = Modifier.weight(1f)) { Text(m.label) }
                    } else {
                        FilledTonalButton(onClick = { mode = m }, modifier = Modifier.weight(1f)) { Text(m.label) }
                    }
                }
            }
        }

        if (mode == MusicMode.Library) {
            item { LibraryHeader(enabled = installed && permitted) }
            itemsIndexed(st.files, key = { _, p -> p }) { index, path ->
                val playing = st.nowPlaying == path
                GlassCard(onClick = { MusicController.playIndex(ctx, index) }, modifier = Modifier) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${index + 1}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                path.substringAfterLast('/'),
                                fontWeight = if (playing) FontWeight.Bold else FontWeight.Normal,
                                color = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                maxLines = 2, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                path.substringBeforeLast('/'),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        } else {
            item { DownloadSection(enabled = installed && permitted && !st.busy) }
            if (st.log.isNotBlank()) {
                item {
                    GlassCard {
                        SectionTitle("Nhật ký")
                        SelectionContainer {
                            Text(
                                st.log, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryHeader(enabled: Boolean) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val st by MusicController.state.collectAsStateWithLifecycle()

    GlassCard {
        SectionTitle("Thư viện (Download · Music · Movies · DCIM)")
        Text(
            "mp3 · mp4 · mkv · webm · m4a · aac · flac",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = { MusicController.scan(ctx) }, enabled = enabled && !st.scanning, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.Search, null)
            Spacer(Modifier.width(8.dp))
            Text("Quét file media")
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                label = { Text("Nhập tên (hoặc 1 phần tên) để phát") },
                singleLine = true, modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            FilledTonalButton(
                enabled = enabled && query.isNotBlank(),
                onClick = {
                    val hit = st.files.firstOrNull { it.substringAfterLast('/').contains(query.trim(), ignoreCase = true) }
                    if (hit != null) MusicController.playSingle(ctx, hit)
                    else ctx.toast(
                        if (st.files.isEmpty()) "Hãy quét file trước" else "Không tìm thấy file nào chứa “${query.trim()}”",
                        long = true
                    )
                }
            ) { Text("Phát") }
        }
        if (st.files.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text("${st.files.size} file. Chạm vào một file để phát.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun PlayerCard() {
    val ctx = LocalContext.current
    val st by MusicController.state.collectAsStateWithLifecycle()

    // Đồng hồ cập nhật mỗi giây (tương đương vòng lặp 1s trong show_player_control của music.py)
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(st.nowPlaying, st.playing) {
        while (st.playing) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    val elapsed = ((now - st.startMs).coerceAtLeast(0)) / 1000.0
    val dur = st.durationSec
    val pos = if (dur > 0) (if (st.loop) elapsed % dur else minOf(elapsed, dur)) else elapsed
    val remaining = if (dur > 0) dur - pos else 0.0

    // Hết bài khi không lặp
    LaunchedEffect(elapsed, dur, st.loop) {
        if (dur > 0 && !st.loop && elapsed >= dur + 1) MusicController.markFinished()
    }

    GlassCard {
        SectionTitle("Điều khiển & đếm thời gian")
        Text(
            st.nowPlaying?.substringAfterLast('/') ?: "",
            style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (dur > 0) "${formatTime(pos)} / ${formatTime(dur)}  (Còn lại: ${formatTime(remaining)})"
            else "${formatTime(pos)} / Đang phát…",
            fontFamily = FontFamily.Monospace
        )
        if (dur > 0) {
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(progress = { (pos / dur).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        }
        Text(
            if (st.single) "📌 Phát 1 file cố định" else "Playlist",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
        )
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledTonalIconButton(onClick = { MusicController.previous(ctx) }, enabled = !st.single) {
                Icon(Icons.Rounded.SkipPrevious, "Trước")
            }
            FilledIconToggleButton(checked = st.loop, onCheckedChange = { MusicController.toggleLoop(ctx) }) {
                Icon(Icons.Rounded.Repeat, "Lặp vô hạn")
            }
            FilledTonalIconButton(onClick = { MusicController.next(ctx) }, enabled = !st.single) {
                Icon(Icons.Rounded.SkipNext, "Sau")
            }
            Button(onClick = { MusicController.stop(ctx) }) {
                Icon(Icons.Rounded.Stop, null)
                Spacer(Modifier.width(4.dp))
                Text("Dừng")
            }
        }
        Text(
            "Lặp vô hạn: ${if (st.loop) "BẬT (--loop=inf)" else "TẮT"}",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
private fun DownloadSection(enabled: Boolean) {
    val ctx = LocalContext.current
    var ytUrl by remember { mutableStateOf("") }
    var ttUrl by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        GlassCard {
            SectionTitle("YouTube")
            OutlinedTextField(
                value = ytUrl, onValueChange = { ytUrl = it },
                label = { Text("Dán link YouTube") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { MusicController.download(ctx, DownloadKind.YOUTUBE_VIDEO, ytUrl) },
                    enabled = enabled && ytUrl.isNotBlank(), modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Download, null)
                    Spacer(Modifier.width(4.dp))
                    Text("Video MP4")
                }
                FilledTonalButton(
                    onClick = { MusicController.download(ctx, DownloadKind.YOUTUBE_MP3, ytUrl) },
                    enabled = enabled && ytUrl.isNotBlank(), modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Download, null)
                    Spacer(Modifier.width(4.dp))
                    Text("Chỉ MP3")
                }
            }
        }
        GlassCard {
            SectionTitle("TikTok (sạch logo)")
            OutlinedTextField(
                value = ttUrl, onValueChange = { ttUrl = it },
                label = { Text("Dán link TikTok") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { MusicController.download(ctx, DownloadKind.TIKTOK, ttUrl) },
                enabled = enabled && ttUrl.isNotBlank(), modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.Download, null)
                Spacer(Modifier.width(4.dp))
                Text("Tải video không watermark")
            }
            Text(
                "File lưu vào /sdcard/Download.",
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp),
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}
