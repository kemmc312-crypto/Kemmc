package com.gamehelper.resolution.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gamehelper.resolution.shizuku.ShizukuHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Giữ log terminal khi chuyển tab / xoay màn hình. */
class TerminalViewModel : ViewModel() {
    private val _log = MutableStateFlow("")
    val log: StateFlow<String> = _log.asStateFlow()
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private var process: Process? = null
    private var job: Job? = null

    private fun append(s: String) = _log.update { (it + s).takeLast(60_000) }

    fun run(raw: String) {
        if (_running.value) return
        val cmd = raw.trim().replace(Regex("^adb\\s+shell\\s+"), "")
        if (cmd.isEmpty()) return
        append("$ $cmd\n")
        if (ShizukuHelper.state() != ShizukuHelper.State.READY) {
            append("⚠ Shizuku chưa sẵn sàng (chưa chạy hoặc chưa cấp quyền).\n\n"); return
        }
        _running.value = true
        job = viewModelScope.launch {
            try {
                val code = ShizukuHelper.stream(cmd, { process = it }) { append(it + "\n") }
                append("[exit $code]\n\n")
            } catch (t: Throwable) {
                append("Lỗi: ${t.message}\n\n")
            } finally {
                process = null
                _running.value = false
            }
        }
    }

    fun stop() { process?.destroy() }
    fun clear() { _log.value = "" }
}
