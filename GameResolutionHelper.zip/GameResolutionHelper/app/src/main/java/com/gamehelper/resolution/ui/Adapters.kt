package com.gamehelper.resolution.ui

import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.gamehelper.resolution.R
import com.gamehelper.resolution.data.GameConfig
import com.gamehelper.resolution.databinding.ItemAppBinding
import com.gamehelper.resolution.databinding.ItemGameBinding
import com.gamehelper.resolution.databinding.ItemScriptBinding
import java.io.File

// ---------- Games ----------
class GameAdapter(
    private val onToggle: (GameConfig, Boolean) -> Unit,
    private val onEdit: (GameConfig) -> Unit,
    private val onDelete: (GameConfig) -> Unit
) : ListAdapter<GameConfig, GameAdapter.VH>(object : DiffUtil.ItemCallback<GameConfig>() {
    override fun areItemsTheSame(a: GameConfig, b: GameConfig) = a.packageName == b.packageName
    override fun areContentsTheSame(a: GameConfig, b: GameConfig) = a == b
}) {
    class VH(val b: ItemGameBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(ItemGameBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val c = getItem(pos)
        val pm = h.b.root.context.packageManager
        h.b.imgIcon.setImageDrawable(try { pm.getApplicationIcon(c.packageName) } catch (_: Exception) { null })
        h.b.txtName.text = c.label
        h.b.txtPkg.text = c.packageName
        h.b.txtSummary.text = "${c.width}×${c.height} · ${c.gameDpi}dpi · ${c.gameHz}Hz · chờ ${c.delaySec}s"
        h.b.root.animate().alpha(if (c.enabled) 1f else 0.55f).setDuration(200).start()
        h.b.swEnabled.setOnCheckedChangeListener(null)
        h.b.swEnabled.isChecked = c.enabled
        h.b.swEnabled.setOnCheckedChangeListener { _, on -> onToggle(c, on) }
        h.b.root.setOnClickListener { onEdit(c) }
        h.b.btnDelete.setOnClickListener { onDelete(c) }
    }
}

// ---------- App picker ----------
data class AppItem(val label: String, val packageName: String)

class AppAdapter(private val pm: PackageManager, private val onPick: (AppItem) -> Unit) :
    RecyclerView.Adapter<AppAdapter.VH>() {
    class VH(val b: ItemAppBinding) : RecyclerView.ViewHolder(b.root)

    private var all: List<AppItem> = emptyList()
    private var shown: List<AppItem> = emptyList()

    fun setData(list: List<AppItem>) { all = list; shown = list; notifyDataSetChanged() }
    fun filter(q: String) {
        val s = q.trim().lowercase()
        shown = if (s.isEmpty()) all else all.filter { it.label.lowercase().contains(s) || it.packageName.contains(s) }
        notifyDataSetChanged()
    }

    override fun getItemCount() = shown.size
    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(ItemAppBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun onBindViewHolder(h: VH, pos: Int) {
        val a = shown[pos]
        h.b.imgIcon.setImageDrawable(try { pm.getApplicationIcon(a.packageName) } catch (_: Exception) { null })
        h.b.txtName.text = a.label
        h.b.txtPkg.text = a.packageName
        h.b.root.setOnClickListener { onPick(a) }
    }
}

// ---------- Scripts ----------
data class ScriptItem(val file: File, val running: Boolean)

class ScriptAdapter(
    private val onToggle: (ScriptItem) -> Unit,
    private val onDelete: (ScriptItem) -> Unit
) : ListAdapter<ScriptItem, ScriptAdapter.VH>(object : DiffUtil.ItemCallback<ScriptItem>() {
    override fun areItemsTheSame(a: ScriptItem, b: ScriptItem) = a.file.absolutePath == b.file.absolutePath
    override fun areContentsTheSame(a: ScriptItem, b: ScriptItem) = a == b
}) {
    class VH(val b: ItemScriptBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(ItemScriptBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val it = getItem(pos)
        h.b.txtName.text = it.file.name
        h.b.txtStatus.text = if (it.running) "Đang chạy" else "Đã dừng · ${it.file.length() / 1024 + 1} KB"
        h.b.progress.isVisible = it.running
        h.b.btnToggle.text = if (it.running) "Tắt" else "Bật"
        h.b.btnToggle.setIconResource(if (it.running) R.drawable.ic_stop else R.drawable.ic_play)
        h.b.btnToggle.setOnClickListener { _ -> onToggle(it) }
        h.b.btnDelete.setOnClickListener { _ -> onDelete(it) }
    }
}
