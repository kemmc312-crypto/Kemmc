package com.gamehelper.resolution.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import com.gamehelper.resolution.core.DisplayController
import com.gamehelper.resolution.data.GameConfig
import com.gamehelper.resolution.data.GameRepository
import com.gamehelper.resolution.shizuku.ShizukuHelper
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class GameWatcherService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val displayLock = Mutex()          // đảm bảo lệnh apply/restore chạy tuần tự
    private var pending: Job? = null
    private var currentGame: GameConfig? = null
    private var applied = false
    private var dismissedPkg: String? = null   // game vừa bấm nút nổi để thoát -> không áp lại tới khi rời game
    private var ignored: Set<String> = emptySet()
    private lateinit var fab: FloatingButton

    override fun onServiceConnected() {
        super.onServiceConnected()
        fab = FloatingButton(this) { onFabClicked() }
        ignored = buildSet {
            add(packageName)
            getSystemService(InputMethodManager::class.java).enabledInputMethodList.forEach { add(it.packageName) }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg in ignored || pkg.startsWith("com.android.systemui")) return
        onForeground(pkg)
    }

    private fun onForeground(pkg: String) {
        val cfg = GameRepository.find(this, pkg)?.takeIf { it.enabled }
        if (cfg == null) {                       // đã rời game (về launcher / mở app khác)
            dismissedPkg = null
            if (currentGame != null) leaveGame(forceRestore = false)
            return
        }
        if (pkg == dismissedPkg) return
        if (currentGame?.packageName == pkg) return
        if (currentGame != null) leaveGame(forceRestore = false) // chuyển thẳng từ game này sang game khác
        startGame(cfg)
    }

    private fun startGame(cfg: GameConfig) {
        currentGame = cfg
        applied = false
        fab.show()
        pending = scope.launch {
            delay(cfg.delaySec * 1000L)          // Game Load Delay: chờ game qua màn hình logo
            if (ShizukuHelper.state() != ShizukuHelper.State.READY) {
                toast("Shizuku chưa sẵn sàng - không thể đổi cấu hình"); return@launch
            }
            withContext(NonCancellable) {
                val r = displayLock.withLock { DisplayController.apply(cfg) }
                if (!r.ok) toast("Lỗi áp cấu hình: ${r.output}")
                if (currentGame === cfg) applied = true
                else displayLock.withLock { DisplayController.restore(cfg) } // đã rời game trong lúc đang áp
            }
        }
    }

    private fun leaveGame(forceRestore: Boolean) {
        pending?.cancel(); pending = null
        val cfg = currentGame
        val wasApplied = applied
        currentGame = null; applied = false
        fab.hide()
        if (cfg != null && (wasApplied || forceRestore)) restoreAsync(cfg)
    }

    private fun restoreAsync(cfg: GameConfig?) {
        scope.launch { displayLock.withLock { DisplayController.restore(cfg) } }
    }

    private fun onFabClicked() {
        val cfg = currentGame ?: return
        dismissedPkg = cfg.packageName
        leaveGame(forceRestore = true)
        toast("Đã khôi phục độ phân giải gốc")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onInterrupt() {}

    override fun onDestroy() {
        val cfg = currentGame
        if (cfg != null && applied) CoroutineScope(Dispatchers.IO).launch { DisplayController.restore(cfg) }
        if (::fab.isInitialized) fab.hide()
        scope.cancel()
        super.onDestroy()
    }
}
