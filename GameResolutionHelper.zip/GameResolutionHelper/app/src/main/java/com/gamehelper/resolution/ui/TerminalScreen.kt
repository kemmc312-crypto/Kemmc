package com.gamehelper.resolution.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gamehelper.resolution.shizuku.ShizukuHelper
import com.gamehelper.resolution.termux.TermuxBridge
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class ShellTarget(val label: String) { Shizuku("Shizuku (shell)"), Termux("Termux") }

private data class Line(val text: String, val kind: Int) // 0 = lệnh, 1 = kết quả, 2 = lỗi, 3 = thông tin

/** Terminal cơ bản: gõ và chạy lệnh thủ công qua Shizuku hoặc Termux. */
@Composable
fun TerminalScreen(padding: PaddingValues) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val shizuku by ShizukuHelper.status.collectAsStateWithLifecycle()

    var target by remember { mutableStateOf(ShellTarget.Shizuku) }
    var input by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    val lines = remember {
        mutableStateListOf(
            Line("Terminal cơ bản. Chọn Shizuku (quyền shell) hoặc Termux rồi gõ lệnh.", 3),
            Line("Ví dụ: wm size   |   settings get system peak_refresh_rate   |   dumpsys battery", 3)
        )
    }
    val history = remember { mutableStateListOf<String>() }
    var histPos by remember { mutableStateOf(-1) }
    val listState = rememberLazyListState()

    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.animateScrollToItem(lines.lastIndex)
    }

    fun append(text: String, kind: Int) {
        text.lines().forEach { lines.add(Line(it, kind)) }
        while (lines.size > 600) lines.removeAt(0)
    }

    fun run() {
        val cmd = input.trim()
        if (cmd.isEmpty() || running) return
        input = ""
        histPos = -1
        history.add(cmd)
        val prompt = if (target == ShellTarget.Shizuku) "shizuku$ " else "termux$ "
        append(prompt + cmd, 0)

        if (cmd == "clear") {
            lines.clear()
            return
        }

        running = true
        when (target) {
            ShellTarget.Shizuku -> scope.launch {
                val r = withContext(Dispatchers.IO) {
                    ShizukuHelper.awaitReady(1500)
                    ShizukuHelper.exec(cmd)
                }
                if (r.out.isNotBlank()) append(r.out, 1)
                if (r.err.isNotBlank()) append(r.err, 2)
                if (r.out.isBlank() && r.err.isBlank()) append("(exit ${r.code})", 3)
                running = false
            }
            ShellTarget.Termux -> {
                val sent = TermuxBridge.run(ctx, cmd) { r ->
                    if (r.stdout.isNotBlank()) append(r.stdout.trimEnd(), 1)
                    if (r.stderr.isNotBlank()) append(r.stderr.trimEnd(), 2)
                    r.error?.let { e -> append(e, 2) }
                    if (r.stdout.isBlank() && r.stderr.isBlank() && r.error == null) append("(exit ${r.exitCode ?: 0})", 3)
                    running = false
                }
                if (!sent) running = false
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(
                start = 16.dp, end = 16.dp,
                top = padding.calculateTopPadding() + 12.dp,
                bottom = padding.calculateBottomPadding() + 8.dp
            )
    ) {
        Text("Terminal", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Row(
            Modifier.padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ShellTarget.entries.forEach { t ->
                FilterChip(selected = target == t, onClick = { target = t }, label = { Text(t.label) })
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { lines.clear() }) { Icon(Icons.Rounded.DeleteSweep, "Xóa màn hình") }
        }

        if (target == ShellTarget.Shizuku && shizuku != ShizukuHelper.Status.READY) {
            Text(
                "Shizuku chưa sẵn sàng — lệnh sẽ thất bại.",
                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall
            )
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.Black.copy(alpha = 0.72f))
                .padding(12.dp)
        ) {
            SelectionContainer {
                LazyColumn(state = listState) {
                    items(lines.size) { i ->
                        val l = lines[i]
                        Text(
                            l.text,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.5.sp,
                            lineHeight = 17.sp,
                            color = when (l.kind) {
                                0 -> Color(0xFF6EE7B7)
                                2 -> Color(0xFFFF8A80)
                                3 -> Color(0xFF93C5FD)
                                else -> Color(0xFFE8ECF8)
                            }
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Nhập lệnh…") },
                textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { run() })
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = { run() }, enabled = !running && input.isNotBlank()) {
                Icon(Icons.Rounded.Send, "Chạy")
            }
        }
        if (history.isNotEmpty()) {
            Row(
                Modifier.padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = false,
                    onClick = {
                        histPos = if (histPos < 0) history.lastIndex else (histPos - 1).coerceAtLeast(0)
                        input = history[histPos]
                    },
                    label = { Text("↑ Lệnh trước") }
                )
            }
        }
    }
}
