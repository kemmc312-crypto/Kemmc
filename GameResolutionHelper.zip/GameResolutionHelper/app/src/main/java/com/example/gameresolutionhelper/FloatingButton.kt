package com.example.gameresolutionhelper

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs

/**
 * Nút nổi kéo thả (SYSTEM_ALERT_WINDOW). Chạm = onTap, kéo = di chuyển.
 * Kích thước tính theo [densityDpi] của game vì lúc này màn hình đã bị đổi density.
 */
class FloatingButton(
    private val context: Context,
    private val densityDpi: Int,
    private val onTap: () -> Unit,
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: View? = null

    private fun px(dp: Int): Int = (dp * densityDpi / 160f).toInt().coerceAtLeast(1)

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (view != null) return
        val size = px(52)

        val tv = TextView(context).apply {
            text = "↺"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, px(26).toFloat())
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE6D32F2F.toInt())
                setStroke(px(2), 0x66FFFFFF)
            }
        }

        val lp = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = px(12)
            y = px(160)
        }

        val slop = ViewConfiguration.get(context).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false

        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging) {
                        val (sw, sh) = screenSize()
                        lp.x = (startX + dx).toInt().coerceIn(0, (sw - size).coerceAtLeast(0))
                        lp.y = (startY + dy).toInt().coerceIn(0, (sh - size).coerceAtLeast(0))
                        runCatching { wm.updateViewLayout(v, lp) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) onTap()
                    true
                }
                else -> false
            }
        }

        wm.addView(tv, lp)
        view = tv
    }

    fun hide() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }
}
