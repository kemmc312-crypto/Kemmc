package com.example.gameresolutionhelper

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState { NOT_RUNNING, NO_PERMISSION, READY }

data class ShellResult(val code: Int, val output: String) {
    val ok: Boolean
        get() = code == 0 &&
            !output.startsWith("error", ignoreCase = true) &&
            !output.contains("exception", ignoreCase = true)
}

object ShizukuHelper {
    const val REQUEST_CODE = 1001
    private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"

    fun state(): ShizukuState {
        val alive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        if (!alive) return ShizukuState.NOT_RUNNING
        if (runCatching { Shizuku.isPreV11() }.getOrDefault(true)) return ShizukuState.NOT_RUNNING
        val granted = runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        return if (granted) ShizukuState.READY else ShizukuState.NO_PERMISSION
    }

    /** @return false nếu người dùng đã chọn "từ chối và không hỏi lại" (phải cấp trong app Shizuku). */
    fun requestPermission(): Boolean = runCatching {
        if (Shizuku.shouldShowRequestPermissionRationale()) {
            false
        } else {
            Shizuku.requestPermission(REQUEST_CODE)
            true
        }
    }.getOrDefault(false)

    fun openShizukuApp(ctx: Context): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE) ?: return false
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}

object ShizukuShell {
    // Shizuku.newProcess() là private từ API 13 -> gọi bằng reflection (cách phổ biến, vẫn hoạt động).
    private val newProcessMethod by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java,
        ).apply { isAccessible = true }
    }

    suspend fun exec(command: String): ShellResult = withContext(Dispatchers.IO) {
        try {
            val process = newProcessMethod.invoke(
                null,
                arrayOf("sh", "-c", "($command) 2>&1"),
                null,
                null,
            ) as Process
            val out = process.inputStream.bufferedReader().use { it.readText() }
            val code = process.waitFor()
            ShellResult(code, out.trim())
        } catch (t: Throwable) {
            val root = t.cause ?: t
            ShellResult(-1, "Error: ${root.message ?: root.javaClass.simpleName}")
        }
    }
}

object DisplayController {

    suspend fun cleanRam(mode: CleanMode, packageName: String): ShellResult = when (mode) {
        CleanMode.FORCE_STOP_GAME ->
            if (packageName.isValidPackageName()) ShizukuShell.exec("am force-stop $packageName")
            else ShellResult(-1, "Error: package không hợp lệ")
        CleanMode.KILL_ALL -> ShizukuShell.exec("am kill-all")
    }

    /** Áp dụng độ phân giải/DPI/Hz của game. Trả về danh sách lỗi (rỗng = thành công). */
    suspend fun apply(game: GameConfig): List<String> {
        val errors = mutableListOf<String>()
        suspend fun run(cmd: String) {
            val r = ShizukuShell.exec(cmd)
            if (!r.ok) errors += "$cmd → ${r.output.ifBlank { "exit ${r.code}" }}"
        }
        if (game.width > 0 && game.height > 0) run("wm size ${game.width}x${game.height}")
        if (game.dpi > 0) run("wm density ${game.dpi}")
        if (game.hz > 0) {
            run("settings put system min_refresh_rate ${game.hz}")
            run("settings put system peak_refresh_rate ${game.hz}")
        }
        return errors
    }

    /** Khôi phục: wm size reset, wm density reset, và Hz (nếu phiên trước có đổi Hz). */
    suspend fun reset(settings: AppSettings, resetHz: Boolean): List<String> {
        val errors = mutableListOf<String>()
        suspend fun run(cmd: String) {
            val r = ShizukuShell.exec(cmd)
            if (!r.ok) errors += "$cmd → ${r.output.ifBlank { "exit ${r.code}" }}"
        }
        run("wm size reset")
        run("wm density reset")
        if (resetHz) {
            if (settings.defaultHz > 0) {
                run("settings put system peak_refresh_rate ${settings.defaultHz}")
                run("settings put system min_refresh_rate 0")
            } else {
                run("settings delete system peak_refresh_rate")
                run("settings delete system min_refresh_rate")
            }
        }
        return errors
    }

    /** Mở game bằng quyền shell (không bị giới hạn khởi chạy Activity từ nền). */
    suspend fun launchGame(ctx: Context, packageName: String): ShellResult {
        val component = ctx.packageManager.getLaunchIntentForPackage(packageName)?.component
            ?: return ShellResult(-1, "Error: không tìm thấy Activity khởi chạy của $packageName")
        return ShizukuShell.exec(
            "am start -n '${component.flattenToShortString()}' " +
                "-a android.intent.action.MAIN -c android.intent.category.LAUNCHER",
        )
    }
}
