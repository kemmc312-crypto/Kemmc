package com.example.gameresolutionhelper

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class CleanMode { FORCE_STOP_GAME, KILL_ALL }

data class AppSettings(
    val defaultWidth: Int = 0,
    val defaultHeight: Int = 0,
    val defaultDpi: Int = 0,
    val defaultHz: Int = 0,
    val cleanRam: Boolean = true,
    val cleanMode: CleanMode = CleanMode.FORCE_STOP_GAME,
    val defaultDelaySec: Int = 3,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("defaultWidth", defaultWidth)
        put("defaultHeight", defaultHeight)
        put("defaultDpi", defaultDpi)
        put("defaultHz", defaultHz)
        put("cleanRam", cleanRam)
        put("cleanMode", cleanMode.name)
        put("defaultDelaySec", defaultDelaySec)
    }

    companion object {
        fun fromJson(o: JSONObject) = AppSettings(
            defaultWidth = o.optInt("defaultWidth"),
            defaultHeight = o.optInt("defaultHeight"),
            defaultDpi = o.optInt("defaultDpi"),
            defaultHz = o.optInt("defaultHz"),
            cleanRam = o.optBoolean("cleanRam", true),
            cleanMode = runCatching { CleanMode.valueOf(o.optString("cleanMode")) }
                .getOrDefault(CleanMode.FORCE_STOP_GAME),
            defaultDelaySec = o.optInt("defaultDelaySec", 3),
        )
    }
}

data class GameConfig(
    val id: String = UUID.randomUUID().toString(),
    val packageName: String,
    val displayName: String,
    val width: Int = 0,
    val height: Int = 0,
    val dpi: Int = 0,
    val hz: Int = 0,
    /** null = dùng delay mặc định trong Settings */
    val delaySec: Int? = null,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("packageName", packageName)
        put("displayName", displayName)
        put("width", width)
        put("height", height)
        put("dpi", dpi)
        put("hz", hz)
        if (delaySec != null) put("delaySec", delaySec)
    }

    companion object {
        fun fromJson(o: JSONObject) = GameConfig(
            id = o.getString("id"),
            packageName = o.getString("packageName"),
            displayName = o.optString("displayName"),
            width = o.optInt("width"),
            height = o.optInt("height"),
            dpi = o.optInt("dpi"),
            hz = o.optInt("hz"),
            delaySec = if (o.has("delaySec") && !o.isNull("delaySec")) o.getInt("delaySec") else null,
        )
    }
}

fun String.isValidPackageName(): Boolean =
    Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+\$").matches(trim())

class Store(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("grh_store", Context.MODE_PRIVATE)

    fun settings(): AppSettings =
        sp.getString(KEY_SETTINGS, null)
            ?.let { runCatching { AppSettings.fromJson(JSONObject(it)) }.getOrNull() }
            ?: AppSettings()

    fun saveSettings(s: AppSettings) {
        sp.edit().putString(KEY_SETTINGS, s.toJson().toString()).apply()
    }

    fun games(): List<GameConfig> {
        val raw = sp.getString(KEY_GAMES, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { GameConfig.fromJson(arr.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    fun saveGames(list: List<GameConfig>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        sp.edit().putString(KEY_GAMES, arr.toString()).apply()
    }

    /** Đã ghi đè Hz trong phiên gần nhất chưa (để biết có cần reset Hz không). */
    var hzApplied: Boolean
        get() = sp.getBoolean(KEY_HZ_APPLIED, false)
        set(v) {
            sp.edit().putBoolean(KEY_HZ_APPLIED, v).apply()
        }

    private companion object {
        const val KEY_SETTINGS = "settings"
        const val KEY_GAMES = "games"
        const val KEY_HZ_APPLIED = "hz_applied"
    }
}
