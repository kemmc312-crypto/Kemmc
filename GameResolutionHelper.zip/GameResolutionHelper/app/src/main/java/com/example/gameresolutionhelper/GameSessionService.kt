package com.example.gameresolutionhelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Chạy 1 phiên chơi game (dùng chung cho nút Play và Shortcut):
 * dọn RAM -> đổi độ phân giải -> hiện nút nổi -> chờ delay -> mở game.
 * Chạm nút nổi (hoặc nút "Khôi phục" trên thông báo) -> reset toàn bộ và tự tắt.
 */
class GameSessionService : Service() {

    companion object {
        const val ACTION_START = "com.example.gameresolutionhelper.START"
        const val ACTION_RESTORE = "com.example.gameresolutionhelper.RESTORE"
        const val EXTRA_GAME_ID = "game_id"
        private const val CHANNEL_ID = "session"
        private const val NOTIF_ID = 42
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var store: Store
    private var sessionJob: Job? = null
    private var overlay: FloatingButton? = null
    private var restoring = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        store = Store(this)
        val channel = NotificationChannel(
            CHANNEL_ID, "Phiên chơi game", NotificationManager.IMPORTANCE_LOW,
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground("Đang chuẩn bị…")
        val action = intent?.action
        val gameId = intent?.getStringExtra(EXTRA_GAME_ID)
        when (action) {
            ACTION_START -> {
                val game = store.games().firstOrNull { it.id == gameId }
                if (game == null) {
                    toast("Không tìm thấy cấu hình game (có thể đã bị xóa)")
                    stopSelf()
                } else {
                    startSession(game)
                }
            }
            ACTION_RESTORE -> restoreAndStop()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startSession(game: GameConfig) {
        if (restoring) {
            toast("Đang khôi phục màn hình, hãy thử lại sau giây lát")
            return
        }
        sessionJob?.cancel()
        overlay?.hide()
        overlay = null

        sessionJob = scope.launch {
            val settings = store.settings()

            if (ShizukuHelper.state() != ShizukuState.READY) {
                toast("Shizuku chưa chạy hoặc chưa cấp quyền")
                stopSelf()
                return@launch
            }
            if (!Settings.canDrawOverlays(this@GameSessionService)) {
                toast("Chưa cấp quyền hiển thị trên ứng dụng khác")
                stopSelf()
                return@launch
            }

            // 1) Dọn RAM
            if (settings.cleanRam) {
                notify("Đang dọn RAM…")
                DisplayController.cleanRam(settings.cleanMode, game.packageName)
            }

            // 2) Đổi độ phân giải / DPI / Hz
            notify("Đang đổi độ phân giải…")
            if (game.hz > 0) store.hzApplied = true
            val errors = DisplayController.apply(game)
            if (errors.isNotEmpty()) {
                toast("Lỗi khi đổi màn hình:\n" + errors.joinToString("\n"))
                restoreAndStop()
                return@launch
            }

            // 3) Hiện nút nổi (trước khi chờ delay để luôn có lối thoát)
            val density = game.dpi.takeIf { it > 0 }
                ?: settings.defaultDpi.takeIf { it > 0 }
                ?: resources.displayMetrics.densityDpi
            overlay = FloatingButton(this@GameSessionService, density) { restoreAndStop() }
                .also { it.show() }

            // 4) Chờ delay
            val delaySec = (game.delaySec ?: settings.defaultDelaySec).coerceAtLeast(0)
            if (delaySec > 0) {
                notify("Mở ${game.displayName} sau $delaySec giây… (chạm ↺ để hủy & khôi phục)")
                delay(delaySec * 1000L)
            }

            // 5) Mở game
            val result = DisplayController.launchGame(this@GameSessionService, game.packageName)
            if (!result.ok) {
                toast("Không mở được game: ${result.output}")
                restoreAndStop()
                return@launch
            }
            notify("Đang chơi ${game.displayName} — chạm nút ↺ để khôi phục màn hình")
        }
    }

    private fun restoreAndStop() {
        if (restoring) return
        restoring = true
        sessionJob?.cancel()
        overlay?.hide()
        overlay = null
        notify("Đang khôi phục…")
        scope.launch {
            val errors = DisplayController.reset(store.settings(), store.hzApplied)
            store.hzApplied = false
            toast(
                if (errors.isEmpty()) "Đã khôi phục màn hình gốc"
                else "Khôi phục có lỗi:\n" + errors.joinToString("\n"),
            )
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        overlay?.hide()
        scope.cancel()
        super.onDestroy()
    }

    // ---- helpers ----

    private fun startAsForeground(text: String) {
        ServiceCompat.startForeground(
            this,
            NOTIF_ID,
            buildNotification(text),
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0,
        )
    }

    private fun notify(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val restore = PendingIntent.getService(
            this, 1,
            Intent(this, GameSessionService::class.java).setAction(ACTION_RESTORE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_rotate)
            .setContentTitle("Game Resolution Helper")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, "Khôi phục", restore)
            .build()
    }

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
    }
}

/** Điểm vào duy nhất để bắt đầu 1 phiên: dùng bởi nút Play và LaunchActivity (Shortcut). */
object SessionLauncher {
    fun start(ctx: Context, gameId: String): Boolean {
        if (ShizukuHelper.state() != ShizukuState.READY) {
            Toast.makeText(ctx, "Shizuku chưa chạy hoặc chưa cấp quyền", Toast.LENGTH_LONG).show()
            return false
        }
        if (!Settings.canDrawOverlays(ctx)) {
            Toast.makeText(ctx, "Hãy cấp quyền hiển thị trên ứng dụng khác trước", Toast.LENGTH_LONG).show()
            return false
        }
        val i = Intent(ctx, GameSessionService::class.java)
            .setAction(GameSessionService.ACTION_START)
            .putExtra(GameSessionService.EXTRA_GAME_ID, gameId)
        ContextCompat.startForegroundService(ctx, i)
        return true
    }

    fun restore(ctx: Context) {
        val i = Intent(ctx, GameSessionService::class.java)
            .setAction(GameSessionService.ACTION_RESTORE)
        ContextCompat.startForegroundService(ctx, i)
    }
}
