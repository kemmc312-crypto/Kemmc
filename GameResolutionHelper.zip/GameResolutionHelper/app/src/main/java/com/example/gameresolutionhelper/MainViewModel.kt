package com.example.gameresolutionhelper

import android.app.Application
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.net.Uri
import android.provider.Settings
import android.view.Display
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import kotlin.math.roundToInt

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)

    private val _settings = MutableStateFlow(store.settings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _games = MutableStateFlow(store.games())
    val games: StateFlow<List<GameConfig>> = _games.asStateFlow()

    private val _shizuku = MutableStateFlow(ShizukuHelper.state())
    val shizuku: StateFlow<ShizukuState> = _shizuku.asStateFlow()

    private val _overlay = MutableStateFlow(Settings.canDrawOverlays(app))
    val overlayGranted: StateFlow<Boolean> = _overlay.asStateFlow()

    private val _terminal = MutableStateFlow<List<String>>(emptyList())
    val terminal: StateFlow<List<String>> = _terminal.asStateFlow()

    private val _shellBusy = MutableStateFlow(false)
    val shellBusy: StateFlow<Boolean> = _shellBusy.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events.asSharedFlow()

    private val onBinderReceived = Shizuku.OnBinderReceivedListener { refreshStatus() }
    private val onBinderDead = Shizuku.OnBinderDeadListener { refreshStatus() }
    private val onPermissionResult =
        Shizuku.OnRequestPermissionResultListener { _, _ -> refreshStatus() }

    init {
        Shizuku.addBinderReceivedListenerSticky(onBinderReceived)
        Shizuku.addBinderDeadListener(onBinderDead)
        Shizuku.addRequestPermissionResultListener(onPermissionResult)
    }

    override fun onCleared() {
        Shizuku.removeBinderReceivedListener(onBinderReceived)
        Shizuku.removeBinderDeadListener(onBinderDead)
        Shizuku.removeRequestPermissionResultListener(onPermissionResult)
    }

    private fun emit(msg: String) {
        _events.tryEmit(msg)
    }

    // ---- trạng thái quyền ----

    fun refreshStatus() {
        _shizuku.value = ShizukuHelper.state()
        _overlay.value = Settings.canDrawOverlays(getApplication<Application>())
    }

    fun shizukuAction(ctx: Context) {
        when (_shizuku.value) {
            ShizukuState.NOT_RUNNING ->
                if (!ShizukuHelper.openShizukuApp(ctx)) {
                    emit("Chưa cài Shizuku. Hãy cài và khởi động Shizuku (Wireless debugging hoặc root).")
                }
            ShizukuState.NO_PERMISSION ->
                if (!ShizukuHelper.requestPermission()) {
                    emit("Hãy cấp quyền thủ công trong app Shizuku → Authorized apps.")
                }
            ShizukuState.READY -> Unit
        }
    }

    fun openOverlaySettings(ctx: Context) {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }

    // ---- settings ----

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        _settings.update(transform)
        store.saveSettings(_settings.value)
    }

    /** Đọc độ phân giải/DPI gốc qua Shizuku và Hz hiện tại của màn hình. */
    fun detectDefaults() {
        viewModelScope.launch {
            if (_shizuku.value != ShizukuState.READY) {
                emit("Cần bật Shizuku và cấp quyền trước")
                return@launch
            }
            val size = ShizukuShell.exec("wm size").output
            val density = ShizukuShell.exec("wm density").output
            val m = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(size)
            val d = Regex("Physical density:\\s*(\\d+)").find(density)
            val dm = getApplication<Application>().getSystemService(DisplayManager::class.java)
            val hz = dm.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate?.roundToInt()
            updateSettings { s ->
                s.copy(
                    defaultWidth = m?.groupValues?.get(1)?.toIntOrNull() ?: s.defaultWidth,
                    defaultHeight = m?.groupValues?.get(2)?.toIntOrNull() ?: s.defaultHeight,
                    defaultDpi = d?.groupValues?.get(1)?.toIntOrNull() ?: s.defaultDpi,
                    defaultHz = hz ?: s.defaultHz,
                )
            }
            emit("Đã lấy thông số từ máy")
        }
    }

    // ---- games ----

    fun newGameTemplate(): GameConfig {
        val s = _settings.value
        return GameConfig(
            packageName = "",
            displayName = "",
            width = s.defaultWidth,
            height = s.defaultHeight,
            dpi = s.defaultDpi,
            hz = s.defaultHz,
        )
    }

    fun isNewGame(id: String) = _games.value.none { it.id == id }

    fun saveGame(g: GameConfig) {
        _games.update { list ->
            if (list.any { it.id == g.id }) list.map { if (it.id == g.id) g else it } else list + g
        }
        store.saveGames(_games.value)
    }

    fun deleteGame(id: String) {
        _games.update { list -> list.filterNot { it.id == id } }
        store.saveGames(_games.value)
    }

    fun play(ctx: Context, g: GameConfig) {
        SessionLauncher.start(ctx, g.id)
    }

    fun createShortcut(ctx: Context, g: GameConfig) {
        val err = ShortcutHelper.pin(ctx, g)
        if (err != null) emit(err) else emit("Hãy xác nhận thêm lối tắt trên màn hình chính")
    }

    fun restoreNow(ctx: Context) {
        SessionLauncher.restore(ctx)
    }

    // ---- terminal ----

    private fun append(line: String) {
        _terminal.update { (it + line).takeLast(300) }
    }

    fun clearTerminal() {
        _terminal.value = emptyList()
    }

    fun runCommand(cmd: String) {
        viewModelScope.launch {
            append("$ $cmd")
            if (_shizuku.value != ShizukuState.READY) {
                append("Shizuku chưa sẵn sàng.")
                return@launch
            }
            _shellBusy.value = true
            val r = ShizukuShell.exec(cmd)
            append(r.output.ifBlank { "(exit ${r.code})" })
            _shellBusy.value = false
        }
    }
}
