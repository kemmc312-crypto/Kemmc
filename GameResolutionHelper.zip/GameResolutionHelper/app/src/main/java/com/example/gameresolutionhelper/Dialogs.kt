package com.example.gameresolutionhelper

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InstalledApp(val label: String, val packageName: String)

@Suppress("DEPRECATION")
private fun loadLaunchableApps(ctx: Context): List<InstalledApp> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .map { InstalledApp(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .filter { it.packageName != ctx.packageName }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun GameEditDialog(
    initial: GameConfig,
    isNew: Boolean,
    onDismiss: () -> Unit,
    onSave: (GameConfig) -> Unit,
) {
    var name by remember { mutableStateOf(initial.displayName) }
    var pkg by remember { mutableStateOf(initial.packageName) }
    var w by remember { mutableStateOf(initial.width.takeIf { it > 0 }) }
    var h by remember { mutableStateOf(initial.height.takeIf { it > 0 }) }
    var dpi by remember { mutableStateOf(initial.dpi.takeIf { it > 0 }) }
    var hz by remember { mutableStateOf(initial.hz.takeIf { it > 0 }) }
    var delay by remember { mutableStateOf(initial.delaySec) }
    var showPicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Thêm game" else "Sửa game") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Chọn từ ứng dụng đã cài")
                }
                OutlinedTextField(
                    value = pkg,
                    onValueChange = { pkg = it.trim() },
                    label = { Text("Package name") },
                    singleLine = true,
                    isError = pkg.isNotEmpty() && !pkg.isValidPackageName(),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Display name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField("Width", w, Modifier.weight(1f)) { w = it }
                    NumberField("Height", h, Modifier.weight(1f)) { h = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField("DPI", dpi, Modifier.weight(1f)) { dpi = it }
                    NumberField("Hz", hz, Modifier.weight(1f)) { hz = it }
                }
                NumberField("Delay riêng (giây)", delay, Modifier.fillMaxWidth()) { delay = it }
                Text(
                    "Để trống Width/Height/DPI/Hz = giữ nguyên giá trị đó. Để trống Delay = dùng delay mặc định.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = pkg.isValidPackageName(),
                onClick = {
                    onSave(
                        initial.copy(
                            packageName = pkg.trim(),
                            displayName = name.trim().ifBlank { pkg.trim() },
                            width = w ?: 0,
                            height = h ?: 0,
                            dpi = dpi ?: 0,
                            hz = hz ?: 0,
                            delaySec = delay,
                        ),
                    )
                },
            ) { Text("Lưu") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } },
    )

    if (showPicker) {
        AppPickerDialog(
            onDismiss = { showPicker = false },
            onPick = { app ->
                pkg = app.packageName
                name = app.label
                showPicker = false
            },
        )
    }
}

@Composable
fun AppPickerDialog(onDismiss: () -> Unit, onPick: (InstalledApp) -> Unit) {
    val ctx = LocalContext.current
    val apps by produceState<List<InstalledApp>?>(initialValue = null) {
        value = withContext(Dispatchers.Default) { loadLaunchableApps(ctx) }
    }
    var query by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chọn ứng dụng") },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Tìm theo tên hoặc package…") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.padding(top = 8.dp))
                val list = apps
                if (list == null) {
                    CircularProgressIndicator()
                } else {
                    val filtered = list.filter {
                        it.label.contains(query, ignoreCase = true) ||
                            it.packageName.contains(query, ignoreCase = true)
                    }
                    LazyColumn(Modifier.heightIn(max = 360.dp)) {
                        items(filtered, key = { it.packageName }) { a ->
                            Column(
                                Modifier.fillMaxWidth().clickable { onPick(a) }.padding(vertical = 8.dp),
                            ) {
                                Text(a.label, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    a.packageName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Đóng") } },
    )
}
