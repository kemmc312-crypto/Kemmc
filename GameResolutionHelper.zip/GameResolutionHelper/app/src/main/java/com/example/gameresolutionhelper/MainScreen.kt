package com.example.gameresolutionhelper

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: MainViewModel, onOpenSettings: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<GameConfig?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Game Resolution Helper") },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
            )
        },
        floatingActionButton = {
            if (tab == 0) {
                FloatingActionButton(onClick = { editing = vm.newGameTemplate() }) {
                    Icon(Icons.Default.Add, contentDescription = "Thêm game")
                }
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Games") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Terminal") })
            }
            if (tab == 0) GamesTab(vm) { editing = it } else TerminalTab(vm)
        }
    }

    editing?.let { g ->
        GameEditDialog(
            initial = g,
            isNew = vm.isNewGame(g.id),
            onDismiss = { editing = null },
            onSave = {
                vm.saveGame(it)
                editing = null
            },
        )
    }
}

@Composable
fun GamesTab(vm: MainViewModel, onEdit: (GameConfig) -> Unit) {
    val ctx = LocalContext.current
    val games by vm.games.collectAsState()
    val settings by vm.settings.collectAsState()
    val shizuku by vm.shizuku.collectAsState()
    val overlay by vm.overlayGranted.collectAsState()
    var pendingDelete by remember { mutableStateOf<GameConfig?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            StatusCard(
                shizuku = shizuku,
                overlay = overlay,
                onShizuku = { vm.shizukuAction(ctx) },
                onOverlay = { vm.openOverlaySettings(ctx) },
            )
        }
        item {
            OutlinedButton(onClick = { vm.restoreNow(ctx) }, modifier = Modifier.fillMaxWidth()) {
                Text("Khôi phục độ phân giải gốc ngay")
            }
        }
        if (games.isEmpty()) {
            item {
                Text(
                    "Chưa có game nào. Bấm nút + để thêm game.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        items(games, key = { it.id }) { g ->
            GameCard(
                game = g,
                defaultDelay = settings.defaultDelaySec,
                onPlay = { vm.play(ctx, g) },
                onShortcut = { vm.createShortcut(ctx, g) },
                onEdit = { onEdit(g) },
                onDelete = { pendingDelete = g },
            )
        }
    }

    pendingDelete?.let { g ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Xóa game?") },
            text = { Text("Xóa \"${g.displayName}\" khỏi danh sách? Lối tắt đã tạo (nếu có) sẽ không còn hoạt động.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteGame(g.id)
                    pendingDelete = null
                }) { Text("Xóa") }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Hủy") } },
        )
    }
}

@Composable
fun StatusCard(
    shizuku: ShizukuState,
    overlay: Boolean,
    onShizuku: () -> Unit,
    onOverlay: () -> Unit,
) {
    if (shizuku == ShizukuState.READY && overlay) {
        Text(
            "✔ Shizuku và quyền hiển thị trên ứng dụng khác đã sẵn sàng",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary,
        )
        return
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusRow(
                ok = shizuku == ShizukuState.READY,
                text = when (shizuku) {
                    ShizukuState.NOT_RUNNING -> "Shizuku chưa chạy"
                    ShizukuState.NO_PERMISSION -> "Chưa cấp quyền Shizuku cho app"
                    ShizukuState.READY -> "Shizuku sẵn sàng"
                },
                action = when (shizuku) {
                    ShizukuState.NOT_RUNNING -> "Mở Shizuku"
                    ShizukuState.NO_PERMISSION -> "Cấp quyền"
                    ShizukuState.READY -> null
                },
                onAction = onShizuku,
            )
            StatusRow(
                ok = overlay,
                text = if (overlay) "Quyền hiển thị trên ứng dụng khác: đã cấp"
                else "Chưa cấp quyền hiển thị trên ứng dụng khác",
                action = if (overlay) null else "Cấp quyền",
                onAction = onOverlay,
            )
        }
    }
}

@Composable
private fun StatusRow(ok: Boolean, text: String, action: String?, onAction: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(if (ok) "✔" else "✖")
        Spacer(Modifier.width(8.dp))
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        if (action != null) TextButton(onClick = onAction) { Text(action) }
    }
}

private fun GameConfig.summary(defaultDelay: Int): String {
    val res = if (width > 0 && height > 0) "${width}×$height" else "độ phân giải giữ nguyên"
    val d = if (dpi > 0) "$dpi dpi" else "dpi giữ nguyên"
    val h = if (hz > 0) "$hz Hz" else "Hz giữ nguyên"
    return "$res • $d • $h • delay ${delaySec ?: defaultDelay}s"
}

@Composable
fun GameCard(
    game: GameConfig,
    defaultDelay: Int,
    onPlay: () -> Unit,
    onShortcut: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(game.displayName, style = MaterialTheme.typography.titleMedium)
                    Text(
                        game.packageName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = "Sửa") }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Xóa") }
            }
            Spacer(Modifier.padding(top = 4.dp))
            Text(game.summary(defaultDelay), style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.padding(top = 8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onShortcut, modifier = Modifier.weight(1f)) {
                    Text("Create Shortcut")
                }
                Button(onClick = onPlay, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Play")
                }
            }
        }
    }
}

@Composable
fun TerminalTab(vm: MainViewModel) {
    val lines by vm.terminal.collectAsState()
    val busy by vm.shellBusy.collectAsState()
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(lines.size) {
        if (lines.isNotEmpty()) listState.animateScrollToItem(lines.lastIndex)
    }

    fun submit() {
        val c = input.trim()
        if (c.isNotEmpty() && !busy) {
            vm.runCommand(c)
            input = ""
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp).imePadding(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("wm size", "wm density", "settings get system peak_refresh_rate").forEach { c ->
                AssistChip(onClick = { input = c }, label = { Text(c) })
            }
        }
        Surface(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = MaterialTheme.shapes.medium,
        ) {
            SelectionContainer {
                LazyColumn(state = listState, contentPadding = PaddingValues(8.dp)) {
                    items(lines.size) { i ->
                        Text(lines[i], fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Lệnh shell, ví dụ: wm size") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { submit() }),
            )
            Button(onClick = { submit() }, enabled = !busy) { Text("Run") }
        }
        TextButton(onClick = { vm.clearTerminal() }) { Text("Xóa màn hình") }
    }
}
