package com.example.gameresolutionhelper

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.SwitchCompat
import androidx.recyclerview.widget.RecyclerView

data class AppItem(val label: String, val pkg: String, val icon: Drawable)

class AppAdapter(
    private val ctx: Context,
    private val onOpenSettings: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var all: List<AppItem> = emptyList()
    private var shown: List<AppItem> = emptyList()
    private var query: String = ""

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.imgIcon)
        val name: TextView = v.findViewById(R.id.tvName)
        val pkg: TextView = v.findViewById(R.id.tvPackage)
        val res: TextView = v.findViewById(R.id.tvRes)
        val toggle: SwitchCompat = v.findViewById(R.id.swEnable)
    }

    fun submit(list: List<AppItem>) {
        all = list
        filter(query)
    }

    fun filter(q: String) {
        query = q.trim()
        shown = if (query.isEmpty()) all else all.filter {
            it.label.contains(query, ignoreCase = true) || it.pkg.contains(query, ignoreCase = true)
        }
        notifyDataSetChanged()
    }

    /** Gọi khi quay lại từ màn hình cài đặt để cập nhật dòng "Độ phân giải". */
    fun refresh() = notifyDataSetChanged()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount(): Int = shown.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = shown[position]
        h.icon.setImageDrawable(item.icon)
        h.name.text = item.label
        h.pkg.text = item.pkg
        h.res.text = Prefs.getResolution(ctx, item.pkg)?.let { "Độ phân giải: $it" }
            ?: "Chưa đặt độ phân giải – bấm vào tên gói để nhập"

        h.toggle.setOnCheckedChangeListener(null)
        h.toggle.isChecked = Prefs.isEnabled(ctx, item.pkg)
        h.toggle.setOnCheckedChangeListener { _, checked ->
            Prefs.setEnabled(ctx, item.pkg, checked)
            if (checked && Prefs.getResolution(ctx, item.pkg) == null) {
                Toast.makeText(ctx, "Bấm vào tên gói để nhập độ phân giải", Toast.LENGTH_LONG).show()
            }
        }

        h.pkg.setOnClickListener { onOpenSettings(item) }
    }
}
