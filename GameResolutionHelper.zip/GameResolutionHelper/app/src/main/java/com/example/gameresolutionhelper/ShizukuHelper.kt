package com.example.gameresolutionhelper

import android.app.Activity
import android.content.pm.PackageManager
import android.widget.Toast
import rikka.shizuku.Shizuku

data class CmdResult(val ok: Boolean, val output: String)

object ShizukuHelper {

    const val MIN_DPI = 72
    const val MAX_DPI = 1000
    const val SIZE_RESET = "wm size reset"
    const val DENSITY_RESET = "wm density reset"

    private val RES_REGEX = Regex("^\\d{3,5}x\\d{3,5}$")

    // Chỉ cho phép đúng các dạng lệnh wm sau -> tránh chèn lệnh lạ vào shell
    private val ALLOWED = Regex("^wm (size (\\d{3,5}x\\d{3,5}|reset)|density (\\d{2,4}|reset))$")

    fun isValidResolution(res: String): Boolean = RES_REGEX.matches(res)
    fun isValidDpi(dpi: Int): Boolean = dpi in MIN_DPI..MAX_DPI

    fun sizeCmd(res: String): String = "wm size $res"
    fun densityCmd(dpi: Int): String = "wm density $dpi"

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        isRunning() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    /** Áp dụng cho game: size và/hoặc density, chạy tuần tự trong một lần gọi shell. */
    fun apply(res: String?, dpi: Int?): CmdResult {
        val cmds = mutableListOf<String>()
        if (res != null) cmds += sizeCmd(res)
        if (dpi != null) cmds += densityCmd(dpi)
        return runCommands(cmds)
    }

    /** Khôi phục thủ công (nút cứu hộ): reset size, density về DPI mặc định (hoặc reset). */
    fun restoreAll(defaultDpi: Int?): CmdResult = runCommands(
        listOf(SIZE_RESET, if (defaultDpi != null) densityCmd(defaultDpi) else DENSITY_RESET)
    )

    /**
     * Chạy nhiều lệnh wm trong 1 lần gọi shell. Dùng ";" thay vì "&&" để lệnh sau vẫn chạy
     * kể cả khi lệnh trước lỗi (quan trọng khi khôi phục).
     */
    fun runCommands(commands: List<String>): CmdResult {
        if (commands.isEmpty()) return CmdResult(true, "")
        if (commands.any { !ALLOWED.matches(it) }) {
            return CmdResult(false, "Lệnh không hợp lệ: ${commands.joinToString()}")
        }
        return exec(commands.joinToString("; "))
    }

    // Shizuku.newProcess là hàm private từ API 13 -> gọi bằng reflection.
    // Tiến trình chạy với quyền shell (uid 2000).
    private val newProcessMethod by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    @Synchronized
    private fun exec(command: String): CmdResult {
        if (!hasPermission()) return CmdResult(false, "Chưa có quyền Shizuku")
        return try {
            val p = newProcessMethod.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            val code = p.waitFor()
            CmdResult(code == 0 && err.isBlank(), (out + err).trim())
        } catch (e: Throwable) {
            CmdResult(false, e.message ?: e.toString())
        }
    }
}

/** Chạy lệnh Shizuku ở luồng nền rồi báo kết quả bằng Toast. */
fun Activity.runShizukuTask(task: () -> CmdResult) {
    if (!ShizukuHelper.hasPermission()) {
        Toast.makeText(this, "Chưa có quyền Shizuku", Toast.LENGTH_SHORT).show()
        return
    }
    Thread {
        val r = task()
        runOnUiThread {
            Toast.makeText(
                this,
                if (r.ok) "Thành công ✓" else "Lỗi: ${r.output}",
                Toast.LENGTH_LONG
            ).show()
        }
    }.start()
}
