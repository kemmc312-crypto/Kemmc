package com.example.gameresolutionhelper

import android.app.Activity
import android.content.pm.PackageManager
import android.widget.Toast
import rikka.shizuku.Shizuku

data class CmdResult(val ok: Boolean, val output: String)

object ShizukuHelper {

    // Chỉ cho phép dạng 314x701 -> tránh chèn lệnh lạ vào shell
    private val RES_REGEX = Regex("^\\d{3,5}x\\d{3,5}$")

    fun isValidResolution(res: String): Boolean = RES_REGEX.matches(res)

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        isRunning() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun setSize(res: String): CmdResult {
        if (!isValidResolution(res)) return CmdResult(false, "Độ phân giải không hợp lệ: $res")
        return exec("wm size $res")
    }

    fun resetSize(): CmdResult = exec("wm size reset")

    // Shizuku.newProcess là hàm private từ API 13 -> gọi bằng reflection (cách đơn giản nhất,
    // không cần AIDL/UserService). Tiến trình chạy với quyền shell (uid 2000).
    private val newProcessMethod by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    @Synchronized
    private fun exec(command: String): CmdResult {
        if (!hasPermission()) return CmdResult(false, "Chưa có quyền Shizuku")
        return try {
            val p = newProcessMethod.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            val code = p.waitFor()
            CmdResult(code == 0, (out + err).trim())
        } catch (e: Throwable) {
            CmdResult(false, e.message ?: e.toString())
        }
    }
}

/** Chạy lệnh Shizuku ở luồng nền rồi báo kết quả bằng Toast. */
fun Activity.runShizukuTask(task: () -> CmdResult) {
    if (!ShizukuHelper.hasPermission()) {
        Toast.makeText(this, "Chưa có quyền Shizuku", Toast.LENGTH_SHORT).show()
        return
    }
    Thread {
        val r = task()
        runOnUiThread {
            Toast.makeText(
                this,
                if (r.ok) "Thành công ✓" else "Lỗi: ${r.output}",
                Toast.LENGTH_LONG
            ).show()
        }
    }.start()
}
