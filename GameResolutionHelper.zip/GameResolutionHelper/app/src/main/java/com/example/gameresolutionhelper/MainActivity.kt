package com.example.gameresolutionhelper

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQ_SHIZUKU = 1001
        private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
    }

    private lateinit var tvShizuku: TextView
    private lateinit var tvAccess: TextView
    private lateinit var etDefaultDpi: EditText
    private lateinit var adapter: AppAdapter

    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refreshStatus() } }
    private val binderReceived =
        Shizuku.OnBinderReceivedListener { runOnUiThread { refreshStatus() } }
    private val binderDead =
        Shizuku.OnBinderDeadListener { runOnUiThread { refreshStatus() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvShizuku = findViewById(R.id.tvShizuku)
        tvAccess = findViewById(R.id.tvAccess)
        etDefaultDpi = findViewById(R.id.etDefaultDpi)

        findViewById<Button>(R.id.btnShizuku).setOnClickListener { requestShizuku() }
        findViewById<Button>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        // Nút cứu hộ: khôi phục size + density ngay lập tức
        findViewById<Button>(R.id.btnReset).setOnClickListener {
            runShizukuTask { ShizukuHelper.restoreAll(Prefs.getDefaultDpi(this)) }
        }

        // Default DPI (màn hình chính / khi thoát game)
        Prefs.getDefaultDpi(this)?.let { etDefaultDpi.setText(it.toString()) }
        findViewById<Button>(R.id.btnSaveDpi).setOnClickListener { saveDefaultDpi() }

        adapter = AppAdapter(this) { item ->
            startActivity(
                Intent(this, ResolutionActivity::class.java)
                    .putExtra(ResolutionActivity.EXTRA_PKG, item.pkg)
                    .putExtra(ResolutionActivity.EXTRA_LABEL, item.label)
            )
        }
        findViewById<RecyclerView>(R.id.rvApps).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                adapter.filter(s?.toString().orEmpty())
            }
        })

        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionListener)

        loadApps()
        refreshStatus()

        // Tự xin quyền Shizuku ngay khi mở app (nếu Shizuku đang chạy mà chưa cấp quyền)
        if (ShizukuHelper.isRunning() && !ShizukuHelper.hasPermission()) requestShizuku()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        adapter.refresh()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun saveDefaultDpi() {
        val txt = etDefaultDpi.text.toString().trim()
        if (txt.isEmpty()) {
            Prefs.setDefaultDpi(this, null)
            Toast.makeText(this, "Đã xóa DPI mặc định (thoát game sẽ dùng wm density reset)", Toast.LENGTH_LONG).show()
            return
        }
        val dpi = txt.toIntOrNull()
        if (dpi == null || !ShizukuHelper.isValidDpi(dpi)) {
            Toast.makeText(
                this,
                "DPI hợp lệ: ${ShizukuHelper.MIN_DPI}–${ShizukuHelper.MAX_DPI}",
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        Prefs.setDefaultDpi(this, dpi)
        Toast.makeText(this, "Đã lưu DPI mặc định: $dpi", Toast.LENGTH_SHORT).show()
    }

    @Suppress("DEPRECATION")
    private fun loadApps() {
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) {
                val pm = packageManager
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val enabled = Prefs.getEnabled(this@MainActivity)
                pm.queryIntentActivities(intent, 0)
                    .map { it.activityInfo.applicationInfo }
                    .distinctBy { it.packageName }
                    .filter { it.packageName != packageName }
                    .map { AppItem(it.loadLabel(pm).toString(), it.packageName, it.loadIcon(pm)) }
                    .sortedWith(
                        compareByDescending<AppItem> { it.pkg in enabled }
                            .thenBy { it.label.lowercase() }
                    )
            }
            adapter.submit(items)
        }
    }

    private fun refreshStatus() {
        val running = ShizukuHelper.isRunning()
        val granted = ShizukuHelper.hasPermission()
        tvShizuku.text = when {
            !running -> "Shizuku: chưa chạy ✗ (hãy mở Shizuku và khởi động)"
            !granted -> "Shizuku: đang chạy, chưa cấp quyền ✗"
            else -> "Shizuku: sẵn sàng ✓"
        }
        tvAccess.text =
            if (isAccessibilityEnabled()) "Trợ năng: đã bật ✓" else "Trợ năng: chưa bật ✗"
    }

    private fun requestShizuku() {
        if (!ShizukuHelper.isRunning()) {
            Toast.makeText(this, "Shizuku chưa chạy. Hãy khởi động Shizuku trước.", Toast.LENGTH_LONG).show()
            packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)?.let { startActivity(it) }
            return
        }
        if (Shizuku.isPreV11()) {
            Toast.makeText(this, "Phiên bản Shizuku quá cũ", Toast.LENGTH_LONG).show()
            return
        }
        if (ShizukuHelper.hasPermission()) {
            refreshStatus()
            return
        }
        if (Shizuku.shouldShowRequestPermissionRationale()) {
            Toast.makeText(
                this,
                "Bạn đã từ chối quyền. Vào Shizuku > Ứng dụng được ủy quyền để cấp lại.",
                Toast.LENGTH_LONG
            ).show()
            packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)?.let { startActivity(it) }
        } else {
            Shizuku.requestPermission(REQ_SHIZUKU)
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = ComponentName(this, GameWatcherService::class.java)
        return enabled.split(':').mapNotNull { ComponentName.unflattenFromString(it) }.any { it == me }
    }
}
