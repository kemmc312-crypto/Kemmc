package com.example.gameresolutionhelper

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Cài đặt") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            Modifier.padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("Thông số gốc của máy", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                NumberField("Width", s.defaultWidth.takeIf { it > 0 }, Modifier.weight(1f)) { v ->
                    vm.updateSettings { it.copy(defaultWidth = v ?: 0) }
                }
                NumberField("Height", s.defaultHeight.takeIf { it > 0 }, Modifier.weight(1f)) { v ->
                    vm.updateSettings { it.copy(defaultHeight = v ?: 0) }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                NumberField("DPI", s.defaultDpi.takeIf { it > 0 }, Modifier.weight(1f)) { v ->
                    vm.updateSettings { it.copy(defaultDpi = v ?: 0) }
                }
                NumberField("Hz", s.defaultHz.takeIf { it > 0 }, Modifier.weight(1f)) { v ->
                    vm.updateSettings { it.copy(defaultHz = v ?: 0) }
                }
            }
            OutlinedButton(onClick = { vm.detectDefaults() }, modifier = Modifier.fillMaxWidth()) {
                Text("Lấy thông số từ máy (cần Shizuku)")
            }
            Text(
                "Nên bấm khi máy đang ở độ phân giải gốc. Hz gốc được dùng để khôi phục tần số quét sau khi chơi.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            HorizontalDivider()

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Dọn RAM trước khi vào game", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Chạy tự động trước khi đổi độ phân giải.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = s.cleanRam,
                    onCheckedChange = { v -> vm.updateSettings { it.copy(cleanRam = v) } },
                )
            }
            if (s.cleanRam) {
                CleanMode.entries.forEach { mode ->
                    val (title, desc) = when (mode) {
                        CleanMode.FORCE_STOP_GAME ->
                            "Force-stop game" to "am force-stop <package> — tắt hẳn tiến trình cũ của game để vào game sạch"
                        CleanMode.KILL_ALL ->
                            "Kill tiến trình nền" to "am kill-all — dọn các tiến trình nền/cached của mọi app"
                    }
                    Row(
                        Modifier.fillMaxWidth().selectable(
                            selected = s.cleanMode == mode,
                            role = Role.RadioButton,
                            onClick = { vm.updateSettings { it.copy(cleanMode = mode) } },
                        ),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = s.cleanMode == mode, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(title, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                desc,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            HorizontalDivider()

            Text("Thời gian chờ", style = MaterialTheme.typography.titleMedium)
            NumberField("Delay mặc định (giây)", s.defaultDelaySec, Modifier.fillMaxWidth()) { v ->
                vm.updateSettings { it.copy(defaultDelaySec = v ?: 0) }
            }
            Text(
                "Số giây chờ sau khi đổi độ phân giải, trước khi mở game. Mỗi game có thể đặt delay riêng.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Ô nhập số nguyên; để trống = null. */
@Composable
fun NumberField(
    label: String,
    value: Int?,
    modifier: Modifier = Modifier,
    onValue: (Int?) -> Unit,
) {
    var text by remember { mutableStateOf(value?.toString() ?: "") }
    // Đồng bộ khi giá trị bị đổi từ bên ngoài (ví dụ nút "Lấy thông số từ máy")
    LaunchedEffect(value) {
        if ((value ?: 0) != (text.toIntOrNull() ?: 0)) text = value?.toString() ?: ""
    }
    OutlinedTextField(
        value = text,
        onValueChange = { raw ->
            val digits = raw.filter { it.isDigit() }.take(6)
            text = digits
            onValue(digits.toIntOrNull())
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier,
    )
}
