package com.example.gameresolutionhelper

import android.content.Context
import android.content.SharedPreferences

/** Lưu danh sách game bật toggle, độ phân giải + DPI riêng cho từng game, và DPI mặc định. */
object Prefs {
    private const val FILE = "game_resolution_prefs"
    private const val KEY_ENABLED = "enabled_packages"
    private const val KEY_DEFAULT_DPI = "default_dpi"
    private const val RES_PREFIX = "res_"
    private const val DPI_PREFIX = "dpi_"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ----- Danh sách game đã bật toggle -----
    fun getEnabled(ctx: Context): Set<String> =
        sp(ctx).getStringSet(KEY_ENABLED, emptySet())?.toSet() ?: emptySet()

    fun isEnabled(ctx: Context, pkg: String): Boolean = pkg in getEnabled(ctx)

    fun setEnabled(ctx: Context, pkg: String, enabled: Boolean) {
        val set = getEnabled(ctx).toMutableSet()
        if (enabled) set.add(pkg) else set.remove(pkg)
        sp(ctx).edit().putStringSet(KEY_ENABLED, set).apply()
    }

    // ----- Độ phân giải riêng cho từng game: dạng "314x701" hoặc null -----
    fun getResolution(ctx: Context, pkg: String): String? =
        sp(ctx).getString(RES_PREFIX + pkg, null)

    fun setResolution(ctx: Context, pkg: String, res: String?) {
        val e = sp(ctx).edit()
        if (res == null) e.remove(RES_PREFIX + pkg) else e.putString(RES_PREFIX + pkg, res)
        e.apply()
    }

    // ----- Game DPI (wm density khi vào game), null = không đổi -----
    fun getGameDpi(ctx: Context, pkg: String): Int? =
        sp(ctx).getInt(DPI_PREFIX + pkg, -1).takeIf { it > 0 }

    fun setGameDpi(ctx: Context, pkg: String, dpi: Int?) {
        val e = sp(ctx).edit()
        if (dpi == null) e.remove(DPI_PREFIX + pkg) else e.putInt(DPI_PREFIX + pkg, dpi)
        e.apply()
    }

    // ----- Default DPI (màn hình chính / khi thoát game), null = dùng wm density reset -----
    fun getDefaultDpi(ctx: Context): Int? =
        sp(ctx).getInt(KEY_DEFAULT_DPI, -1).takeIf { it > 0 }

    fun setDefaultDpi(ctx: Context, dpi: Int?) {
        val e = sp(ctx).edit()
        if (dpi == null) e.remove(KEY_DEFAULT_DPI) else e.putInt(KEY_DEFAULT_DPI, dpi)
        e.apply()
    }
}
