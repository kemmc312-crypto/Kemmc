package com.example.gameresolutionhelper

import android.content.Context
import android.content.SharedPreferences

/** Lưu danh sách game bật toggle + độ phân giải riêng cho từng game. */
object Prefs {
    private const val FILE = "game_resolution_prefs"
    private const val KEY_ENABLED = "enabled_packages"
    private const val RES_PREFIX = "res_"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getEnabled(ctx: Context): Set<String> =
        sp(ctx).getStringSet(KEY_ENABLED, emptySet())?.toSet() ?: emptySet()

    fun isEnabled(ctx: Context, pkg: String): Boolean = pkg in getEnabled(ctx)

    fun setEnabled(ctx: Context, pkg: String, enabled: Boolean) {
        val set = getEnabled(ctx).toMutableSet()
        if (enabled) set.add(pkg) else set.remove(pkg)
        sp(ctx).edit().putStringSet(KEY_ENABLED, set).apply()
    }

    /** Trả về dạng "314x701" hoặc null nếu chưa đặt. */
    fun getResolution(ctx: Context, pkg: String): String? =
        sp(ctx).getString(RES_PREFIX + pkg, null)

    fun setResolution(ctx: Context, pkg: String, res: String?) {
        val e = sp(ctx).edit()
        if (res == null) e.remove(RES_PREFIX + pkg) else e.putString(RES_PREFIX + pkg, res)
        e.apply()
    }
}
