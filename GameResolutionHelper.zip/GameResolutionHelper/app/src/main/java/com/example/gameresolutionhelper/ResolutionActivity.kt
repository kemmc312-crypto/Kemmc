package com.example.gameresolutionhelper

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Màn hình nhập độ phân giải riêng cho từng game. */
class ResolutionActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PKG = "extra_pkg"
        const val EXTRA_LABEL = "extra_label"
    }

    private lateinit var pkg: String
    private lateinit var etW: EditText
    private lateinit var etH: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resolution)

        val p = intent.getStringExtra(EXTRA_PKG)
        if (p == null) {
            finish()
            return
        }
        pkg = p
        val label = intent.getStringExtra(EXTRA_LABEL) ?: pkg

        title = label
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        findViewById<TextView>(R.id.tvAppName).text = label
        findViewById<TextView>(R.id.tvPkg).text = pkg

        etW = findViewById(R.id.etWidth)
        etH = findViewById(R.id.etHeight)

        // Nạp lại giá trị đã lưu (ví dụ "314x701")
        Prefs.getResolution(this, pkg)?.split("x")?.takeIf { it.size == 2 }?.let {
            etW.setText(it[0])
            etH.setText(it[1])
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val res = readInput(true) ?: return@setOnClickListener
            Prefs.setResolution(this, pkg, res)
            Toast.makeText(this, "Đã lưu $res cho $label", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnTest).setOnClickListener {
            val res = readInput(true) ?: return@setOnClickListener
            Prefs.setResolution(this, pkg, res)
            runShizukuTask { ShizukuHelper.setSize(res) }
        }

        findViewById<Button>(R.id.btnRestore).setOnClickListener {
            runShizukuTask { ShizukuHelper.resetSize() }
        }
    }

    /** Trả về "WxH" hợp lệ hoặc null. */
    private fun readInput(showError: Boolean): String? {
        val w = etW.text.toString().trim().toIntOrNull()
        val h = etH.text.toString().trim().toIntOrNull()
        if (w == null || h == null || w !in 200..10000 || h !in 200..10000) {
            if (showError) {
                Toast.makeText(this, "Nhập chiều rộng và chiều cao hợp lệ (200–10000)", Toast.LENGTH_SHORT).show()
            }
            return null
        }
        return "${w}x$h"
    }

    // Tự lưu khi thoát màn hình (nếu số liệu hợp lệ)
    override fun onPause() {
        super.onPause()
        if (::pkg.isInitialized) {
            readInput(false)?.let { Prefs.setResolution(this, pkg, it) }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
