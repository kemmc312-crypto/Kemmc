package com.example.gameresolutionhelper

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

private data class Parsed(val res: String?, val dpi: Int?)

/** Màn hình cài đặt riêng cho từng game: độ phân giải (Size) và Game DPI. */
class ResolutionActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PKG = "extra_pkg"
        const val EXTRA_LABEL = "extra_label"
    }

    private lateinit var pkg: String
    private lateinit var etW: EditText
    private lateinit var etH: EditText
    private lateinit var etGameDpi: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resolution)

        val p = intent.getStringExtra(EXTRA_PKG)
        if (p == null) {
            finish()
            return
        }
        pkg = p
        val label = intent.getStringExtra(EXTRA_LABEL) ?: pkg

        title = label
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        findViewById<TextView>(R.id.tvAppName).text = label
        findViewById<TextView>(R.id.tvPkg).text = pkg

        etW = findViewById(R.id.etWidth)
        etH = findViewById(R.id.etHeight)
        etGameDpi = findViewById(R.id.etGameDpi)

        // Nạp lại giá trị đã lưu (ví dụ "314x701" và DPI 160)
        Prefs.getResolution(this, pkg)?.split("x")?.takeIf { it.size == 2 }?.let {
            etW.setText(it[0])
            etH.setText(it[1])
        }
        Prefs.getGameDpi(this, pkg)?.let { etGameDpi.setText(it.toString()) }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val s = parse(true) ?: return@setOnClickListener
            save(s)
            Toast.makeText(this, "Đã lưu cho $label: ${describe(s)}", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnTest).setOnClickListener {
            val s = parse(true) ?: return@setOnClickListener
            if (s.res == null && s.dpi == null) {
                Toast.makeText(this, "Chưa nhập Size hoặc DPI để áp dụng", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            save(s)
            runShizukuTask { ShizukuHelper.apply(s.res, s.dpi) }
        }

        findViewById<Button>(R.id.btnRestore).setOnClickListener {
            runShizukuTask { ShizukuHelper.restoreAll(Prefs.getDefaultDpi(this)) }
        }
    }

    private fun describe(s: Parsed): String =
        listOfNotNull(s.res?.let { "Size $it" }, s.dpi?.let { "DPI $it" })
            .joinToString(", ")
            .ifEmpty { "(đã xóa cài đặt)" }

    private fun save(s: Parsed) {
        Prefs.setResolution(this, pkg, s.res)
        Prefs.setGameDpi(this, pkg, s.dpi)
    }

    /**
     * Đọc ô nhập. Rộng/Cao phải nhập đủ cả hai hoặc để trống cả hai; DPI có thể để trống.
     * Trả về null nếu có lỗi.
     */
    private fun parse(showError: Boolean): Parsed? {
        fun fail(msg: String): Parsed? {
            if (showError) Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            return null
        }

        val wTxt = etW.text.toString().trim()
        val hTxt = etH.text.toString().trim()
        val dTxt = etGameDpi.text.toString().trim()

        var res: String? = null
        if (wTxt.isNotEmpty() || hTxt.isNotEmpty()) {
            val w = wTxt.toIntOrNull()
            val h = hTxt.toIntOrNull()
            if (w == null || h == null || w !in 200..10000 || h !in 200..10000) {
                return fail("Nhập đủ Rộng và Cao hợp lệ (200–10000), hoặc để trống cả hai")
            }
            res = "${w}x$h"
        }

        var dpi: Int? = null
        if (dTxt.isNotEmpty()) {
            val d = dTxt.toIntOrNull()
            if (d == null || !ShizukuHelper.isValidDpi(d)) {
                return fail("DPI hợp lệ: ${ShizukuHelper.MIN_DPI}–${ShizukuHelper.MAX_DPI}")
            }
            dpi = d
        }
        return Parsed(res, dpi)
    }

    // Tự lưu khi thoát màn hình (nếu số liệu hợp lệ)
    override fun onPause() {
        super.onPause()
        if (::pkg.isInitialized) {
            parse(false)?.let { save(it) }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
