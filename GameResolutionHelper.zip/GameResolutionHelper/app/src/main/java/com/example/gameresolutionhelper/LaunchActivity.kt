package com.example.gameresolutionhelper

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.graphics.drawable.toBitmap

/** Activity trong suốt, đích của Shortcut: khởi động phiên chơi rồi đóng ngay. */
class LaunchActivity : Activity() {

    companion object {
        const val ACTION_LAUNCH = "com.example.gameresolutionhelper.LAUNCH_GAME"
        const val EXTRA_GAME_ID = "game_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra(EXTRA_GAME_ID)
        if (id == null || Store(this).games().none { it.id == id }) {
            Toast.makeText(this, "Game này đã bị xóa khỏi danh sách", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        if (!SessionLauncher.start(this, id)) {
            // Thiếu quyền -> mở app chính để người dùng cấp quyền
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        finish()
    }
}

object ShortcutHelper {
    /** @return null nếu gửi yêu cầu thành công, ngược lại là thông báo lỗi. */
    fun pin(ctx: Context, game: GameConfig): String? {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
            return "Launcher hiện tại không hỗ trợ ghim lối tắt"
        }
        val icon = runCatching {
            IconCompat.createWithBitmap(
                ctx.packageManager.getApplicationIcon(game.packageName).toBitmap(192, 192),
            )
        }.getOrNull() ?: IconCompat.createWithResource(ctx, R.drawable.ic_launcher)

        val label = game.displayName.ifBlank { game.packageName }
        val intent = Intent(ctx, LaunchActivity::class.java)
            .setAction(LaunchActivity.ACTION_LAUNCH)
            .putExtra(LaunchActivity.EXTRA_GAME_ID, game.id)

        val info = ShortcutInfoCompat.Builder(ctx, "game_${game.id}")
            .setShortLabel(label)
            .setLongLabel(label)
            .setIcon(icon)
            .setIntent(intent)
            .build()

        return if (ShortcutManagerCompat.requestPinShortcut(ctx, info, null)) null
        else "Không thể tạo lối tắt"
    }
}
