package com.example.gameresolutionhelper

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Lắng nghe TYPE_WINDOW_STATE_CHANGED để biết app nào đang ở foreground.
 *  - Game (đã bật toggle + có độ phân giải) lên foreground  -> wm size <res>
 *  - Chuyển sang app khác / về Home                          -> wm size reset
 */
class GameWatcherService : AccessibilityService() {

    companion object {
        private const val RESET_DELAY_MS = 1200L

        // Các cửa sổ "ké" tạm thời (thanh thông báo, overlay hệ thống, game space...)
        // không được coi là việc thoát game. Thêm package khác vào đây nếu cần.
        private val IGNORED = setOf(
            "android",
            "com.android.systemui",
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller",
            // Oppo / ColorOS
            "com.oplus.games",
            "com.coloros.smartsidebar"
        )
    }

    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var activeGame: String? = null
    private var imePackages: Set<String> = emptySet()

    private val resetRunnable = Runnable { resetNow() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        imePackages = getSystemService(InputMethodManager::class.java)
            ?.enabledInputMethodList
            ?.map { it.packageName }
            ?.toSet()
            ?: emptySet()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return

        // Bàn phím / overlay hệ thống: bỏ qua
        if (pkg in IGNORED || pkg in imePackages) return

        val res = if (Prefs.isEnabled(this, pkg)) Prefs.getResolution(this, pkg) else null

        if (res != null) {
            // Đang ở trong game -> huỷ lệnh reset đang chờ
            handler.removeCallbacks(resetRunnable)
            if (activeGame != pkg) {
                activeGame = pkg
                executor.execute { ShizukuHelper.setSize(res) }
            }
        } else if (activeGame != null) {
            // Rời game -> chờ ~1.2s (tránh nhấp nháy khi popup/quảng cáo) rồi reset
            handler.removeCallbacks(resetRunnable)
            handler.postDelayed(resetRunnable, RESET_DELAY_MS)
        }
    }

    private fun resetNow() {
        if (activeGame != null) {
            activeGame = null
            executor.execute { ShizukuHelper.resetSize() }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(resetRunnable)
        if (activeGame != null) {
            activeGame = null
            executor.execute { ShizukuHelper.resetSize() }
        }
        executor.shutdown()
        super.onDestroy()
    }
}
