package com.example.gameresolutionhelper

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Lắng nghe TYPE_WINDOW_STATE_CHANGED để biết app nào đang ở foreground.
 *
 *  - Vào game (đã bật toggle, có Size và/hoặc Game DPI):
 *        wm size <WxH> ; wm density <Game DPI>
 *  - Thoát game (sang app khác / về Home):
 *        wm size reset ; wm density <Default DPI>   (hoặc wm density reset nếu chưa đặt Default DPI)
 */
class GameWatcherService : AccessibilityService() {

    companion object {
        private const val RESET_DELAY_MS = 1200L

        // Các cửa sổ "ké" tạm thời (thanh thông báo, overlay hệ thống, game space...)
        // không được coi là việc thoát game. Thêm package khác vào đây nếu cần.
        private val IGNORED = setOf(
            "android",
            "com.android.systemui",
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller",
            // Oppo / ColorOS
            "com.oplus.games",
            "com.coloros.smartsidebar"
        )
    }

    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private var activeGame: String? = null
    private var imePackages: Set<String> = emptySet()

    // Theo dõi những gì service đã thay đổi để chỉ khôi phục đúng phần đó
    private var sizeChanged = false
    private var densityChanged = false

    private val resetRunnable = Runnable { resetNow() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        imePackages = getSystemService(InputMethodManager::class.java)
            ?.enabledInputMethodList
            ?.map { it.packageName }
            ?.toSet()
            ?: emptySet()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return

        // Bàn phím / overlay hệ thống: bỏ qua
        if (pkg in IGNORED || pkg in imePackages) return

        val enabled = Prefs.isEnabled(this, pkg)
        val res = if (enabled) Prefs.getResolution(this, pkg) else null
        val dpi = if (enabled) Prefs.getGameDpi(this, pkg) else null

        if (res != null || dpi != null) {
            // Đang ở trong game -> huỷ lệnh reset đang chờ
            handler.removeCallbacks(resetRunnable)
            if (activeGame != pkg) enterGame(pkg, res, dpi)
        } else if (activeGame != null) {
            // Rời game -> chờ ~1.2s (tránh nhấp nháy khi popup/quảng cáo) rồi khôi phục
            handler.removeCallbacks(resetRunnable)
            handler.postDelayed(resetRunnable, RESET_DELAY_MS)
        }
    }

    /** Vào game: áp dụng size + density. Nếu đang chuyển thẳng từ game khác, khôi phục phần không dùng. */
    private fun enterGame(pkg: String, res: String?, dpi: Int?) {
        activeGame = pkg
        val cmds = mutableListOf<String>()

        if (res != null) {
            cmds += ShizukuHelper.sizeCmd(res)
            sizeChanged = true
        } else if (sizeChanged) {
            cmds += ShizukuHelper.SIZE_RESET
            sizeChanged = false
        }

        if (dpi != null) {
            cmds += ShizukuHelper.densityCmd(dpi)
            densityChanged = true
        } else if (densityChanged) {
            cmds += restoreDensityCmd()
            densityChanged = false
        }

        if (cmds.isNotEmpty()) executor.execute { ShizukuHelper.runCommands(cmds) }
    }

    private fun restoreDensityCmd(): String {
        val def = Prefs.getDefaultDpi(this)
        return if (def != null) ShizukuHelper.densityCmd(def) else ShizukuHelper.DENSITY_RESET
    }

    /** Danh sách lệnh khôi phục khi thoát game. */
    private fun buildRestoreCommands(): List<String> {
        val cmds = mutableListOf(ShizukuHelper.SIZE_RESET)
        val def = Prefs.getDefaultDpi(this)
        if (def != null) {
            cmds += ShizukuHelper.densityCmd(def)
        } else if (densityChanged) {
            cmds += ShizukuHelper.DENSITY_RESET
        }
        return cmds
    }

    private fun resetNow() {
        if (activeGame == null) return
        val cmds = buildRestoreCommands()
        activeGame = null
        sizeChanged = false
        densityChanged = false
        executor.execute { ShizukuHelper.runCommands(cmds) }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(resetRunnable)
        if (activeGame != null) {
            val cmds = buildRestoreCommands()
            activeGame = null
            executor.execute { ShizukuHelper.runCommands(cmds) }
        }
        executor.shutdown()
        super.onDestroy()
    }
}
