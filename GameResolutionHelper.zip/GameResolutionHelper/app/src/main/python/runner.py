"""Trình chạy script cho PythonRunnerService (Chaquopy)."""
import ctypes
import runpy
import threading
import time
import traceback

_idents = {}
_real_sleep = time.sleep


def _sleep(seconds):
    # Chia nhỏ sleep để lệnh Dừng có hiệu lực trong <= 0.2s kể cả khi script dùng time.sleep(60)
    end = time.time() + seconds
    while True:
        remain = end - time.time()
        if remain <= 0:
            break
        _real_sleep(min(0.2, remain))


time.sleep = _sleep


def run_blocking(path):
    _idents[path] = threading.get_ident()
    try:
        runpy.run_path(path, run_name="__main__")
        return ""
    except SystemExit:
        return ""
    except BaseException:
        return traceback.format_exc()
    finally:
        _idents.pop(path, None)


def stop(path):
    ident = _idents.get(path)
    if ident is None:
        return False
    ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(ident), ctypes.py_object(SystemExit))
    return True
