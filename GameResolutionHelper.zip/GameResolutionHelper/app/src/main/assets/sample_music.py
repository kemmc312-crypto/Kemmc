# Phát nhạc nền nhẹ bằng MediaPlayer của Android - không cần thư viện ngoài, rất ít RAM.
# 1) Sửa MUSIC_PATH thành file nhạc của bạn.
# 2) Cấp cho app quyền "Nhạc và âm thanh" (Cài đặt > Ứng dụng > Quyền) nếu file nằm ở /storage/emulated/0/Music.
import time
from java import jclass

MUSIC_PATH = "/storage/emulated/0/Music/music.mp3"
VOLUME = 0.6

MediaPlayer = jclass("android.media.MediaPlayer")
player = MediaPlayer()
try:
    player.setDataSource(MUSIC_PATH)
    player.setLooping(True)
    player.setVolume(VOLUME, VOLUME)
    player.prepare()
    player.start()
    print("Đang phát:", MUSIC_PATH)
    while True:
        time.sleep(1)
finally:
    player.release()
