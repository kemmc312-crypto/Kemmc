# GameResolutionHelper v1.1

Tự động đổi độ phân giải (`wm size`) và DPI (`wm density`) khi mở game, rồi khôi phục khi thoát,
dùng Shizuku + Accessibility Service.

## Hành vi
- Vào game (đã bật toggle, có Size và/hoặc Game DPI):
  `wm size <WxH> ; wm density <Game DPI>`
- Thoát game (sang app khác / về Home, sau ~1,2 giây):
  `wm size reset ; wm density <Default DPI>`; nếu chưa đặt Default DPI và game có đổi DPI thì `wm density reset`.
- Dùng `;` thay vì `&&` để lệnh sau vẫn chạy kể cả khi lệnh trước lỗi.
- Size và Game DPI đều là tùy chọn (để trống = không đổi phần đó).

## Cài đặt trong app
- Màn hình chính: ô **Default DPI** (DPI màn hình chính / khi thoát game) + nút Lưu DPI.
- Bấm vào dòng package của game: nhập Rộng × Cao và **Game DPI** riêng cho game đó.

## Build APK
1. Android Studio (JDK 17): File > Open thư mục này > Gradle Sync.
2. Build > Build APK(s) -> `app/build/outputs/apk/debug/app-debug.apk`.
Hoặc build trên GitHub Actions (xem hướng dẫn trong chat).

## Dùng
1. Khởi động Shizuku -> mở app -> "Cấp quyền Shizuku".
2. "Bật Trợ năng" -> bật GameResolutionHelper
   (Android 13+: Thông tin ứng dụng > ⋮ > "Cho phép cài đặt bị hạn chế").
3. Bấm package của game -> nhập Size / Game DPI -> Lưu -> bật toggle.

Cứu hộ khi kẹt size/DPI lạ: nút "Khôi phục" trong app, hoặc
`adb shell wm size reset; adb shell wm density reset`.
