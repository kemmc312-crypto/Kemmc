# Game Resolution Helper

Kotlin · Material 3 · Shizuku · AccessibilityService · Chaquopy (Python)

## Build
1. Mở thư mục bằng Android Studio (Koala+ / JDK 17). Android Studio tự tạo gradle wrapper jar khi sync.
2. Cần cài Python 3.8+ trên máy build (Chaquopy dùng để build). Nếu không tự tìm thấy, khai báo `buildPython("đường/dẫn/python")` trong `app/build.gradle.kts`.
3. `Build > Build APK(s)` hoặc `./gradlew assembleDebug`.

## Cấu trúc
- `data/` cấu hình từng game (SharedPreferences + JSON)
- `shizuku/ShizukuHelper` chạy lệnh shell (exec / stream thời gian thực)
- `core/` DisplayController (wm size/density/Hz), PermissionChecker, ScriptStore
- `service/GameWatcherService` phát hiện game, delay, áp/khôi phục cấu hình; `FloatingButton`; `PythonRunnerService`
- `ui/` MainActivity + 4 tab: Tổng quan (quyền), Game, Terminal, Script
- `python/runner.py` bộ chạy/dừng script
