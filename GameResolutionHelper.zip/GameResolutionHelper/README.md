# GameResolutionHelper

Tự động đổi độ phân giải (`wm size`) khi mở game và khôi phục (`wm size reset`) khi thoát, dùng Shizuku + Accessibility Service.

## Build APK
1. Cài Android Studio (Koala trở lên), JDK 17.
2. File > Open > chọn thư mục `GameResolutionHelper` > chờ Gradle Sync.
   (Nếu Android Studio không nhận project: tạo project "Empty Views Activity", Kotlin,
   package `com.example.gameresolutionhelper`, rồi chép thư mục `app/src` và phần `dependencies`
   trong `app/build.gradle.kts` vào.)
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
   -> `app/build/outputs/apk/debug/app-debug.apk` (đã ký debug, cài được ngay).
   Hoặc dòng lệnh: `./gradlew assembleDebug`.
4. Bản release: Build > Generate Signed App Bundle / APK > APK.

## Dùng
1. Khởi động Shizuku (Wireless debugging hoặc root) -> mở app -> "Cấp quyền Shizuku".
2. "Bật Trợ năng" -> chọn GameResolutionHelper -> Bật.
   Android 13+: nếu bị chặn, vào Cài đặt > Ứng dụng > GameResolutionHelper > ⋮ > "Cho phép cài đặt bị hạn chế".
3. Bấm vào dòng package của game -> nhập Rộng x Cao (vd 314 x 701) -> Lưu.
4. Bật toggle của game. Xong.

Cứu hộ nếu màn hình kẹt size lạ: nút "Reset size" trong app, hoặc `adb shell wm size reset`.
