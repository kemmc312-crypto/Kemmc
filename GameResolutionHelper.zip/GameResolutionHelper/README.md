# GameResolutionHelper

Kotlin · Jetpack Compose · Material 3 · Shizuku · Termux

## Build APK
1. Mở thư mục này bằng Android Studio (Ladybug trở lên, JDK 17), chờ Gradle sync.
2. Build > Build APK(s)  (hoặc `./gradlew assembleDebug`) -> `app/build/outputs/apk/debug/app-debug.apk`.

## Thiết lập khi dùng
- **Shizuku**: cài và khởi động Shizuku, mở app rồi bấm "Cấp quyền" ở tab Trang chủ.
- **Nút nổi**: cấp quyền "Hiển thị trên các ứng dụng khác".
- **Termux** (tab Nhạc): trong Termux chạy
  `termux-setup-storage`, `pkg install mpv ffmpeg yt-dlp`,
  `echo "allow-external-apps = true" >> ~/.termux/termux.properties`, rồi đóng hẳn và mở lại Termux.
  Sau đó cấp quyền RUN_COMMAND trong app.
- Vào Cài đặt > "Tự nhận diện từ máy" (khi máy đang ở phân giải gốc) để lưu thông số gốc.
