# GameResolutionHelper
Mở thư mục này bằng Android Studio (Koala+), để Gradle sync (IDE tự tạo gradle wrapper), rồi Run.

Yêu cầu: cài app Shizuku và khởi động; cấp quyền Shizuku, "Hiển thị trên ứng dụng khác", Thông báo.
ColorOS: bật Tự khởi động / Không hạn chế pin cho app; cấp quyền "Tạo lối tắt" để ghim Shortcut.
Termux (tuỳ chọn): echo "allow-external-apps=true" >> ~/.termux/termux.properties, cấp quyền RUN_COMMAND cho app.
