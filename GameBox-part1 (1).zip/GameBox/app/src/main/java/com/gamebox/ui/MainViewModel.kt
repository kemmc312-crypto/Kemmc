package com.gamebox.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gamebox.display.DisplayClient
import com.gamebox.game.AppInfo
import com.gamebox.game.AppRepository
import com.gamebox.game.TabConfig
import com.gamebox.game.TabManager
import com.gamebox.game.screenRatio
import com.gamebox.shizuku.ShizukuManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val shizuku = ShizukuManager.state
    val lost = ShizukuManager.lost
    val denied = ShizukuManager.denied
    val service = DisplayClient.connected
    val tabs = TabManager.tabs
    val active = TabManager.active
    val status = TabManager.status
    val ratio = screenRatio(app)

    val query = MutableStateFlow("")
    /** app vừa bấm chọn -> mở dialog cấu hình trước khi chạy */
    val pending = MutableStateFlow<AppInfo?>(null)

    private val apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val list = combine(apps, query) { a, q ->
        if (q.isBlank()) a else a.filter { it.label.contains(q, true) || it.pkg.contains(q, true) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init { viewModelScope.launch { apps.value = AppRepository.load(app) } }

    fun requestPermission() = ShizukuManager.requestPermission()
    fun select(id: Int?) = TabManager.select(id)
    fun close(id: Int) = TabManager.close(id)
    fun start(id: Int) = TabManager.start(id)
    fun reconfigure(id: Int, cfg: TabConfig) = TabManager.reconfigure(id, cfg)

    fun pick(a: AppInfo) {
        val t = tabs.value.firstOrNull { it.pkg == a.pkg }
        if (t != null) select(t.id) else pending.value = a
    }

    fun confirmNew(cfg: TabConfig) {
        pending.value?.let { TabManager.addAndStart(it, cfg) }
        pending.value = null
    }
}
