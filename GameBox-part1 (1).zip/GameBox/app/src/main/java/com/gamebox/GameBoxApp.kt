package com.gamebox

import android.app.Application
import com.gamebox.game.TabManager
import com.gamebox.shizuku.ShizukuManager

class GameBoxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        TabManager.init(this)
        ShizukuManager.init(this)
    }
}
