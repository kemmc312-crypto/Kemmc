package com.gamebox.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.gamebox.game.TabConfig
import com.gamebox.game.lockedHeight

/** Cấu hình riêng từng tab: độ phân giải nhập số, khóa tỉ lệ màn hình, DPI, Hz. */
@Composable
fun TabConfigDialog(
    title: String,
    confirm: String,
    initial: TabConfig,
    ratio: Float,
    onDismiss: () -> Unit,
    onConfirm: (TabConfig) -> Unit,
) {
    var w by remember { mutableStateOf(initial.width.toString()) }
    var h by remember { mutableStateOf(initial.height.toString()) }
    var dpi by remember { mutableStateOf(if (initial.dpi > 0) initial.dpi.toString() else "") }
    var land by remember { mutableStateOf(initial.landscape) }
    var lock by remember { mutableStateOf(initial.lockRatio) }
    var hz by remember { mutableStateOf(initial.hz) }

    val wi = w.toIntOrNull() ?: 0
    val hi = if (lock) lockedHeight(wi, land, ratio) else (h.toIntOrNull() ?: 0)
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = w, onValueChange = { w = it.filter(Char::isDigit) },
                    label = { Text("Chiều rộng (px)") }, singleLine = true, keyboardOptions = num
                )
                OutlinedTextField(
                    value = if (lock) hi.toString() else h, onValueChange = { h = it.filter(Char::isDigit) },
                    enabled = !lock, label = { Text("Chiều cao (px)") }, singleLine = true, keyboardOptions = num
                )
                Row { Text("Khóa tỉ lệ màn hình", Modifier.weight(1f)); Switch(checked = lock, onCheckedChange = { lock = it }) }
                Row { Text("Chạy ngang", Modifier.weight(1f)); Switch(checked = land, onCheckedChange = { land = it }) }
                OutlinedTextField(
                    value = dpi, onValueChange = { dpi = it.filter(Char::isDigit) },
                    label = { Text("DPI (trống = tự động)") }, singleLine = true, keyboardOptions = num
                )
                Text("Tần số quét (Hz)")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(30, 45, 60, 90).forEach { f ->
                        FilterChip(selected = hz == f, onClick = { hz = f }, label = { Text("$f") })
                    }
                }
                Text(
                    "Đổi cấu hình sẽ khởi động lại game ở tab này.",
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = wi in 240..4000 && hi in 240..4000,
                onClick = { onConfirm(TabConfig(wi / 2 * 2, hi / 2 * 2, dpi.toIntOrNull() ?: 0, land, lock, hz)) }
            ) { Text(confirm) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}
