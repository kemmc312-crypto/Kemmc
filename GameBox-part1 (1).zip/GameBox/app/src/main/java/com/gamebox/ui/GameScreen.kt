package com.gamebox.ui

import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import com.gamebox.display.DisplayClient
import com.gamebox.game.GameTab
import com.gamebox.game.TabManager

/** Nội dung 1 tab game: SurfaceView hiển thị display ảo + chuyển touch vào display. Back = về tab "Thêm game". */
@Composable
fun GameView(tab: GameTab, vm: MainViewModel) {
    BackHandler { vm.select(null) }
    val c = tab.cfg
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        if (!tab.running) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${tab.label}: chưa chạy", color = Color.White)
                Button(onClick = { vm.start(tab.id) }) { Text("Chạy") }
            }
        } else key(tab.id, tab.displayId) {
            AndroidView(
                modifier = Modifier.aspectRatio(c.width.toFloat() / c.height),
                factory = { ctx ->
                    SurfaceView(ctx).apply {
                        keepScreenOn = true
                        holder.setFixedSize(c.width, c.height)
                        holder.addCallback(object : SurfaceHolder.Callback {
                            override fun surfaceCreated(h: SurfaceHolder) = DisplayClient.attach(tab.displayId, h.surface)
                            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
                            override fun surfaceDestroyed(h: SurfaceHolder) = DisplayClient.detach(tab.displayId)
                        })
                        setOnTouchListener { v, ev ->
                            if (v.width > 0 && v.height > 0)
                                DisplayClient.inject(
                                    ev, tab.displayId,
                                    c.width / v.width.toFloat(), c.height / v.height.toFloat()
                                )
                            if (ev.actionMasked == MotionEvent.ACTION_UP) TabManager.touchDiag()
                            true
                        }
                    }
                }
            )
        }
    }
}
