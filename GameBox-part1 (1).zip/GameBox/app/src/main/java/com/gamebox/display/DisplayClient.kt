package com.gamebox.display

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.graphics.Matrix
import android.os.IBinder
import android.view.MotionEvent
import android.view.Surface
import com.gamebox.IDisplayService
import com.gamebox.game.TabManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku

/** Phía app: bind DisplayService (chạy bằng quyền shell qua Shizuku). */
object DisplayClient {
    private var svc: IDisplayService? = null
    private var bound = false
    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            svc = IDisplayService.Stub.asInterface(b)
            _connected.value = true
        }
        override fun onServiceDisconnected(n: ComponentName) {
            onShizukuLost()
            TabManager.onServiceLost()
        }
    }

    fun bind(ctx: Context) {
        if (bound || !Shizuku.pingBinder()) return
        bound = true
        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, DisplayService::class.java.name))
            .daemon(false).processNameSuffix("display").version(1)
        try { Shizuku.bindUserService(args, conn) } catch (_: Throwable) { bound = false }
    }

    fun onShizukuLost() { svc = null; bound = false; _connected.value = false }

    fun createDisplay(name: String, w: Int, h: Int, dpi: Int): Int =
        try { svc?.createDisplay(name, w, h, dpi) ?: -1 } catch (_: Throwable) { -1 }

    fun lastError(): String = try { svc?.lastError().orEmpty() } catch (e: Throwable) { e.message.orEmpty() }
    fun attach(id: Int, s: Surface) { try { svc?.attachSurface(id, s) } catch (_: Throwable) {} }
    fun detach(id: Int) { try { svc?.detachSurface(id) } catch (_: Throwable) {} }
    fun release(id: Int) { try { svc?.releaseDisplay(id) } catch (_: Throwable) {} }

    /** sx, sy: tỉ lệ pixel display / pixel view */
    fun inject(ev: MotionEvent, id: Int, sx: Float, sy: Float) {
        val s = svc ?: return
        val e = MotionEvent.obtain(ev)
        e.transform(Matrix().apply { setScale(sx, sy) })
        try { s.inject(e, id) } catch (_: Throwable) {} finally { e.recycle() }
    }
}
