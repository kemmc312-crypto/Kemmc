package com.gamebox.ui

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.OutlinedButton
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.gamebox.shizuku.ShizukuState

private fun openShizuku(ctx: Context) {
    val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
    if (i != null) ctx.startActivity(i) else Toast.makeText(ctx, "Chưa cài Shizuku", Toast.LENGTH_SHORT).show()
}

/** Tab "Thêm game": trạng thái Shizuku + danh sách app đã cài. */
@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val st by vm.shizuku.collectAsState()
    val lost by vm.lost.collectAsState()
    val denied by vm.denied.collectAsState()
    val svc by vm.service.collectAsState()
    val tabs by vm.tabs.collectAsState()
    val q by vm.query.collectAsState()
    val list by vm.list.collectAsState()
    val pickApk = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.installApk(uri)
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (lost) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
            Text(
                "⚠ Shizuku đã ngắt kết nối. Các game đang chạy có thể lỗi — mở Shizuku và chạy lại.",
                Modifier.padding(12.dp)
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                when (st) {
                    ShizukuState.NOT_INSTALLED -> "Shizuku: chưa cài"
                    ShizukuState.NOT_RUNNING -> "Shizuku: chưa chạy"
                    ShizukuState.NO_PERMISSION -> "Shizuku: chưa cấp quyền"
                    ShizukuState.READY -> "Shizuku: sẵn sàng ✓"
                },
                Modifier.weight(1f)
            )
            when (st) {
                ShizukuState.NO_PERMISSION -> Button(onClick = vm::requestPermission) { Text("Cấp quyền") }
                ShizukuState.NOT_RUNNING -> Button(onClick = { openShizuku(ctx) }) { Text("Mở Shizuku") }
                else -> {}
            }
        }
        if (st == ShizukuState.READY)
            Text(
                if (svc) "Dịch vụ display: đã kết nối ✓" else "Dịch vụ display: đang kết nối…",
                style = MaterialTheme.typography.bodySmall
            )
        if (denied && st == ShizukuState.NO_PERMISSION)
            Text(
                "Đã từ chối: vào Shizuku → ứng dụng được ủy quyền → bật GameBox.",
                style = MaterialTheme.typography.bodySmall
            )

        OutlinedButton(
            onClick = { pickApk.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream")) },
            enabled = svc,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Cài game từ file APK") }
        Text("Hoặc chọn app đã có sẵn để mở thành tab mới", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(
            value = q, onValueChange = { vm.query.value = it },
            modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Tìm app") }
        )
        LazyColumn(Modifier.weight(1f)) {
            items(list, key = { it.pkg }) { a ->
                val open = tabs.any { it.pkg == a.pkg }
                ListItem(
                    headlineContent = { Text(a.label) },
                    supportingContent = { Text(a.pkg, style = MaterialTheme.typography.bodySmall) },
                    trailingContent = { if (open) Text("đang mở", style = MaterialTheme.typography.labelSmall) },
                    modifier = Modifier.clickable { vm.pick(a) }
                )
            }
        }
    }
}
