package com.gamebox.game

import android.content.Context
import android.content.Intent
import com.gamebox.shizuku.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppInfo(val label: String, val pkg: String)

object AppRepository {
    suspend fun load(ctx: Context): List<AppInfo> = withContext(Dispatchers.IO) {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }
}

object GameLauncher {
    /** @return (thành công, output của am) */
    suspend fun launch(ctx: Context, pkg: String, displayId: Int, freshStart: Boolean = true): Pair<Boolean, String> {
        val comp = ctx.packageManager.getLaunchIntentForPackage(pkg)?.component
            ?: return false to "Không tìm thấy activity chính của $pkg"
        ShizukuManager.sh("settings put global force_resizable_activities 1") // best effort
        if (freshStart) ShizukuManager.sh("am force-stop $pkg")
        val (code, out) = ShizukuManager.sh("am start --display $displayId --activity-exclude-from-recents -n ${comp.flattenToShortString()}")
        return (code == 0 && !out.contains("Error", ignoreCase = true)) to out
    }

    suspend fun isRunning(pkg: String): Boolean =
        ShizukuManager.sh("pidof $pkg").let { it.first == 0 && it.second.isNotBlank() }

    suspend fun stop(pkg: String) = ShizukuManager.sh("am force-stop $pkg")

    /** Task của game đang nằm ở display nào (null nếu không thấy). */
    suspend fun displayOf(pkg: String): Int? {
        val out = ShizukuManager.sh(
            "dumpsys activity activities | grep -E 'Display #[0-9]+|ActivityRecord.* u0 $pkg/'"
        ).second
        val re = Regex("Display #(\\d+)")
        var d: Int? = null
        for (l in out.lines()) {
            val m = re.find(l)
            if (m != null) d = m.groupValues[1].toInt()
            else if (l.contains("ActivityRecord")) return d
        }
        return null
    }
}
