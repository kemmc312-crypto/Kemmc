package com.gamebox;

import android.os.ParcelFileDescriptor;
import android.view.Surface;
import android.view.MotionEvent;

interface IDisplayService {
    // Shizuku bắt buộc
    void destroy() = 16777114;

    // Tạo display ảo (quyền shell, trusted). Trả về displayId, -1 nếu lỗi.
    int createDisplay(String name, int width, int height, int dpi) = 1;
    void attachSurface(int displayId, in Surface surface) = 2;
    // Gỡ SurfaceView: display chuyển sang Surface giả để không bị OFF
    void detachSurface(int displayId) = 3;
    void releaseDisplay(int displayId) = 4;
    oneway void inject(in MotionEvent event, int displayId) = 5;
    String lastError() = 6;
    String injectStatus() = 7;
    // Cài APK đơn bằng quyền shell (pm install). Trả về output của pm.
    String installApk(in ParcelFileDescriptor apk) = 8;
}
