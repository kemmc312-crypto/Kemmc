package com.dxz.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

data class Msg(val role: String, val text: String, val local: Boolean = false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { DxzApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DxzApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("dxz", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()

    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    val msgs = remember { mutableStateListOf<Msg>() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    fun send() {
        val text = input.trim()
        if (text.isEmpty() || loading) return
        input = ""
        val filter = FilterStore.active(ctx)

        // Lọc đầu vào
        if (filter.matches(text)) {
            msgs += Msg("user", text, local = true)
            msgs += Msg("assistant", filter.blockMessage, local = true)
            return
        }
        msgs += Msg("user", text)
        loading = true
        scope.launch {
            val history = msgs.filter { !it.local }.map { it.role to it.text }
            try {
                val reply = ApiClient.chat(apiKey, history)
                // Lọc đầu ra
                if (filter.matches(reply)) msgs += Msg("assistant", filter.blockMessage, local = true)
                else msgs += Msg("assistant", reply)
            } catch (e: Exception) {
                msgs += Msg("assistant", "Lỗi: ${e.message}", local = true)
            }
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("dxz") },
                actions = { TextButton(onClick = { showSettings = !showSettings }) { Text(if (showSettings) "Đóng" else "Cài đặt") } }
            )
        }
    ) { pad ->
        if (showSettings) {
            SettingsScreen(
                modifier = Modifier.padding(pad),
                apiKey = apiKey,
                onApiKey = { apiKey = it; prefs.edit().putString("key", it).apply() }
            )
        } else {
            Column(Modifier.padding(pad).padding(12.dp)) {
                LazyColumn(Modifier.weight(1f)) {
                    items(msgs) { m ->
                        Text(
                            (if (m.role == "user") "Bạn: " else "dxz: ") + m.text,
                            Modifier.padding(vertical = 6.dp)
                        )
                    }
                    if (loading) item { Text("dxz đang nghĩ...") }
                }
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Hỏi về code...") })
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = ::send, enabled = !loading) { Text("Gửi") }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(modifier: Modifier, apiKey: String, onApiKey: (String) -> Unit) {
    val ctx = LocalContext.current
    val locked = remember { FilterStore.locked(ctx) }
    val saved = remember { FilterStore.user(ctx) }
    var words by remember { mutableStateOf(saved.blockedWords.joinToString("\n")) }
    var blockMsg by remember { mutableStateOf(saved.blockMessage) }
    var status by remember { mutableStateOf("") }

    Column(modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
        OutlinedTextField(apiKey, onApiKey, Modifier.fillMaxWidth(), label = { Text("API key") }, singleLine = true)

        // Phần lọc: chỉ hiện ở bản dev. Bản phát hành đặt SHOW_FILTER_SETTINGS = false.
        if (BuildConfig.SHOW_FILTER_SETTINGS) {
            Spacer(Modifier.height(16.dp))
            Text("Bộ lọc", style = MaterialTheme.typography.titleMedium)
            if (locked != null) Text("Đang dùng bộ lọc khoá cứng trong app (assets/filter.json). Cài đặt dưới đây không có tác dụng.")
            Text("Mỗi dòng một từ/cụm bị chặn. Để trống = không lọc.")
            OutlinedTextField(words, { words = it }, Modifier.fillMaxWidth().heightIn(min = 120.dp), label = { Text("Từ bị chặn") })
            OutlinedTextField(blockMsg, { blockMsg = it }, Modifier.fillMaxWidth(), label = { Text("Thông báo khi bị chặn") })
            Spacer(Modifier.height(8.dp))
            Row {
                Button(onClick = {
                    FilterStore.saveUser(ctx, cfg(words, blockMsg)); status = "Đã lưu"
                }) { Text("Lưu") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = {
                    val json = cfg(words, blockMsg).toJson()
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("filter.json", json))
                    status = "Đã copy filter.json, dán vào app/src/main/assets/filter.json"
                }) { Text("Copy filter.json") }
            }
            if (status.isNotEmpty()) Text(status)
        }
    }
}

private fun cfg(words: String, msg: String) = FilterConfig(
    words.lines().map { it.trim() }.filter { it.isNotEmpty() },
    msg.ifBlank { FilterConfig().blockMessage }
)
