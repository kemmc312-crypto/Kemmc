package com.dxz.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

object ApiClient {
    private val http = OkHttpClient()

    private const val SYSTEM =
        "Bạn là dxz, một trợ lý lập trình. Với mỗi yêu cầu: (1) phân tích yêu cầu, " +
        "(2) liệt kê các bước thực hiện và logic, (3) rồi mới viết code từng bước, " +
        "(4) chỉ ra chỗ dễ lỗi. Trả lời bằng ngôn ngữ người dùng đang dùng."

    suspend fun chat(apiKey: String, history: List<Pair<String, String>>): String =
        withContext(Dispatchers.IO) {
            val msgs = JSONArray()
            history.forEach { (role, text) ->
                msgs.put(JSONObject().put("role", role).put("content", text))
            }
            val body = JSONObject()
                .put("model", "claude-sonnet-5-5")
                .put("max_tokens", 2000)
                .put("system", SYSTEM)
                .put("messages", msgs)

            val req = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .header("x-api-key", apiKey)
                .header("anthropic-version", "2023-06-01")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(req).execute().use { r ->
                val s = r.body?.string().orEmpty()
                if (!r.isSuccessful) error("API ${r.code}: $s")
                val c = JSONObject(s).getJSONArray("content")
                buildString {
                    for (i in 0 until c.length()) append(c.getJSONObject(i).optString("text"))
                }
            }
        }
}
