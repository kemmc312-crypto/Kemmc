# GameResolutionHelper

Kotlin · Jetpack Compose · Material 3 · Shizuku · Termux

## Build APK
1. Mở thư mục này bằng Android Studio (Ladybug trở lên, JDK 17), chờ Gradle sync.
2. Build > Build APK(s)  (hoặc `./gradlew assembleDebug`) -> `app/build/outputs/apk/debug/app-debug.apk`.

## Thiết lập khi dùng
- **Shizuku**: cài và khởi động Shizuku, mở app rồi bấm "Cấp quyền" ở tab Trang chủ.
- **Nút nổi**: cấp quyền "Hiển thị trên các ứng dụng khác".
- **Tab Ứng dụng**: cần Shizuku đang chạy và đã cấp quyền. Công tắc BẬT = app hoạt động, TẮT = đóng băng
  (`pm disable-user --user 0`). Bật lại bằng công tắc hoặc ở bộ lọc "Đã tắt".
- Vào Cài đặt > "Tự nhận diện từ máy" (khi máy đang ở phân giải gốc) để lưu thông số gốc.
