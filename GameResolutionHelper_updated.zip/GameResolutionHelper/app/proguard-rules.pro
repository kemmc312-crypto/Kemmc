# Không bật minify trong cấu hình mặc định. Nếu bật R8, giữ lại Shizuku:
-keep class rikka.shizuku.** { *; }
