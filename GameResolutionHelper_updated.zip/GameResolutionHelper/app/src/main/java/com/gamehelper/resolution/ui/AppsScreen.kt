package com.gamehelper.resolution.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gamehelper.resolution.apps.AppsController
import com.gamehelper.resolution.apps.PackageItem
import com.gamehelper.resolution.shizuku.ShizukuHelper
import com.gamehelper.resolution.toast

private enum class AppFilter(val label: String) {
    User("Đã cài"),
    System("Hệ thống"),
    Disabled("Đã tắt"),
    All("Tất cả")
}

private fun AppFilter.matches(app: PackageItem): Boolean = when (this) {
    AppFilter.User -> !app.isSystem
    AppFilter.System -> app.isSystem
    AppFilter.Disabled -> !app.enabled
    AppFilter.All -> true
}

@Composable
fun AppsScreen(padding: PaddingValues) {
    val ctx = LocalContext.current
    val st by AppsController.state.collectAsStateWithLifecycle()
    val shizuku by ShizukuHelper.status.collectAsStateWithLifecycle()

    var query by rememberSaveable { mutableStateOf("") }
    var filterIndex by rememberSaveable { mutableIntStateOf(0) }
    val filter = AppFilter.entries[filterIndex]
    var pendingDisable by remember { mutableStateOf<PackageItem?>(null) }

    // Quét lần đầu và quét lại mỗi khi quay lại app (có thể vừa cài/gỡ app khác)
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        ShizukuHelper.refresh()
        AppsController.refresh(ctx)
    }

    val counts = remember(st.apps) {
        AppFilter.entries.associateWith { f -> st.apps.count { f.matches(it) } }
    }
    val filtered = remember(st.apps, query, filter) {
        val q = query.trim()
        st.apps.filter { app ->
            filter.matches(app) &&
                    (q.isEmpty() || app.label.contains(q, ignoreCase = true) || app.packageName.contains(q, ignoreCase = true))
        }
    }
    val canToggle = shizuku == ShizukuHelper.Status.READY

    Column(Modifier.fillMaxSize()) {
        // Phần đầu cố định: tiêu đề, tìm kiếm, bộ lọc
        Column(
            Modifier.padding(start = 16.dp, end = 16.dp, top = padding.calculateTopPadding() + 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Quản lý ứng dụng", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Tắt app chạy nền để giải phóng RAM trước khi chơi game.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f)
                    )
                }
                Spacer(Modifier.width(8.dp))
                GlassIconButton(onClick = { AppsController.refresh(ctx) }, enabled = !st.loading) {
                    Icon(Icons.Rounded.Refresh, "Quét lại")
                }
            }

            if (shizuku != ShizukuHelper.Status.READY) ShizukuNotice(shizuku)

            GlassTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Tìm theo tên hoặc package") },
                singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = if (query.isNotEmpty()) {
                    { Icon(Icons.Rounded.Close, "Xóa", Modifier.clickable { query = "" }) }
                } else null,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppFilter.entries.forEach { f ->
                    FilterPill(
                        text = "${f.label} (${counts[f] ?: 0})",
                        selected = f == filter,
                        onClick = { filterIndex = f.ordinal }
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        if (st.loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        } else {
            Spacer(Modifier.height(4.dp))
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp, top = 8.dp,
                bottom = padding.calculateBottomPadding() + 24.dp
            ),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (filtered.isEmpty()) {
                item {
                    GlassCard {
                        Text(
                            when {
                                !st.loaded -> "Đang quét danh sách ứng dụng…"
                                query.isNotBlank() -> "Không có ứng dụng nào khớp “${query.trim()}”."
                                filter == AppFilter.Disabled -> "Chưa có ứng dụng nào bị tắt."
                                else -> "Không có ứng dụng nào."
                            },
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
            items(filtered, key = { it.packageName }) { app ->
                AppRow(
                    item = app,
                    busy = app.packageName in st.busy,
                    canToggle = canToggle,
                    onToggle = { wantEnabled ->
                        if (!wantEnabled && app.isSystem) pendingDisable = app
                        else AppsController.setEnabled(ctx, app.packageName, wantEnabled)
                    }
                )
            }
        }
    }

    pendingDisable?.let { app ->
        AlertDialog(
            onDismissRequest = { pendingDisable = null },
            title = { Text("Tắt ứng dụng hệ thống?") },
            text = {
                Text(
                    "“${app.label}” là ứng dụng hệ thống. Tắt nhầm có thể khiến một số tính năng của máy " +
                            "hoạt động sai hoặc báo lỗi. Bạn có thể bật lại bất cứ lúc nào ở mục “Đã tắt”."
                )
            },
            confirmButton = {
                GlassTextButton(onClick = {
                    AppsController.setEnabled(ctx, app.packageName, false)
                    pendingDisable = null
                }) { Text("Tắt ứng dụng") }
            },
            dismissButton = { GlassTextButton(onClick = { pendingDisable = null }) { Text("Hủy") } }
        )
    }
}

@Composable
private fun ShizukuNotice(status: ShizukuHelper.Status) {
    val ctx = LocalContext.current
    val notRunning = status == ShizukuHelper.Status.NOT_RUNNING
    GlassCard {
        Text(
            if (notRunning) "Shizuku chưa chạy. Khởi động Shizuku rồi quay lại đây để bật/tắt ứng dụng."
            else "Chưa cấp quyền Shizuku cho app này.",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(10.dp))
        GlassButton(
            emphasis = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                if (notRunning) {
                    val intent = ctx.packageManager.getLaunchIntentForPackage(ShizukuHelper.SHIZUKU_PKG)
                    if (intent != null) ctx.startActivity(intent) else ctx.toast("Chưa cài Shizuku", long = true)
                } else {
                    ShizukuHelper.requestPermission()
                }
            }
        ) { Text(if (notRunning) "Mở Shizuku" else "Cấp quyền Shizuku") }
    }
}

@Composable
private fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(Color.White.copy(alpha = if (selected) 0.20f else 0.04f), CircleShape)
            .border(1.dp, Color.White.copy(alpha = if (selected) 0.85f else 0.30f), CircleShape)
            .clickable(role = Role.Tab, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = Color.White.copy(alpha = if (selected) 1f else 0.75f),
            maxLines = 1
        )
    }
}

@Composable
private fun AppRow(
    item: PackageItem,
    busy: Boolean,
    canToggle: Boolean,
    onToggle: (Boolean) -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    val frozen = !item.enabled
    // App được bảo vệ đang bật thì không cho gạt tắt; nếu lỡ đang tắt thì vẫn cho bật lại.
    val switchEnabled = canToggle && (frozen || item.protectedReason == null)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color.White.copy(alpha = if (frozen) 0.02f else 0.06f), shape)
            .border(1.dp, Color.White.copy(alpha = if (frozen) 0.12f else 0.22f), shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.graphicsLayer { alpha = if (frozen) 0.45f else 1f }) {
            AppIcon(item.packageName, 44.dp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.label,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (frozen) 0.6f else 1f),
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                item.packageName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (frozen) Badge("Đã tắt", MaterialTheme.colorScheme.error)
                else Badge("Đang bật", Color.White.copy(alpha = 0.8f))
                if (item.isSystem) Badge("Hệ thống", Color.White.copy(alpha = 0.55f))
                if (item.protectedReason != null) {
                    Icon(
                        Icons.Rounded.Lock, "Được bảo vệ: ${item.protectedReason}",
                        modifier = Modifier.size(14.dp), tint = Color.White.copy(alpha = 0.55f)
                    )
                }
            }
        }
        Spacer(Modifier.width(8.dp))
        if (busy) {
            CircularProgressIndicator(Modifier.size(24.dp), color = Color.White, strokeWidth = 2.dp)
        } else {
            GlassSwitch(checked = item.enabled, onCheckedChange = onToggle, enabled = switchEnabled)
        }
    }
}

@Composable
private fun Badge(text: String, color: Color) {
    val shape = RoundedCornerShape(6.dp)
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        color = color,
        maxLines = 1,
        modifier = Modifier
            .border(1.dp, color.copy(alpha = 0.6f), shape)
            .padding(horizontal = 6.dp, vertical = 1.dp)
    )
}
