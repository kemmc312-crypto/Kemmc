package com.gamehelper.resolution.termux

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Gửi lệnh sang Termux qua intent RUN_COMMAND.
 *
 * Yêu cầu phía Termux:
 *  - Mở Termux, thêm dòng `allow-external-apps = true` vào ~/.termux/termux.properties rồi khởi động lại Termux.
 *  - Chạy `termux-setup-storage` để Termux đọc được /sdcard.
 *  - Cài gói: pkg install mpv ffmpeg yt-dlp
 */
object TermuxBridge {
    const val PACKAGE = "com.termux"
    const val PERMISSION = "com.termux.permission.RUN_COMMAND"
    private const val BASH = "/data/data/com.termux/files/usr/bin/bash"
    private const val HOME = "/data/data/com.termux/files/home"
    private const val PATH_PREFIX = "export PATH=/data/data/com.termux/files/usr/bin:\$PATH; "

    data class Result(
        val stdout: String,
        val stderr: String,
        val exitCode: Int?,
        val error: String?
    ) {
        val ok: Boolean get() = error == null && (exitCode == null || exitCode == 0)
    }

    private val callbacks = ConcurrentHashMap<Int, (Result) -> Unit>()
    private val counter = AtomicInteger(2000)

    fun isInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(PACKAGE, 0)
        true
    } catch (_: Exception) {
        false
    }

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, PERMISSION) == PackageManager.PERMISSION_GRANTED

    /**
     * Chạy [script] bằng bash trong nền của Termux.
     * [onResult] (nếu có) được gọi trên main thread khi lệnh kết thúc.
     * Trả về false nếu không gửi được lệnh (chưa cài Termux, thiếu quyền, ...).
     */
    fun run(ctx: Context, script: String, onResult: ((Result) -> Unit)? = null): Boolean {
        val app = ctx.applicationContext
        if (!isInstalled(app)) {
            onResult?.invoke(Result("", "", null, "Chưa cài Termux"))
            return false
        }
        if (!hasPermission(app)) {
            onResult?.invoke(Result("", "", null, "Chưa cấp quyền RUN_COMMAND cho app"))
            return false
        }

        val intent = Intent("com.termux.RUN_COMMAND").apply {
            setClassName(PACKAGE, "com.termux.app.RunCommandService")
            putExtra("com.termux.RUN_COMMAND_PATH", BASH)
            putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", PATH_PREFIX + script))
            putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME)
            putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
        }

        var id = -1
        if (onResult != null) {
            id = counter.incrementAndGet()
            callbacks[id] = onResult
            val resultIntent = Intent(app, TermuxResultReceiver::class.java).putExtra("reqId", id)
            val pending = PendingIntent.getBroadcast(
                app, id, resultIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            intent.putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pending)
        }

        return try {
            ContextCompat.startForegroundService(app, intent)
            true
        } catch (e: Exception) {
            if (id != -1) callbacks.remove(id)
            onResult?.invoke(
                Result(
                    "", "", null,
                    "Không gửi được lệnh tới Termux: ${e.message}. " +
                            "Hãy kiểm tra allow-external-apps = true trong termux.properties."
                )
            )
            false
        }
    }

    /** Termux trả kết quả về qua TermuxResultReceiver. */
    internal fun deliver(id: Int, data: Intent) {
        val cb = callbacks.remove(id) ?: return
        val b = data.getBundleExtra("result")
        val errMsg = b?.getString("errmsg")
        cb(
            Result(
                stdout = b?.getString("stdout").orEmpty(),
                stderr = b?.getString("stderr").orEmpty(),
                exitCode = if (b != null && b.containsKey("exitCode")) b.getInt("exitCode") else null,
                error = errMsg?.takeIf { it.isNotBlank() }
            )
        )
    }
}
