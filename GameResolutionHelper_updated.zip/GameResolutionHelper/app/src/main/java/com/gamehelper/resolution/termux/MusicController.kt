package com.gamehelper.resolution.termux

import android.content.Context
import com.gamehelper.resolution.shellQuote
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONObject

data class MusicState(
    val files: List<String> = emptyList(),
    val index: Int = -1,
    val nowPlaying: String? = null,
    val playing: Boolean = false,
    val loop: Boolean = true,
    val single: Boolean = false,
    val startMs: Long = 0L,
    val durationSec: Double = 0.0,
    val scanning: Boolean = false,
    val status: String = "",
    val busy: Boolean = false,
    val log: String = ""
)

enum class DownloadKind { YOUTUBE_VIDEO, YOUTUBE_MP3, TIKTOK }

/**
 * Chuyển logic của music.py sang Kotlin: quét media, phát bằng mpv, đo thời lượng bằng ffprobe,
 * tải bằng yt-dlp — tất cả chạy trong Termux thông qua [TermuxBridge].
 */
object MusicController {
    val SEARCH_PATHS = listOf("/sdcard/Download", "/sdcard/Music", "/sdcard/Movies", "/sdcard/DCIM")
    val EXTENSIONS = listOf("mp3", "mp4", "mkv", "webm", "m4a", "aac", "flac")
    private const val DOWNLOAD_DIR = "/sdcard/Download"

    private val _state = MutableStateFlow(MusicState())
    val state: StateFlow<MusicState> = _state.asStateFlow()

    // ------------------------------------------------------------------
    // Quét file
    // ------------------------------------------------------------------
    fun scan(ctx: Context) {
        _state.update { it.copy(scanning = true, status = "Đang quét file trong máy…") }
        val paths = SEARCH_PATHS.joinToString(" ") { shellQuote(it) }
        val names = EXTENSIONS.joinToString(" -o ") { "-iname '*.$it'" }
        val script = "find $paths -type f \\( $names \\) 2>/dev/null | sort"
        TermuxBridge.run(ctx, script) { r ->
            if (r.error != null) {
                _state.update { it.copy(scanning = false, status = "❌ ${r.error}") }
            } else {
                val files = r.stdout.lines().map { it.trim() }.filter { it.isNotEmpty() }
                _state.update {
                    it.copy(
                        scanning = false,
                        files = files,
                        status = if (files.isEmpty()) "❌ Không tìm thấy file âm thanh/video nào! (đã chạy termux-setup-storage chưa?)"
                        else "Tìm thấy ${files.size} file"
                    )
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Phát
    // ------------------------------------------------------------------
    /** Phát theo chỉ số trong danh sách (chế độ playlist: có Next/Prev). */
    fun playIndex(ctx: Context, index: Int) {
        val files = _state.value.files
        if (index !in files.indices) return
        start(ctx, files[index], index, single = false)
    }

    /** Phát 1 file cố định (như chức năng "nhập tên file" trong music.py). */
    fun playSingle(ctx: Context, path: String) {
        val idx = _state.value.files.indexOf(path)
        start(ctx, path, idx, single = true)
    }

    private fun start(ctx: Context, path: String, index: Int, single: Boolean) {
        _state.update {
            it.copy(
                nowPlaying = path, index = index, single = single, playing = true,
                startMs = System.currentTimeMillis(), durationSec = 0.0,
                status = "Đang phát"
            )
        }
        launchMpv(ctx, path)
        probeDuration(ctx, path)
    }

    private fun launchMpv(ctx: Context, path: String) {
        val loopArg = if (_state.value.loop) "--loop=inf" else ""
        // pkill mpv rồi chạy mpv ở foreground của phiên Termux nền -> dừng bằng `pkill mpv`
        val script = "pkill mpv 2>/dev/null; sleep 0.3; exec mpv --no-video --no-terminal $loopArg ${shellQuote(path)}"
        TermuxBridge.run(ctx, script) // không cần kết quả
    }

    /** ffprobe lấy tổng thời gian (giây), giống get_media_duration() trong music.py. */
    private fun probeDuration(ctx: Context, path: String) {
        val script = "ffprobe -v quiet -print_format json -show_format ${shellQuote(path)}"
        TermuxBridge.run(ctx, script) { r ->
            val dur = try {
                JSONObject(r.stdout).optJSONObject("format")?.optString("duration")?.toDoubleOrNull() ?: 0.0
            } catch (_: Exception) {
                0.0
            }
            _state.update { s -> if (s.nowPlaying == path) s.copy(durationSec = dur) else s }
        }
    }

    fun stop(ctx: Context) {
        TermuxBridge.run(ctx, "pkill mpv 2>/dev/null")
        _state.update { it.copy(playing = false, nowPlaying = null, index = -1, status = "🛑 Đã dừng phát") }
    }

    /** Hết bài khi tắt lặp: giao diện gọi khi thời gian đã vượt thời lượng. */
    fun markFinished() {
        _state.update { if (it.playing) it.copy(playing = false, status = "Đã phát xong") else it }
    }

    fun toggleLoop(ctx: Context) {
        val s = _state.value
        val newLoop = !s.loop
        _state.update { it.copy(loop = newLoop) }
        val path = s.nowPlaying
        if (path != null && s.playing) {
            // Giống music.py: đổi chế độ lặp thì phát lại từ đầu
            _state.update { it.copy(startMs = System.currentTimeMillis()) }
            launchMpv(ctx, path)
        }
    }

    fun next(ctx: Context) = step(ctx, +1)
    fun previous(ctx: Context) = step(ctx, -1)

    private fun step(ctx: Context, delta: Int) {
        val s = _state.value
        if (s.single || s.files.isEmpty()) return
        val base = if (s.index in s.files.indices) s.index else 0
        val next = ((base + delta) % s.files.size + s.files.size) % s.files.size
        start(ctx, s.files[next], next, single = false)
    }

    // ------------------------------------------------------------------
    // Tải bằng yt-dlp
    // ------------------------------------------------------------------
    fun download(ctx: Context, kind: DownloadKind, url: String) {
        val clean = url.trim()
        if (clean.isEmpty()) {
            _state.update { it.copy(status = "Hãy dán link vào trước") }
            return
        }
        val dir = shellQuote(DOWNLOAD_DIR)
        val cmd = when (kind) {
            DownloadKind.YOUTUBE_MP3 -> "yt-dlp -x --audio-format mp3 -P $dir ${shellQuote(clean)}"
            DownloadKind.YOUTUBE_VIDEO, DownloadKind.TIKTOK -> "yt-dlp -P $dir ${shellQuote(clean)}"
        }
        val label = when (kind) {
            DownloadKind.YOUTUBE_MP3 -> "Đang tải và trích xuất MP3…"
            DownloadKind.YOUTUBE_VIDEO -> "Đang tải video YouTube…"
            DownloadKind.TIKTOK -> "Đang tải TikTok sạch logo…"
        }
        _state.update { it.copy(busy = true, status = "⏳ $label", log = "") }
        val script = "mkdir -p $dir; out=\$($cmd 2>&1); code=\$?; echo \"\$out\" | tail -n 30; exit \$code"
        TermuxBridge.run(ctx, script) { r ->
            val logText = listOfNotNull(
                r.stdout.takeIf { s -> s.isNotBlank() },
                r.stderr.takeIf { s -> s.isNotBlank() },
                r.error
            ).joinToString("\n")
            _state.update {
                it.copy(
                    busy = false,
                    status = if (r.ok) "✓ Tải xong! File nằm trong $DOWNLOAD_DIR" else "❌ Tải thất bại",
                    log = logText
                )
            }
        }
    }

    /** Cài gói cần thiết trong Termux. */
    fun installPackages(ctx: Context) {
        _state.update { it.copy(busy = true, status = "⏳ Đang cài mpv, ffmpeg, yt-dlp trong Termux…", log = "") }
        TermuxBridge.run(ctx, "yes | pkg install -y mpv ffmpeg yt-dlp 2>&1 | tail -n 30") { r ->
            _state.update {
                it.copy(
                    busy = false,
                    status = if (r.error == null) "✓ Đã chạy xong lệnh cài đặt" else "❌ ${r.error}",
                    log = r.stdout.trim()
                )
            }
        }
    }
}
