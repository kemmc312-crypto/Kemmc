package com.gamehelper.resolution.shizuku

import android.content.pm.PackageManager
import com.gamehelper.resolution.data.AppStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku
import java.lang.reflect.Method
import kotlin.concurrent.thread

/**
 * Mọi lệnh hệ thống (wm, settings, am, cmd overlay, ...) chạy qua Shizuku với quyền shell.
 * Không dùng Accessibility Service, không có tiến trình nền thường trực.
 */
object ShizukuHelper {

    enum class Status { NOT_RUNNING, NO_PERMISSION, READY }

    data class ShellResult(val out: String, val err: String, val code: Int) {
        val ok: Boolean get() = code == 0
    }

    const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
    private const val REQUEST_CODE = 7001
    private val PKG_REGEX = Regex("[A-Za-z0-9._]+")

    private val _status = MutableStateFlow(Status.NOT_RUNNING)
    val status: StateFlow<Status> = _status.asStateFlow()

    private var initialized = false

    fun init() {
        if (initialized) return
        initialized = true
        Shizuku.addBinderReceivedListenerSticky { refresh() }
        Shizuku.addBinderDeadListener { refresh() }
        Shizuku.addRequestPermissionResultListener { _, _ -> refresh() }
        refresh()
    }

    fun refresh() {
        _status.value = try {
            when {
                !Shizuku.pingBinder() -> Status.NOT_RUNNING
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> Status.READY
                else -> Status.NO_PERMISSION
            }
        } catch (e: Throwable) {
            Status.NOT_RUNNING
        }
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
        }
    }

    /** Chặn (blocking) tối đa [timeoutMs] chờ Shizuku sẵn sàng. Gọi từ luồng nền. */
    fun awaitReady(timeoutMs: Long = 2500): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            refresh()
            if (_status.value == Status.READY) return true
            Thread.sleep(100)
        }
        return _status.value == Status.READY
    }

    // newProcess là hàm private trong Shizuku API 13.x -> gọi bằng reflection (cách làm phổ biến).
    private val newProcessMethod: Method by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    /** Chạy một dòng lệnh shell với quyền Shizuku. Gọi từ luồng nền. */
    fun exec(command: String): ShellResult {
        if (_status.value != Status.READY) {
            return ShellResult("", "Shizuku chưa sẵn sàng", -1)
        }
        return try {
            val process = newProcessMethod.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            var err = ""
            val errThread = thread(isDaemon = true) {
                err = try {
                    process.errorStream.bufferedReader().readText()
                } catch (_: Exception) {
                    ""
                }
            }
            val out = process.inputStream.bufferedReader().readText()
            errThread.join(3000)
            val code = process.waitFor()
            ShellResult(out.trim(), err.trim(), code)
        } catch (e: Throwable) {
            ShellResult("", e.cause?.message ?: e.message ?: "Lỗi không xác định", -1)
        }
    }

    private fun safe(pkg: String) = PKG_REGEX.matches(pkg)

    // ------------------------------------------------------------------
    // Hiển thị
    // ------------------------------------------------------------------
    fun physicalSize(): Pair<Int, Int>? {
        val out = exec("wm size").out
        val m = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(out) ?: return null
        return m.groupValues[1].toInt() to m.groupValues[2].toInt()
    }

    fun physicalDensity(): Int? {
        val out = exec("wm density").out
        return Regex("Physical density:\\s*(\\d+)").find(out)?.groupValues?.get(1)?.toIntOrNull()
    }

    fun displayInfo(): String = exec("wm size; wm density").out

    fun applyDisplay(width: Int, height: Int, dpi: Int): ShellResult =
        exec("wm size ${width}x$height; wm density $dpi")

    /** Đổi tần số quét (lưu giá trị cũ lần đầu để khôi phục chính xác). */
    fun applyRefreshRate(hz: Int) {
        if (hz <= 0) return
        if (!AppStore.hasSavedRefresh()) {
            val peak = exec("settings get system peak_refresh_rate").out.ifBlank { "null" }
            val min = exec("settings get system min_refresh_rate").out.ifBlank { "null" }
            AppStore.saveOriginalRefresh(peak, min)
        }
        exec("settings put system peak_refresh_rate $hz; settings put system min_refresh_rate $hz")
    }

    private fun restoreRefreshRate() {
        if (!AppStore.hasSavedRefresh()) return
        fun restore(key: String, value: String) =
            if (value == "null") "settings delete system $key" else "settings put system $key $value"
        exec(restore("peak_refresh_rate", AppStore.originalPeak()) + "; " +
                restore("min_refresh_rate", AppStore.originalMin()))
        AppStore.clearSavedRefresh()
    }

    /** wm size reset + wm density reset + khôi phục Hz. */
    fun resetDisplay(): ShellResult {
        val r = exec("wm size reset; wm density reset")
        restoreRefreshRate()
        return r
    }

    // ------------------------------------------------------------------
    // Ứng dụng
    // ------------------------------------------------------------------
    fun forceStop(pkg: String): ShellResult =
        if (safe(pkg)) exec("am force-stop $pkg") else ShellResult("", "Tên package không hợp lệ", -1)

    /**
     * Vô hiệu hóa (đóng băng) một app cho user 0: app biến mất khỏi launcher, không thể chạy nền.
     * Dữ liệu của app được giữ nguyên, bật lại bằng [enablePackage].
     */
    fun disablePackage(pkg: String): ShellResult =
        if (safe(pkg)) exec("pm disable-user --user 0 $pkg") else ShellResult("", "Tên package không hợp lệ", -1)

    /** Kích hoạt lại app đã bị vô hiệu hóa. */
    fun enablePackage(pkg: String): ShellResult =
        if (safe(pkg)) exec("pm enable --user 0 $pkg") else ShellResult("", "Tên package không hợp lệ", -1)

    /** Game còn tiến trình hay không. */
    fun isProcessRunning(pkg: String): Boolean {
        if (!safe(pkg)) return false
        return exec("pidof $pkg 2>/dev/null || (ps -A 2>/dev/null | grep -w $pkg | head -n 1)").out.isNotBlank()
    }

    /** Game có đang ở trên cùng (foreground) không. null = không xác định được. */
    fun isForeground(pkg: String): Boolean? {
        if (!safe(pkg)) return null
        val out = exec("dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity|ResumedActivity'").out
        if (out.isBlank()) return null
        return out.contains(pkg)
    }

    /** Dọn RAM: force-stop mọi app người dùng cài, trừ danh sách loại trừ. Trả về số app đã dừng. */
    fun cleanRam(exclude: Set<String>): Int {
        val pkgs = exec("pm list packages -3").out.lines()
            .map { it.trim() }
            .filter { it.startsWith("package:") }
            .map { it.removePrefix("package:") }
            .filter { safe(it) && it !in exclude }
        pkgs.chunked(20).forEach { chunk ->
            exec(chunk.joinToString("; ") { "am force-stop $it" })
        }
        return pkgs.size
    }

    // ------------------------------------------------------------------
    // Điều hướng
    // ------------------------------------------------------------------
    fun setNavigationMode(gesture: Boolean): ShellResult {
        val overlay = if (gesture) "com.android.internal.systemui.navbar.gestural"
        else "com.android.internal.systemui.navbar.threebutton"
        return exec("cmd overlay enable $overlay")
    }
}
