package com.gamehelper.resolution.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray

/** Kho lưu cài đặt + danh sách game (SharedPreferences, truy cập được từ Service/Tile). */
object AppStore {
    private const val PREFS = "game_helper_store"
    private lateinit var prefs: SharedPreferences

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _games = MutableStateFlow<List<GameConfig>>(emptyList())
    val games: StateFlow<List<GameConfig>> = _games.asStateFlow()

    fun init(context: Context) {
        if (::prefs.isInitialized) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        _settings.value = loadSettings()
        _games.value = loadGames()
    }

    // ---------------- Settings ----------------
    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        _settings.update(transform)
        saveSettings(_settings.value)
    }

    private fun loadSettings(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            defaultWidth = prefs.getInt("defaultWidth", d.defaultWidth),
            defaultHeight = prefs.getInt("defaultHeight", d.defaultHeight),
            defaultDpi = prefs.getInt("defaultDpi", d.defaultDpi),
            defaultHz = prefs.getInt("defaultHz", d.defaultHz),
            glassEnabled = prefs.getBoolean("glassEnabled", d.glassEnabled),
            videoBgEnabled = prefs.getBoolean("videoBgEnabled", d.videoBgEnabled),
            videoUri = prefs.getString("videoUri", d.videoUri) ?: "",
            videoAudioEnabled = prefs.getBoolean("videoAudioEnabled", d.videoAudioEnabled),
            videoVolume = prefs.getFloat("videoVolume", d.videoVolume),
            safetyGuard = prefs.getBoolean("safetyGuard", d.safetyGuard),
            lockAspect = prefs.getBoolean("lockAspect", d.lockAspect),
            navSwitchEnabled = prefs.getBoolean("navSwitchEnabled", d.navSwitchEnabled),
            autoResetMonitor = prefs.getBoolean("autoResetMonitor", d.autoResetMonitor),
            tileEnabled = prefs.getBoolean("tileEnabled", d.tileEnabled),
            ramCleanEnabled = prefs.getBoolean("ramCleanEnabled", d.ramCleanEnabled),
            ramExclusions = prefs.getString("ramExclusions", d.ramExclusions) ?: "",
            floatingEnabled = prefs.getBoolean("floatingEnabled", d.floatingEnabled),
            floatingSizeDp = prefs.getInt("floatingSizeDp", d.floatingSizeDp),
            floatingAutoScale = prefs.getBoolean("floatingAutoScale", d.floatingAutoScale),
            defaultDelaySec = prefs.getInt("defaultDelaySec", d.defaultDelaySec),
            presetsEnabled = prefs.getBoolean("presetsEnabled", d.presetsEnabled)
        )
    }

    private fun saveSettings(s: AppSettings) {
        prefs.edit()
            .putInt("defaultWidth", s.defaultWidth)
            .putInt("defaultHeight", s.defaultHeight)
            .putInt("defaultDpi", s.defaultDpi)
            .putInt("defaultHz", s.defaultHz)
            .putBoolean("glassEnabled", s.glassEnabled)
            .putBoolean("videoBgEnabled", s.videoBgEnabled)
            .putString("videoUri", s.videoUri)
            .putBoolean("videoAudioEnabled", s.videoAudioEnabled)
            .putFloat("videoVolume", s.videoVolume)
            .putBoolean("safetyGuard", s.safetyGuard)
            .putBoolean("lockAspect", s.lockAspect)
            .putBoolean("navSwitchEnabled", s.navSwitchEnabled)
            .putBoolean("autoResetMonitor", s.autoResetMonitor)
            .putBoolean("tileEnabled", s.tileEnabled)
            .putBoolean("ramCleanEnabled", s.ramCleanEnabled)
            .putString("ramExclusions", s.ramExclusions)
            .putBoolean("floatingEnabled", s.floatingEnabled)
            .putInt("floatingSizeDp", s.floatingSizeDp)
            .putBoolean("floatingAutoScale", s.floatingAutoScale)
            .putInt("defaultDelaySec", s.defaultDelaySec)
            .putBoolean("presetsEnabled", s.presetsEnabled)
            .apply()
    }

    // ---------------- Games ----------------
    fun getGame(pkg: String): GameConfig? = _games.value.firstOrNull { it.packageName == pkg }

    fun upsertGame(game: GameConfig) {
        _games.update { list ->
            val idx = list.indexOfFirst { it.packageName == game.packageName }
            if (idx >= 0) list.toMutableList().also { it[idx] = game } else list + game
        }
        saveGames()
    }

    fun deleteGame(pkg: String) {
        _games.update { list -> list.filterNot { it.packageName == pkg } }
        saveGames()
    }

    private fun loadGames(): List<GameConfig> {
        val raw = prefs.getString("games", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { GameConfig.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveGames() {
        val arr = JSONArray()
        _games.value.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("games", arr.toString()).apply()
    }

    // ---------------- Tần số quét gốc (để khôi phục đúng) ----------------
    fun hasSavedRefresh(): Boolean = prefs.getBoolean("refresh_saved", false)

    fun saveOriginalRefresh(peak: String, min: String) {
        prefs.edit()
            .putBoolean("refresh_saved", true)
            .putString("orig_peak", peak)
            .putString("orig_min", min)
            .apply()
    }

    fun originalPeak(): String = prefs.getString("orig_peak", "null") ?: "null"
    fun originalMin(): String = prefs.getString("orig_min", "null") ?: "null"

    fun clearSavedRefresh() {
        prefs.edit().putBoolean("refresh_saved", false).apply()
    }
}
