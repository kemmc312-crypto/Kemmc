package com.gamehelper.resolution

import android.app.Application
import com.gamehelper.resolution.data.AppStore
import com.gamehelper.resolution.shizuku.ShizukuHelper
import com.gamehelper.resolution.tile.TileHelper

class GameHelperApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppStore.init(this)
        ShizukuHelper.init()
        // Đồng bộ trạng thái bật/tắt của ô Cài đặt nhanh
        TileHelper.setEnabled(this, AppStore.settings.value.tileEnabled)
    }
}
