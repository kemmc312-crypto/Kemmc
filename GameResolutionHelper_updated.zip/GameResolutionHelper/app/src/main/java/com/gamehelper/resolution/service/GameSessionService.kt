package com.gamehelper.resolution.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.gamehelper.resolution.MainActivity
import com.gamehelper.resolution.R
import com.gamehelper.resolution.data.AppSettings
import com.gamehelper.resolution.data.AppStore
import com.gamehelper.resolution.data.ResolutionCalc
import com.gamehelper.resolution.shizuku.ShizukuHelper
import com.gamehelper.resolution.toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Chỉ chạy khi người dùng bấm Play / Shortcut, và tự tắt khi xong việc.
 *
 * Quy trình: Dọn RAM (nếu bật) -> Kiểm tra an toàn phân giải -> Khóa tỷ lệ -> Đổi phân giải (Shizuku)
 *            -> Hiện nút nổi (nếu bật) -> Delay -> Mở game -> (tùy chọn) theo dõi để tự reset.
 */
class GameSessionService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var floating: FloatingButton? = null
    private var sessionJob: Job? = null
    private var currentPkg: String? = null
    private var ending = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startInForeground("Đang chuẩn bị…")
        when (intent?.action) {
            ACTION_START -> {
                val pkg = intent.getStringExtra(EXTRA_PKG)
                if (pkg == null) stopSelfClean() else startSession(pkg)
            }
            ACTION_RESET -> endSession(kill = intent.getBooleanExtra(EXTRA_KILL, false))
            else -> stopSelfClean()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        instance = null
        floating?.hide()
        floating = null
        activePackage.value = null
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // Phiên chơi
    // ------------------------------------------------------------------
    private fun startSession(pkg: String) {
        sessionJob?.cancel()
        ending = false
        sessionJob = scope.launch {
            val settings = AppStore.settings.value
            val game = AppStore.getGame(pkg)
            if (game == null) {
                toast("Không tìm thấy cấu hình của game này")
                stopSelfClean()
                return@launch
            }
            if (ShizukuHelper.status.value != ShizukuHelper.Status.READY) {
                toast("Shizuku chưa chạy hoặc chưa cấp quyền", long = true)
                stopSelfClean()
                return@launch
            }

            currentPkg = pkg
            activePackage.value = pkg
            setStage("${game.displayName}: bắt đầu")

            val excludes = if (settings.ramCleanEnabled) buildExcludes(settings, pkg) else emptySet()

            // Resolution Safety Guard + Lock Aspect Ratio
            val lockEffective = settings.lockAspect && game.lockRatio
            val res = ResolutionCalc.resolve(
                width = game.width,
                height = game.height,
                dpi = game.dpi,
                lockRatio = lockEffective,
                baseW = settings.defaultWidth,
                baseH = settings.defaultHeight,
                guard = settings.safetyGuard
            )

            val applied = withContext(Dispatchers.IO) {
                if (settings.ramCleanEnabled) {
                    setStage("Đang dọn RAM…")
                    ShizukuHelper.cleanRam(excludes)
                }
                setStage("Đang đổi phân giải ${res.width}×${res.height}…")
                val r = ShizukuHelper.applyDisplay(res.width, res.height, res.dpi)
                if (r.ok && game.hz > 0) ShizukuHelper.applyRefreshRate(game.hz)
                r
            }

            if (!applied.ok) {
                toast("Đổi phân giải thất bại: ${applied.err.ifBlank { "không rõ lỗi" }}", long = true)
                endSession(kill = false)
                return@launch
            }
            if (res.adjusted) {
                toast("Đã nâng lên mức an toàn ${res.width}×${res.height} (Safety Guard)", long = true)
            }

            if (settings.floatingEnabled && Settings.canDrawOverlays(this@GameSessionService)) {
                // Chờ hệ thống cập nhật xong DisplayMetrics để nút đo đúng kích thước mới
                delay(400)
                showFloating()
            }

            if (game.delaySec > 0) {
                setStage("Chờ ${game.delaySec}s trước khi mở game…")
                delay(game.delaySec * 1000L)
            }

            launchGame(pkg)
            setStage("Đang chơi ${game.displayName}")

            when {
                settings.autoResetMonitor -> monitorGame(pkg)
                !settings.floatingEnabled -> stopSelfClean() // không còn việc gì để giữ service
                else -> Unit
            }
        }
    }

    private fun buildExcludes(s: AppSettings, gamePkg: String): Set<String> {
        val set = mutableSetOf(
            packageName, gamePkg, ShizukuHelper.SHIZUKU_PKG,
            "com.termux", "com.termux.api", "com.termux.boot", "com.termux.widget", "com.termux.x11"
        )
        // Launcher hiện tại
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName?.let { set.add(it) }
        // Bàn phím hiện tại
        try {
            Settings.Secure.getString(contentResolver, "default_input_method")
                ?.substringBefore('/')?.takeIf { it.isNotBlank() }?.let { set.add(it) }
        } catch (_: Exception) {
        }
        // Danh sách người dùng tự thêm
        s.ramExclusions.split(',', ' ', '\n', ';').map { it.trim() }.filter { it.isNotEmpty() }
            .forEach { set.add(it) }
        return set
    }

    private fun launchGame(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            toast("Không mở được game (không có launch intent)", long = true)
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(intent)
        } catch (_: Exception) {
        }
        // Phòng trường hợp Android chặn mở Activity từ nền: dùng shell (Shizuku) làm phương án dự phòng.
        val component = intent.component?.flattenToShortString()
        if (component != null) {
            scope.launch {
                delay(2500)
                val running = withContext(Dispatchers.IO) { ShizukuHelper.isForeground(pkg) }
                if (running == false) {
                    withContext(Dispatchers.IO) { ShizukuHelper.exec("am start -n $component") }
                }
            }
        }
    }

    /** Auto-Reset Monitor: khi game không còn ở foreground (liên tục ~9s) hoặc tiến trình đã chết thì khôi phục. */
    private suspend fun monitorGame(pkg: String) {
        var seen = false
        var missing = 0
        val startedAt = System.currentTimeMillis()
        while (true) {
            delay(3000)
            val fg = withContext(Dispatchers.IO) {
                val alive = ShizukuHelper.isProcessRunning(pkg)
                if (!alive) false else ShizukuHelper.isForeground(pkg)
            }
            when (fg) {
                true -> {
                    seen = true
                    missing = 0
                }
                false -> {
                    missing++
                    val gaveUpWaiting = !seen && System.currentTimeMillis() - startedAt > 45_000
                    if ((seen && missing >= 3) || gaveUpWaiting) break
                }
                null -> Unit // không xác định -> bỏ qua lượt này
            }
        }
        endSession(kill = false)
    }

    private fun showFloating() {
        if (floating == null) {
            floating = FloatingButton(this) {
                // Nút nổi 2-trong-1: khôi phục hiển thị + force-stop game
                endSession(kill = true)
            }
        }
        floating?.show()
    }

    /** Khôi phục hiển thị; nếu [kill] thì force-stop cả game. Sau đó ẩn nút nổi và tắt service. */
    fun endSession(kill: Boolean) {
        if (ending) return
        ending = true
        val pkg = currentPkg
        sessionJob?.cancel()
        scope.launch {
            floating?.hide()
            setStage("Đang khôi phục…")
            withContext(Dispatchers.IO) {
                ShizukuHelper.resetDisplay()
                if (kill && pkg != null) ShizukuHelper.forceStop(pkg)
            }
            currentPkg = null
            activePackage.value = null
            stopSelfClean()
        }
    }

    private fun stopSelfClean() {
        floating?.hide()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ------------------------------------------------------------------
    // Notification
    // ------------------------------------------------------------------
    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Phiên chơi game", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String): Notification {
        val resetIntent = PendingIntent.getService(
            this, 1,
            Intent(this, GameSessionService::class.java).setAction(ACTION_RESET).putExtra(EXTRA_KILL, false),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("GameResolutionHelper")
            .setContentText(text)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openIntent)
            .addAction(0, "Reset màn hình", resetIntent)
            .build()
    }

    private fun startInForeground(text: String) {
        val n = buildNotification(text)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun setStage(text: String) {
        stage.value = text
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    // ------------------------------------------------------------------
    companion object {
        const val ACTION_START = "com.gamehelper.resolution.action.START"
        const val ACTION_RESET = "com.gamehelper.resolution.action.RESET"
        const val EXTRA_PKG = "pkg"
        const val EXTRA_KILL = "kill"
        private const val CHANNEL_ID = "game_session"
        private const val NOTIF_ID = 1001

        @Volatile
        var instance: GameSessionService? = null
            private set

        private val _activePackage = MutableStateFlow<String?>(null)
        val activePackage: MutableStateFlow<String?> get() = _activePackage

        private val _stage = MutableStateFlow("")
        val stage: MutableStateFlow<String> get() = _stage

        /** Kiểm tra điều kiện trước khi chạy. Trả về thông báo lỗi hoặc null nếu ổn. */
        fun preflight(ctx: Context): String? {
            if (ShizukuHelper.status.value != ShizukuHelper.Status.READY) {
                return "Shizuku chưa chạy hoặc chưa cấp quyền cho app"
            }
            if (AppStore.settings.value.floatingEnabled && !Settings.canDrawOverlays(ctx)) {
                return "Cần cấp quyền 'Hiển thị trên các ứng dụng khác' để dùng nút nổi"
            }
            return null
        }

        /** Nút Play / Shortcut: kiểm tra rồi khởi động phiên. */
        fun play(ctx: Context, pkg: String): Boolean {
            val err = preflight(ctx)
            if (err != null) {
                ctx.toast(err, long = true)
                if (AppStore.settings.value.floatingEnabled && !Settings.canDrawOverlays(ctx)) {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
                return false
            }
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, GameSessionService::class.java)
                    .setAction(ACTION_START)
                    .putExtra(EXTRA_PKG, pkg)
            )
            return true
        }

        /** Yêu cầu kết thúc phiên đang chạy. Trả về false nếu không có phiên nào. */
        fun requestEnd(kill: Boolean): Boolean {
            val s = instance ?: return false
            Handler(Looper.getMainLooper()).post { s.endSession(kill) }
            return true
        }
    }
}
