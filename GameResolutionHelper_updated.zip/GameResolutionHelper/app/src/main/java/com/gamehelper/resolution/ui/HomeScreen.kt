package com.gamehelper.resolution.ui

import android.content.Intent
import android.hardware.display.DisplayManager
import android.net.Uri
import android.provider.Settings as AndroidSettings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gamehelper.resolution.data.AppStore
import com.gamehelper.resolution.service.GameSessionService
import com.gamehelper.resolution.shizuku.ShizukuHelper
import com.gamehelper.resolution.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun HomeScreen(padding: PaddingValues) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val shizuku by ShizukuHelper.status.collectAsStateWithLifecycle()
    val active by GameSessionService.activePackage.collectAsStateWithLifecycle()
    val stage by GameSessionService.stage.collectAsStateWithLifecycle()
    val settings by AppStore.settings.collectAsStateWithLifecycle()

    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        ShizukuHelper.refresh()
        tick++
    }
    val overlayOk = remember(tick) { AndroidSettings.canDrawOverlays(ctx) }

    var displayInfo by remember { mutableStateOf("") }
    var lastActive by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(active) { if (active != null) lastActive = active }

    suspend fun reloadDisplayInfo() {
        displayInfo = if (shizuku == ShizukuHelper.Status.READY) {
            withContext(Dispatchers.IO) { ShizukuHelper.displayInfo() }
        } else ""
    }
    LaunchedEffect(shizuku, active, tick) { reloadDisplayInfo() }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 16.dp, end = 16.dp,
            top = padding.calculateTopPadding() + 12.dp,
            bottom = padding.calculateBottomPadding() + 16.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text("GameResolutionHelper", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Đổi phân giải theo yêu cầu · không Accessibility ngầm",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f)
                )
            }
        }

        // Phiên đang chạy
        item {
            AnimatedVisibility(
                visible = active != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                GlassCard {
                    SectionTitle("Đang trong phiên chơi")
                    val name = lastActive?.let { AppStore.getGame(it)?.displayName ?: it } ?: ""
                    Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(stage, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GlassButton(onClick = { GameSessionService.requestEnd(kill = false) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.RestartAlt, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Reset")
                        }
                        GlassButton(
                            onClick = { GameSessionService.requestEnd(kill = true) },
                            modifier = Modifier.weight(1f),
                            danger = true
                        ) {
                            Icon(Icons.Rounded.Stop, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Reset & thoát game")
                        }
                    }
                }
            }
        }

        // Trạng thái hệ thống
        item {
            GlassCard {
                SectionTitle("Trạng thái")
                when (shizuku) {
                    ShizukuHelper.Status.READY ->
                        StatusRow(true, "Shizuku", "Đã kết nối và được cấp quyền")
                    ShizukuHelper.Status.NO_PERMISSION ->
                        StatusRow(false, "Shizuku", "Đang chạy nhưng app chưa được cấp quyền", "Cấp quyền") {
                            ShizukuHelper.requestPermission()
                        }
                    ShizukuHelper.Status.NOT_RUNNING ->
                        StatusRow(false, "Shizuku", "Chưa chạy. Hãy khởi động Shizuku (ADB không dây hoặc root).", "Mở Shizuku") {
                            val i = ctx.packageManager.getLaunchIntentForPackage(ShizukuHelper.SHIZUKU_PKG)
                            if (i != null) ctx.startActivity(i) else ctx.toast("Chưa cài Shizuku", long = true)
                        }
                }
                StatusRow(
                    overlayOk, "Nút nổi (quyền hiển thị trên app khác)",
                    if (overlayOk) "Đã cấp" else "Chưa cấp — cần để hiện nút nổi",
                    if (overlayOk) null else "Cấp quyền"
                ) {
                    ctx.startActivity(
                        Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    )
                }
            }
        }

        // Hiển thị hiện tại
        item {
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle("Màn hình hiện tại", Modifier.weight(1f))
                    GlassTextButton(onClick = { scope.launch { reloadDisplayInfo() } }) {
                        Icon(Icons.Rounded.Refresh, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Làm mới")
                    }
                }
                Text(
                    text = displayInfo.ifBlank { "— (cần Shizuku sẵn sàng)" },
                    fontFamily = FontFamily.Monospace,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))
                GlassButton(emphasis = true, 
                    onClick = {
                        scope.launch {
                            if (!GameSessionService.requestEnd(kill = false)) {
                                val r = withContext(Dispatchers.IO) {
                                    ShizukuHelper.awaitReady(1500)
                                    ShizukuHelper.resetDisplay()
                                }
                                ctx.toast(if (r.ok) "Đã khôi phục độ phân giải gốc" else "Reset thất bại: ${r.err}", long = !r.ok)
                            } else {
                                ctx.toast("Đã khôi phục màn hình")
                            }
                            reloadDisplayInfo()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = shizuku == ShizukuHelper.Status.READY
                ) {
                    Icon(Icons.Rounded.RestartAlt, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Reset về độ phân giải gốc ngay")
                }
            }
        }

        // Tóm tắt thông số gốc
        item {
            GlassCard {
                SectionTitle("Thông số gốc đã cấu hình")
                Text(
                    "${settings.defaultWidth}×${settings.defaultHeight} · ${settings.defaultDpi} dpi · ${settings.defaultHz} Hz",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    "Chỉnh trong Cài đặt. Vào tab Game để thêm game, bấm Play hoặc tạo Shortcut ra màn hình chính.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
        }
    }
}

@Composable
private fun StatusRow(
    ok: Boolean,
    title: String,
    detail: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    val tint by animateColorAsState(
        if (ok) Color.White else Color(0xFF9E9E9E), label = "status-tint"
    )
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.Error, null, tint = tint, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        }
        if (actionLabel != null && onAction != null) {
            GlassTextButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}

/** Dùng bởi Settings: đọc thông số thật của máy. */
suspend fun detectDeviceDisplay(ctx: android.content.Context): Boolean {
    val size = withContext(Dispatchers.IO) { ShizukuHelper.physicalSize() }
    val dpi = withContext(Dispatchers.IO) { ShizukuHelper.physicalDensity() }
    val hz = try {
        val dm = ctx.getSystemService(android.content.Context.DISPLAY_SERVICE) as DisplayManager
        dm.getDisplay(0)?.refreshRate?.roundToInt()
    } catch (_: Exception) {
        null
    }
    if (size == null) return false
    AppStore.updateSettings {
        it.copy(
            defaultWidth = size.first,
            defaultHeight = size.second,
            defaultDpi = dpi ?: it.defaultDpi,
            defaultHz = hz ?: it.defaultHz
        )
    }
    return true
}
