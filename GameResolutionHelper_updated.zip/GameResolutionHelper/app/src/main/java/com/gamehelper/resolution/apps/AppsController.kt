package com.gamehelper.resolution.apps

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings
import com.gamehelper.resolution.shizuku.ShizukuHelper
import com.gamehelper.resolution.toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Một ứng dụng trong danh sách quản lý. */
data class PackageItem(
    val label: String,
    val packageName: String,
    /** App hệ thống (FLAG_SYSTEM), kể cả app hệ thống đã được cập nhật. */
    val isSystem: Boolean,
    /** true = đang bật, false = đang bị vô hiệu hóa. */
    val enabled: Boolean,
    /** Khác null = không cho tắt, nội dung là lý do. */
    val protectedReason: String?
)

data class AppsState(
    val apps: List<PackageItem> = emptyList(),
    val loading: Boolean = false,
    /** Đã quét xong ít nhất một lần. */
    val loaded: Boolean = false,
    /** Các package đang chờ lệnh Shizuku chạy xong. */
    val busy: Set<String> = emptySet()
)

/**
 * Quét danh sách package bằng PackageManager (cần QUERY_ALL_PACKAGES) và bật/tắt app bằng lệnh `pm`
 * chạy qua Shizuku. State nằm trong singleton nên không bị mất khi chuyển tab.
 */
object AppsController {

    /** Các package mà tắt đi có thể làm máy mất giao diện / mất kết nối / không cấp quyền được nữa. */
    private val CORE_PACKAGES = setOf(
        "android",
        "com.android.systemui",
        "com.android.settings",
        "com.android.phone",
        "com.android.server.telecom",
        "com.android.providers.settings",
        "com.android.providers.telephony",
        "com.android.shell",
        "com.android.externalstorage",
        "com.android.inputdevices",
        "com.android.keychain",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller"
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _state = MutableStateFlow(AppsState())
    val state: StateFlow<AppsState> = _state.asStateFlow()

    // ------------------------------------------------------------------
    // Quét danh sách
    // ------------------------------------------------------------------
    fun refresh(ctx: Context) {
        if (_state.value.loading) return
        val app = ctx.applicationContext
        _state.update { it.copy(loading = true) }
        scope.launch {
            val scanned = try {
                withContext(Dispatchers.IO) { scan(app) }
            } catch (_: Exception) {
                null
            }
            _state.update { s ->
                if (scanned == null) {
                    s.copy(loading = false)
                } else {
                    // App đang chờ lệnh thì giữ nguyên trạng thái cũ, tránh công tắc nhảy qua lại.
                    val old = s.apps.associateBy { it.packageName }
                    val merged = scanned.map { n -> if (n.packageName in s.busy) old[n.packageName] ?: n else n }
                    s.copy(apps = merged, loading = false, loaded = true)
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun scan(ctx: Context): List<PackageItem> {
        val pm = ctx.packageManager
        val guarded = protectedPackages(ctx)
        return pm.getInstalledApplications(0)
            .map { ai ->
                val label = try {
                    ai.loadLabel(pm).toString()
                } catch (_: Exception) {
                    ""
                }
                PackageItem(
                    label = label.ifBlank { ai.packageName },
                    packageName = ai.packageName,
                    isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                    enabled = ai.enabled,
                    protectedReason = guarded[ai.packageName]
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    /** package -> lý do không cho tắt. */
    @Suppress("DEPRECATION")
    private fun protectedPackages(ctx: Context): Map<String, String> {
        val map = HashMap<String, String>()
        fun put(pkg: String?, reason: String) {
            if (!pkg.isNullOrBlank()) map.putIfAbsent(pkg, reason)
        }

        put(ctx.packageName, "Chính ứng dụng này")
        put(ShizukuHelper.SHIZUKU_PKG, "Shizuku, cần để chạy lệnh")
        CORE_PACKAGES.forEach { put(it, "Thành phần cốt lõi của hệ thống") }

        // Mọi launcher (tắt launcher là mất màn hình chính)
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            ctx.packageManager.queryIntentActivities(home, 0)
                .forEach { put(it.activityInfo.packageName, "Launcher hiện tại") }
        } catch (_: Exception) {
        }
        // Bàn phím đang dùng (tắt là không gõ được)
        try {
            put(
                Settings.Secure.getString(ctx.contentResolver, "default_input_method")?.substringBefore('/'),
                "Bàn phím hiện tại"
            )
        } catch (_: Exception) {
        }
        return map
    }

    // ------------------------------------------------------------------
    // Bật / tắt
    // ------------------------------------------------------------------
    /** [enable] = true: kích hoạt lại; false: vô hiệu hóa (đóng băng). */
    fun setEnabled(ctx: Context, pkg: String, enable: Boolean) {
        val app = ctx.applicationContext
        val s = _state.value
        val item = s.apps.firstOrNull { it.packageName == pkg } ?: return
        if (pkg in s.busy) return
        if (!enable && item.protectedReason != null) {
            app.toast("Không thể tắt “${item.label}”: ${item.protectedReason}", long = true)
            return
        }

        _state.update { it.copy(busy = it.busy + pkg) }
        scope.launch {
            val outcome = withContext(Dispatchers.IO) { apply(app, pkg, enable) }
            _state.update { st ->
                val now = outcome.enabledNow
                st.copy(
                    busy = st.busy - pkg,
                    apps = if (now == null) st.apps
                    else st.apps.map { if (it.packageName == pkg) it.copy(enabled = now) else it }
                )
            }
            app.toast(
                when {
                    outcome.success && enable -> "Đã bật lại “${item.label}”"
                    outcome.success -> "Đã tắt “${item.label}”"
                    else -> "Không đổi được “${item.label}”: ${outcome.error}"
                },
                long = !outcome.success
            )
        }
    }

    private class Outcome(val success: Boolean, val enabledNow: Boolean?, val error: String)

    /** Chạy lệnh rồi đọc lại trạng thái thật từ PackageManager để xác nhận. Gọi từ luồng nền. */
    private fun apply(ctx: Context, pkg: String, enable: Boolean): Outcome {
        if (!ShizukuHelper.awaitReady(1500)) {
            return Outcome(false, null, "Shizuku chưa sẵn sàng")
        }
        val r = if (enable) ShizukuHelper.enablePackage(pkg) else ShizukuHelper.disablePackage(pkg)
        val shellFailed = !r.ok ||
                r.out.contains("Exception", ignoreCase = true) ||
                r.err.contains("Exception", ignoreCase = true) ||
                r.out.startsWith("Error", ignoreCase = true)

        // Hệ thống cập nhật trạng thái hơi trễ nên thử đọc lại vài lần.
        var actual: Boolean? = null
        for (i in 0 until 5) {
            actual = readEnabled(ctx, pkg)
            if (actual == enable) break
            Thread.sleep(150)
        }

        val shellMessage = listOf(r.err, r.out).firstOrNull { it.isNotBlank() }
            ?.lines()?.firstOrNull { it.isNotBlank() }?.take(140)
            ?: "mã lỗi ${r.code}"

        return when {
            actual == enable -> Outcome(true, enable, "")
            actual == null && !shellFailed -> Outcome(true, enable, "") // không đọc lại được, tin vào lệnh
            shellFailed -> Outcome(false, actual, shellMessage)
            else -> Outcome(false, actual, "hệ thống không đổi trạng thái app")
        }
    }

    /** true = đang bật, false = đang tắt, null = không đọc được. */
    @Suppress("DEPRECATION")
    private fun readEnabled(ctx: Context, pkg: String): Boolean? = try {
        ctx.packageManager.getApplicationInfo(pkg, 0).enabled
    } catch (_: PackageManager.NameNotFoundException) {
        null
    }
}
