package com.gamehelper.resolution.service

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.gamehelper.resolution.shizuku.ShizukuHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Đích của Shortcut trên màn hình chính: trong suốt, chỉ khởi động phiên chơi rồi tự đóng.
 */
class LaunchActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra(EXTRA_PKG)
        if (pkg == null) {
            finish()
            return
        }
        lifecycleScope.launch {
            // Process mới khởi động: chờ Shizuku gửi binder (tối đa ~2.5s)
            withContext(Dispatchers.IO) { ShizukuHelper.awaitReady(2500) }
            GameSessionService.play(this@LaunchActivity, pkg)
            finish()
        }
    }

    companion object {
        const val ACTION_LAUNCH = "com.gamehelper.resolution.action.LAUNCH_GAME"
        const val EXTRA_PKG = "pkg"
    }
}
