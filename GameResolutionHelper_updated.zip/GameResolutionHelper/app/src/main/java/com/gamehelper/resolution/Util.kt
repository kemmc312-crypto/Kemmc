package com.gamehelper.resolution

import android.content.Context
import android.widget.Toast

fun Context.toast(message: String, long: Boolean = false) {
    Toast.makeText(applicationContext, message, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
}

/** Bọc chuỗi trong nháy đơn để truyền an toàn vào shell. */
fun shellQuote(s: String): String = "'" + s.replace("'", "'\\''") + "'"

fun formatTime(seconds: Double): String {
    val total = if (seconds.isNaN() || seconds < 0) 0 else seconds.toInt()
    return "%02d:%02d".format(total / 60, total % 60)
}
