package com.gamehelper.resolution.data

import kotlin.math.ceil
import kotlin.math.min

/** Tính toán độ phân giải thực tế: khóa tỷ lệ + Resolution Safety Guard. */
object ResolutionCalc {
    /** Cạnh ngắn tối thiểu cho phép (tránh kẹt màn hình / mất nút lệnh). */
    const val MIN_SAFE_SHORT = 250
    const val MIN_SAFE_DPI = 72

    data class Resolved(val width: Int, val height: Int, val dpi: Int, val adjusted: Boolean)

    private fun even(v: Int) = (v + 1) / 2 * 2

    /** Chiều cao theo tỷ lệ của màn hình gốc. */
    fun lockedHeight(width: Int, baseW: Int, baseH: Int): Int {
        if (baseW <= 0 || baseH <= 0) return width
        return even((width.toLong() * baseH / baseW).toInt())
    }

    fun resolve(
        width: Int,
        height: Int,
        dpi: Int,
        lockRatio: Boolean,
        baseW: Int,
        baseH: Int,
        guard: Boolean
    ): Resolved {
        var w = width.coerceAtLeast(1)
        var h = if (lockRatio) lockedHeight(w, baseW, baseH) else height.coerceAtLeast(1)
        var d = dpi.coerceAtLeast(1)
        var adjusted = false

        if (guard) {
            val short = min(w, h)
            if (short < MIN_SAFE_SHORT) {
                adjusted = true
                if (lockRatio) {
                    // Nâng cả hai cạnh theo cùng hệ số để giữ tỷ lệ (16:9, 4:3, ...)
                    val f = MIN_SAFE_SHORT.toDouble() / short
                    w = even(ceil(w * f).toInt())
                    h = even(ceil(h * f).toInt())
                } else {
                    w = w.coerceAtLeast(MIN_SAFE_SHORT)
                    h = h.coerceAtLeast(MIN_SAFE_SHORT)
                }
            }
            if (d < MIN_SAFE_DPI) {
                d = MIN_SAFE_DPI
                adjusted = true
            }
        }
        return Resolved(w, h, d, adjusted)
    }
}
