package com.gamehelper.resolution.tile

import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import com.gamehelper.resolution.R

object TileHelper {
    private fun component(ctx: Context) = ComponentName(ctx, ResetTileService::class.java)

    /** Bật/tắt hẳn ô cài đặt nhanh (ẩn/hiện khỏi danh sách tile). */
    fun setEnabled(ctx: Context, enabled: Boolean) {
        ctx.packageManager.setComponentEnabledSetting(
            component(ctx),
            if (enabled) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }

    /** Android 13+: hiện hộp thoại thêm tile vào thanh Cài đặt nhanh. */
    fun requestAdd(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 33) return false
        return try {
            val sbm = ctx.getSystemService(StatusBarManager::class.java)
            sbm.requestAddTileService(
                component(ctx),
                ctx.getString(R.string.tile_label),
                Icon.createWithResource(ctx, R.drawable.ic_tile),
                ctx.mainExecutor
            ) { }
            true
        } catch (_: Exception) {
            false
        }
    }
}
