package com.gamehelper.resolution.termux

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Nhận kết quả (stdout/stderr/exitCode) mà Termux gửi về qua PendingIntent. */
class TermuxResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("reqId", -1)
        if (id != -1) TermuxBridge.deliver(id, intent)
    }
}
