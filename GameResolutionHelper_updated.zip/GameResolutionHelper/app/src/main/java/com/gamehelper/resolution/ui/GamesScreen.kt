package com.gamehelper.resolution.ui

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddToHomeScreen
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gamehelper.resolution.data.AppStore
import com.gamehelper.resolution.data.GameConfig
import com.gamehelper.resolution.data.Presets
import com.gamehelper.resolution.data.ResolutionCalc
import com.gamehelper.resolution.service.GameSessionService
import com.gamehelper.resolution.service.ShortcutHelper
import com.gamehelper.resolution.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class AppEntry(val label: String, val pkg: String)

@Composable
fun GamesScreen(padding: PaddingValues) {
    val ctx = LocalContext.current
    val games by AppStore.games.collectAsStateWithLifecycle()
    val settings by AppStore.settings.collectAsStateWithLifecycle()
    val active by GameSessionService.activePackage.collectAsStateWithLifecycle()

    var showPicker by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<GameConfig?>(null) }
    var editingIsNew by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<GameConfig?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp,
                top = padding.calculateTopPadding() + 12.dp,
                bottom = padding.calculateBottomPadding() + 88.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column {
                    Text("Danh sách game", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Mỗi game có cấu hình riêng. Play để chạy ngay, hoặc tạo Shortcut ra màn hình chính.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f)
                    )
                }
            }
            if (games.isEmpty()) {
                item {
                    GlassCard {
                        Icon(Icons.Rounded.SportsEsports, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(8.dp))
                        Text("Chưa có game nào. Bấm “Thêm game” để bắt đầu.", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
            items(games, key = { it.packageName }) { g ->
                GameCard(
                    game = g,
                    running = active == g.packageName,
                    modifier = Modifier.animateItem(),
                    onPlay = { GameSessionService.play(ctx, g.packageName) },
                    onShortcut = {
                        if (ShortcutHelper.pin(ctx, g)) ctx.toast("Hãy xác nhận thêm lối tắt trên màn hình chính")
                        else ctx.toast("Launcher không hỗ trợ tạo lối tắt", long = true)
                    },
                    onEdit = { editing = g; editingIsNew = false },
                    onDelete = { deleting = g }
                )
            }
        }

        GlassFab(
            onClick = { showPicker = true },
            icon = { Icon(Icons.Rounded.Add, null) },
            text = { Text("Thêm game") },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = padding.calculateBottomPadding() + 16.dp)
        )
    }

    if (showPicker) {
        AppPickerDialog(
            existing = games.map { it.packageName }.toSet(),
            onDismiss = { showPicker = false },
            onPick = { entry ->
                showPicker = false
                val base = if (settings.presetsEnabled) Presets.all[1].resolve(settings) else null
                editing = GameConfig(
                    packageName = entry.pkg,
                    displayName = entry.label,
                    width = base?.width ?: settings.defaultWidth,
                    height = base?.height ?: settings.defaultHeight,
                    dpi = base?.dpi ?: settings.defaultDpi,
                    hz = base?.hz ?: settings.defaultHz,
                    delaySec = settings.defaultDelaySec,
                    lockRatio = settings.lockAspect
                )
                editingIsNew = true
            }
        )
    }

    editing?.let { g ->
        GameEditorDialog(
            initial = g,
            isNew = editingIsNew,
            onDismiss = { editing = null },
            onSave = { AppStore.upsertGame(it); editing = null }
        )
    }

    deleting?.let { g ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Xóa game?") },
            text = { Text("Xóa “${g.displayName}” khỏi danh sách (không gỡ app khỏi máy).") },
            confirmButton = {
                GlassTextButton(onClick = { AppStore.deleteGame(g.packageName); deleting = null }) { Text("Xóa") }
            },
            dismissButton = { GlassTextButton(onClick = { deleting = null }) { Text("Hủy") } }
        )
    }
}

@Composable
private fun GameCard(
    game: GameConfig,
    running: Boolean,
    modifier: Modifier,
    onPlay: () -> Unit,
    onShortcut: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    GlassCard(modifier = modifier, highlight = running) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(game.packageName, 48.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(game.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    game.packageName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onEdit) { Icon(Icons.Rounded.Edit, "Sửa") }
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, "Xóa") }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "${game.width}×${game.height} · ${game.dpi} dpi · ${game.hz} Hz · delay ${game.delaySec}s" +
                    if (game.lockRatio) " · khóa tỷ lệ" else "",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.secondary
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton(emphasis = true, onClick = onPlay, modifier = Modifier.weight(1f), enabled = !running) {
                Icon(Icons.Rounded.PlayArrow, null)
                Spacer(Modifier.width(4.dp))
                Text(if (running) "Đang chạy" else "Play")
            }
            GlassButton(onClick = onShortcut, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.AddToHomeScreen, null)
                Spacer(Modifier.width(4.dp))
                Text("Create Shortcut", maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ----------------------------------------------------------------------
// Chọn app
// ----------------------------------------------------------------------
@Composable
private fun AppPickerDialog(
    existing: Set<String>,
    onDismiss: () -> Unit,
    onPick: (AppEntry) -> Unit
) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    val apps by produceState<List<AppEntry>>(emptyList()) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
                .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
                .filter { it.pkg != ctx.packageName }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
        }
    }
    val filtered = remember(apps, query) {
        apps.filter { query.isBlank() || it.label.contains(query, true) || it.pkg.contains(query, true) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chọn game") },
        text = {
            Column {
                GlassTextField(
                    value = query, onValueChange = { query = it },
                    label = { Text("Tìm theo tên / package") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.height(360.dp)) {
                    items(filtered, key = { it.pkg }) { app ->
                        val added = app.pkg in existing
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !added) { onPick(app) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(app.pkg, 40.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    if (added) "Đã có trong danh sách" else app.pkg,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { GlassTextButton(onClick = onDismiss) { Text("Đóng") } }
    )
}

// ----------------------------------------------------------------------
// Sửa cấu hình game
// ----------------------------------------------------------------------
@Composable
private fun GameEditorDialog(
    initial: GameConfig,
    isNew: Boolean,
    onDismiss: () -> Unit,
    onSave: (GameConfig) -> Unit
) {
    val settings by AppStore.settings.collectAsStateWithLifecycle()

    var name by remember { mutableStateOf(initial.displayName) }
    var w by remember { mutableIntStateOf(initial.width) }
    var h by remember { mutableIntStateOf(initial.height) }
    var dpi by remember { mutableIntStateOf(initial.dpi) }
    var hz by remember { mutableIntStateOf(initial.hz) }
    var delay by remember { mutableIntStateOf(initial.delaySec) }
    var lock by remember { mutableStateOf(initial.lockRatio) }

    val lockEffective = lock && settings.lockAspect
    val shownH = if (lockEffective) ResolutionCalc.lockedHeight(w, settings.defaultWidth, settings.defaultHeight) else h
    val preview = ResolutionCalc.resolve(
        w, shownH, dpi, lockEffective, settings.defaultWidth, settings.defaultHeight, settings.safetyGuard
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Thêm game" else "Sửa cấu hình") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(initial.packageName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                GlassTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text("Tên hiển thị") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )

                if (settings.presetsEnabled) {
                    Text("Preset nhanh", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Presets.all.forEach { p ->
                            AssistChip(
                                onClick = {
                                    val v = p.resolve(settings)
                                    w = v.width; h = v.height; dpi = v.dpi; hz = v.hz
                                },
                                label = { Text(p.name) }
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField("Width", w, { w = it }, Modifier.weight(1f))
                    NumberField("Height", shownH, { h = it }, Modifier.weight(1f), enabled = !lockEffective)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumberField("DPI", dpi, { dpi = it }, Modifier.weight(1f))
                    NumberField("Hz", hz, { hz = it }, Modifier.weight(1f))
                }
                NumberField("Delay trước khi mở game", delay, { delay = it.coerceAtMost(60) }, Modifier.fillMaxWidth(), suffix = "giây")

                SwitchRow(
                    title = "Lock Ratio",
                    subtitle = if (settings.lockAspect) "Height tự tính theo tỷ lệ màn hình gốc"
                    else "Đang bị tắt toàn cục trong Cài đặt",
                    checked = lock, onCheckedChange = { lock = it }
                )

                AnimatedVisibility(visible = preview.adjusted) {
                    Text(
                        "Safety Guard sẽ nâng lên ${preview.width}×${preview.height} (${preview.dpi} dpi) khi chạy.",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Text(
                    "Thực tế sẽ áp dụng: ${preview.width}×${preview.height} · ${preview.dpi} dpi",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        },
        confirmButton = {
            GlassTextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(
                        initial.copy(
                            displayName = name.trim(), width = w, height = shownH,
                            dpi = dpi, hz = hz, delaySec = delay, lockRatio = lock
                        )
                    )
                }
            ) { Text("Lưu") }
        },
        dismissButton = { GlassTextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}
