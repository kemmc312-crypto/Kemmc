package com.gamehelper.resolution.service

import android.content.Context
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.graphics.drawable.toBitmap
import com.gamehelper.resolution.R
import com.gamehelper.resolution.data.GameConfig

object ShortcutHelper {

    /** Tạo lối tắt ra màn hình chính qua ShortcutManagerCompat. Trả về false nếu launcher không hỗ trợ. */
    fun pin(context: Context, game: GameConfig): Boolean {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(context)) return false

        val intent = Intent(context, LaunchActivity::class.java)
            .setAction(LaunchActivity.ACTION_LAUNCH)
            .putExtra(LaunchActivity.EXTRA_PKG, game.packageName)

        val icon = try {
            IconCompat.createWithBitmap(
                context.packageManager.getApplicationIcon(game.packageName).toBitmap(192, 192)
            )
        } catch (_: Exception) {
            IconCompat.createWithResource(context, R.drawable.ic_stat)
        }

        val info = ShortcutInfoCompat.Builder(context, "game_${game.packageName}")
            .setShortLabel(game.displayName)
            .setLongLabel("Chơi ${game.displayName}")
            .setIcon(icon)
            .setIntent(intent)
            .build()

        return ShortcutManagerCompat.requestPinShortcut(context, info, null)
    }
}
