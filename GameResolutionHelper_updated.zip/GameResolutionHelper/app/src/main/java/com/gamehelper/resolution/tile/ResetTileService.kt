package com.gamehelper.resolution.tile

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.gamehelper.resolution.R
import com.gamehelper.resolution.data.AppStore
import com.gamehelper.resolution.service.GameSessionService
import com.gamehelper.resolution.shizuku.ShizukuHelper
import com.gamehelper.resolution.toast
import kotlin.concurrent.thread

/**
 * Ô cài đặt nhanh: vuốt xuống, bấm một lần => reset độ phân giải gốc ngay, không cần mở app.
 */
class ResetTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        val app = applicationContext
        if (!AppStore.settings.value.tileEnabled) {
            app.toast("Ô cài đặt nhanh đang tắt trong Cài đặt")
            return
        }

        // Nếu đang có phiên chơi: kết thúc phiên (service sẽ tự reset + ẩn nút nổi)
        if (GameSessionService.requestEnd(kill = false)) {
            app.toast("Đã khôi phục màn hình")
            refreshTile()
            return
        }

        thread {
            val ok = ShizukuHelper.awaitReady(2500)
            val result = if (ok) ShizukuHelper.resetDisplay() else null
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                when {
                    !ok -> app.toast("Shizuku chưa chạy hoặc chưa cấp quyền", long = true)
                    result?.ok == true -> app.toast("Đã khôi phục độ phân giải gốc")
                    else -> app.toast("Reset thất bại: ${result?.err}", long = true)
                }
                refreshTile()
            }
        }
    }

    private fun refreshTile() {
        val tile = qsTile ?: return
        val active = GameSessionService.activePackage.value != null
        tile.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = getString(R.string.tile_label)
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            tile.subtitle = if (active) "Đang chơi game" else "Về phân giải gốc"
        }
        tile.updateTile()
    }
}
