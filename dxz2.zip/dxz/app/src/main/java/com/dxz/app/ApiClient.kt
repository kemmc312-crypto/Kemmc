package com.dxz.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ApiClient {
    private val http = OkHttpClient.Builder()
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    // Đổi tên model ở đây nếu Google đổi tên
    private const val MODEL = "gemini-3.8-flash"

    private const val SYSTEM =
        "Bạn là dxz, một trợ lý lập trình. Với mỗi yêu cầu: (1) phân tích yêu cầu, " +
        "(2) liệt kê các bước thực hiện và logic, (3) rồi mới viết code từng bước, " +
        "(4) chỉ ra chỗ dễ lỗi. Trả lời bằng ngôn ngữ người dùng đang dùng."

    suspend fun chat(apiKey: String, history: List<Pair<String, String>>): String =
        withContext(Dispatchers.IO) {
            val contents = JSONArray()
            history.forEach { (role, text) ->
                contents.put(
                    JSONObject()
                        .put("role", if (role == "assistant") "model" else "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))
                )
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject()
                    .put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("maxOutputTokens", 16000))

            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
                .header("x-goog-api-key", apiKey.trim())
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(req).execute().use { r ->
                val s = r.body?.string().orEmpty()
                if (!r.isSuccessful) error("API ${r.code}: $s")
                val root = JSONObject(s)
                val cands = root.optJSONArray("candidates")
                if (cands == null || cands.length() == 0) {
                    error("Không có câu trả lời (có thể bị chặn): ${root.optJSONObject("promptFeedback")}")
                }
                val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                    ?: error("Câu trả lời rỗng")
                buildString {
                    for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
                }
            }
        }
}
