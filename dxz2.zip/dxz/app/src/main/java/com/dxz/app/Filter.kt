package com.dxz.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class FilterConfig(
    val blockedWords: List<String> = emptyList(),
    val blockMessage: String = "Nội dung này bị chặn bởi bộ lọc."
) {
    // Rỗng = không lọc gì
    val isEmpty get() = blockedWords.none { it.isNotBlank() }

    fun matches(text: String): Boolean {
        if (isEmpty) return false
        val t = text.lowercase()
        return blockedWords.any { it.isNotBlank() && t.contains(it.trim().lowercase()) }
    }

    fun toJson(): String = JSONObject()
        .put("blockedWords", JSONArray(blockedWords))
        .put("blockMessage", blockMessage)
        .toString(2)

    companion object {
        fun parse(json: String): FilterConfig {
            val o = JSONObject(json)
            val a = o.optJSONArray("blockedWords") ?: JSONArray()
            return FilterConfig(
                List(a.length()) { a.getString(it) },
                o.optString("blockMessage", FilterConfig().blockMessage)
            )
        }
    }
}

object FilterStore {
    private const val FILE = "filter.json"

    // Bộ lọc "khoá cứng": nằm trong assets/filter.json của APK.
    // Có file này thì nó được ưu tiên, cài đặt của người dùng không ghi đè được.
    fun locked(ctx: Context): FilterConfig? = try {
        ctx.assets.open(FILE).bufferedReader().use { FilterConfig.parse(it.readText()) }
    } catch (e: Exception) { null }

    fun user(ctx: Context): FilterConfig = try {
        val f = File(ctx.filesDir, FILE)
        if (f.exists()) FilterConfig.parse(f.readText()) else FilterConfig()
    } catch (e: Exception) { FilterConfig() }

    fun saveUser(ctx: Context, cfg: FilterConfig) {
        File(ctx.filesDir, FILE).writeText(cfg.toJson())
    }

    fun active(ctx: Context): FilterConfig = locked(ctx) ?: user(ctx)
}
