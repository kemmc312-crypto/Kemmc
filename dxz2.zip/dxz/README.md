# dxz

Trợ lý AI viết code (phân tích -> liệt kê bước -> code). Dùng Gemini API (có gói miễn phí), lấy key ở aistudio.google.com. Android, Kotlin, Compose.

## Cách dùng bộ lọc
1. Chạy bản debug, vào Cài đặt, nhập từ cần chặn (mỗi dòng một từ), bấm "Copy filter.json".
2. Dán nội dung vào `app/src/main/assets/filter.json`.
3. Build release (`SHOW_FILTER_SETTINGS = false` nên phần cài đặt lọc tự ẩn), ký APK.
   Sửa file filter sau khi ký sẽ làm hỏng chữ ký APK.
4. Không có `assets/filter.json` và không nhập gì = không lọc.

## Lưu ý
- API key nằm trong app thì có thể bị lấy ra. Để người khác dùng thì nên đặt server trung gian giữ key và chạy lọc ở server.
- Lọc từ khoá chỉ chặn được cách viết trực tiếp, người dùng đổi cách viết là né được.
