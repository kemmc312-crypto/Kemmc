package com.lite.autoclick;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (20 * getResources().getDisplayMetrics().density);
        l.setPadding(p, p, p, p);
        TextView t = new TextView(this);
        t.setTextSize(16);
        t.setText("1. Bấm nút bên dưới → Ứng dụng đã cài đặt → AutoClick Lite → Bật.\n\n"
                + "2. Thanh nổi sẽ hiện ra:\n"
                + "⠿ kéo để di chuyển\n"
                + "+ thêm nút click (kéo tới vị trí cần bấm; chạm vào nút để đổi thời gian; giữ lâu để xóa)\n"
                + "▶/■ chạy / dừng\n"
                + "🖱 bật/tắt vùng chuột (touchpad): vuốt để di chuyển con trỏ, chạm để click 1 lần, AUTO để bật/tắt auto click, số ms để đổi tốc độ\n"
                + "✕ tắt dịch vụ");
        Button btn = new Button(this);
        btn.setText("Mở cài đặt Trợ năng");
        btn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        l.addView(t);
        l.addView(btn);
        setContentView(l);
    }
}
