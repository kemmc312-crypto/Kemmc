package com.lite.autoclick;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ClickService extends AccessibilityService {
    static final int[] T = {10, 30, 50, 100, 200, 500, 1000, 2000, 5000};
    static final int WRAP = WindowManager.LayoutParams.WRAP_CONTENT;

    interface Tap { void on(long dur); }

    class Pt {
        TextView v;
        WindowManager.LayoutParams lp;
        int t = 3;
        Runnable r;
    }

    WindowManager wm;
    Handler h;
    float d;
    LinearLayout panel, pad;
    WindowManager.LayoutParams panelLp, padLp, cLp;
    TextView runBtn, autoBtn, cTime, cursor;
    final List<Pt> pts = new ArrayList<>();
    boolean running, mouseOn, cAuto;
    int cT = 3;

    final Runnable cr = new Runnable() {
        @Override public void run() {
            if (!cAuto || !mouseOn) return;
            click(cursor);
            h.postDelayed(this, T[cT]);
        }
    };

    int dp(int x) { return (int) (x * d); }
    int sw() { return getResources().getDisplayMetrics().widthPixels; }
    int sh() { return getResources().getDisplayMetrics().heightPixels; }
    String fmt(int ms) { return ms < 1000 ? ms + "ms" : (ms / 1000) + "s"; }

    @Override protected void onServiceConnected() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        h = new Handler(Looper.getMainLooper());
        d = getResources().getDisplayMetrics().density;
        buildPanel();
    }

    GradientDrawable bg(int color, int radius, boolean oval) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        if (oval) g.setShape(GradientDrawable.OVAL); else g.setCornerRadius(radius);
        return g;
    }

    TextView tv(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sp);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    WindowManager.LayoutParams lp(int w, int hh, int x, int y, boolean touch) {
        int f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        if (!touch) f |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(w, hh,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, f, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.LEFT;
        p.x = x;
        p.y = y;
        return p;
    }

    void drag(View hv, final View target, final WindowManager.LayoutParams p, final Tap tap) {
        hv.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int ox, oy;
            boolean mv;
            long t0;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY(); ox = p.x; oy = p.y;
                        mv = false; t0 = SystemClock.uptimeMillis();
                        break;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                        if (!mv && Math.abs(dx) + Math.abs(dy) < dp(8)) break;
                        mv = true;
                        p.x = (int) (ox + dx);
                        p.y = (int) (oy + dy);
                        wm.updateViewLayout(target, p);
                        break;
                    }
                    case MotionEvent.ACTION_UP:
                        if (!mv && tap != null) tap.on(SystemClock.uptimeMillis() - t0);
                        break;
                }
                return true;
            }
        });
    }

    void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setBackground(bg(0xCC222222, dp(20), false));
        panel.setPadding(dp(4), dp(4), dp(4), dp(4));
        TextView grip = tv("⠿", 20), add = tv("+", 24), mouse = tv("🖱", 18), close = tv("✕", 16);
        runBtn = tv("▶", 20);
        for (TextView t : new TextView[]{grip, add, runBtn, mouse, close})
            panel.addView(t, new LinearLayout.LayoutParams(dp(40), dp(40)));
        panelLp = lp(WRAP, WRAP, dp(8), dp(200), true);
        drag(grip, panel, panelLp, null);
        add.setOnClickListener(v -> addPt());
        runBtn.setOnClickListener(v -> toggle());
        mouse.setOnClickListener(v -> toggleMouse());
        close.setOnClickListener(v -> disableSelf());
        wm.addView(panel, panelLp);
    }

    void label(Pt p) { p.v.setText(fmt(T[p.t])); }

    void addPt() {
        final Pt p = new Pt();
        p.v = tv("", 11);
        p.v.setBackground(bg(0xAAFF3B30, 0, true));
        label(p);
        p.lp = lp(dp(46), dp(46), sw() / 2 - dp(23) + pts.size() * dp(12), sh() / 2, true);
        if (running) p.lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        p.r = new Runnable() {
            @Override public void run() {
                if (!running) return;
                click(p.v);
                h.postDelayed(this, T[p.t]);
            }
        };
        drag(p.v, p.v, p.lp, dur -> {
            if (dur > 600) {
                h.removeCallbacks(p.r);
                wm.removeView(p.v);
                pts.remove(p);
            } else {
                p.t = (p.t + 1) % T.length;
                label(p);
            }
        });
        wm.addView(p.v, p.lp);
        pts.add(p);
        if (running) h.post(p.r);
    }

    void toggle() {
        running = !running;
        runBtn.setText(running ? "■" : "▶");
        for (Pt p : pts) {
            if (running) p.lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            else p.lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            wm.updateViewLayout(p.v, p.lp);
            h.removeCallbacks(p.r);
            if (running) h.post(p.r);
        }
    }

    void toggleMouse() {
        if (mouseOn) {
            mouseOn = false;
            cAuto = false;
            h.removeCallbacks(cr);
            wm.removeView(cursor);
            wm.removeView(pad);
            return;
        }
        cursor = tv("+", 18);
        cursor.setBackground(bg(0x99007AFF, 0, true));
        cLp = lp(dp(28), dp(28), sw() / 2, sh() / 2, false);

        pad = new LinearLayout(this);
        pad.setOrientation(LinearLayout.VERTICAL);
        pad.setBackground(bg(0xAA222222, dp(12), false));
        pad.setPadding(dp(4), dp(4), dp(4), dp(4));
        LinearLayout top = new LinearLayout(this);
        TextView grip = tv("⠿", 20);
        autoBtn = tv("AUTO", 13);
        cTime = tv(fmt(T[cT]), 13);
        top.addView(grip, new LinearLayout.LayoutParams(dp(40), dp(34)));
        top.addView(autoBtn, new LinearLayout.LayoutParams(dp(70), dp(34)));
        top.addView(cTime, new LinearLayout.LayoutParams(dp(70), dp(34)));
        TextView area = tv("touchpad", 12);
        area.setBackground(bg(0x44FFFFFF, dp(8), false));
        pad.addView(top);
        pad.addView(area, new LinearLayout.LayoutParams(dp(180), dp(120)));
        padLp = lp(WRAP, WRAP, dp(8), sh() - dp(280), true);
        drag(grip, pad, padLp, null);

        autoBtn.setOnClickListener(v -> {
            cAuto = !cAuto;
            autoBtn.setBackground(cAuto ? bg(0xFF2EA043, dp(8), false) : null);
            h.removeCallbacks(cr);
            if (cAuto) h.post(cr);
        });
        cTime.setOnClickListener(v -> {
            cT = (cT + 1) % T.length;
            cTime.setText(fmt(T[cT]));
        });
        area.setOnTouchListener(new View.OnTouchListener() {
            float lx, ly, tot;
            long t0;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        lx = e.getRawX(); ly = e.getRawY(); tot = 0; t0 = SystemClock.uptimeMillis();
                        break;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - lx, dy = e.getRawY() - ly;
                        lx = e.getRawX(); ly = e.getRawY();
                        tot += Math.abs(dx) + Math.abs(dy);
                        cLp.x = Math.max(0, Math.min(cLp.x + (int) (dx * 2), sw() - dp(28)));
                        cLp.y = Math.max(0, Math.min(cLp.y + (int) (dy * 2), sh() - dp(28)));
                        wm.updateViewLayout(cursor, cLp);
                        break;
                    }
                    case MotionEvent.ACTION_UP:
                        if (tot < dp(8) && SystemClock.uptimeMillis() - t0 < 300) click(cursor);
                        break;
                }
                return true;
            }
        });
        wm.addView(cursor, cLp);
        wm.addView(pad, padLp);
        mouseOn = true;
    }

    void click(View v) {
        int[] l = new int[2];
        v.getLocationOnScreen(l);
        Path path = new Path();
        path.moveTo(l[0] + v.getWidth() / 2f, l[1] + v.getHeight() / 2f);
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(path, 0, 1));
        dispatchGesture(b.build(), null, null);
    }

    void cleanup() {
        running = false; cAuto = false;
        if (h != null) h.removeCallbacksAndMessages(null);
        try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) {}
        for (Pt p : pts) { try { wm.removeView(p.v); } catch (Exception ignored) {} }
        pts.clear();
        if (mouseOn) {
            try { wm.removeView(cursor); wm.removeView(pad); } catch (Exception ignored) {}
            mouseOn = false;
        }
        panel = null;
    }

    @Override public boolean onUnbind(android.content.Intent i) { cleanup(); return super.onUnbind(i); }
    @Override public void onDestroy() { cleanup(); super.onDestroy(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}
}
