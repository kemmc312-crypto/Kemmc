package com.gamebox.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import com.gamebox.game.TabManager
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.gamebox.game.GameTab
import com.gamebox.game.TabConfig
import com.gamebox.game.lockedHeight

@Composable
fun MainScreen(vm: MainViewModel) {
    val tabs by vm.tabs.collectAsState()
    val active by vm.active.collectAsState()
    val status by vm.status.collectAsState()
    val pending by vm.pending.collectAsState()
    val cur = tabs.firstOrNull { it.id == active }
    var editing by remember { mutableStateOf(false) }
    val act = LocalContext.current as Activity
    val clip = LocalClipboardManager.current

    // Tab game: xoay theo cấu hình tab + ẩn thanh hệ thống. Tab "Thêm game": về bình thường.
    DisposableEffect(cur?.id, cur?.cfg?.landscape) {
        act.requestedOrientation = when {
            cur == null -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            cur.cfg.landscape -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
        if (cur != null) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else c.show(WindowInsetsCompat.Type.systemBars())
        onDispose {}
    }

    Column(
        Modifier.fillMaxSize()
            .background(if (cur == null) MaterialTheme.colorScheme.background else Color.Black)
    ) {
        TabBar(
            tabs = tabs, active = active,
            onSelect = vm::select, onClose = vm::close,
            onSettings = { editing = true },
            onRotate = { active?.let(vm::rotate) }
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (cur == null) HomeScreen(vm) else GameView(cur, vm)
            if (status.isNotBlank())
                Column(Modifier.align(Alignment.TopStart).background(Color(0xCC000000)).padding(6.dp)) {
                    Text(status, fontSize = 11.sp, color = Color.White)
                    Row {
                        TextButton(onClick = { clip.setText(AnnotatedString(status)) }) { Text("Sao chép", fontSize = 11.sp) }
                        TextButton(onClick = { TabManager.clearStatus() }) { Text("Đóng", fontSize = 11.sp) }
                    }
                }
        }
    }

    pending?.let { app ->
        TabConfigDialog(
            title = app.label, confirm = "Chạy",
            initial = TabConfig(height = lockedHeight(1280, true, vm.ratio)),
            ratio = vm.ratio,
            onDismiss = { vm.pending.value = null },
            onConfirm = vm::confirmNew
        )
    }
    if (editing && cur != null) {
        TabConfigDialog(
            title = "Cài đặt: ${cur.label}", confirm = "Áp dụng",
            initial = cur.cfg, ratio = vm.ratio,
            onDismiss = { editing = false },
            onConfirm = { editing = false; vm.reconfigure(cur.id, it) }
        )
    }
}

@Composable
private fun TabBar(
    tabs: List<GameTab>, active: Int?,
    onSelect: (Int?) -> Unit, onClose: (Int) -> Unit, onSettings: () -> Unit, onRotate: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().height(40.dp).background(MaterialTheme.colorScheme.surfaceVariant),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(Modifier.weight(1f).fillMaxHeight().horizontalScroll(rememberScrollState())) {
            TabItem("＋ Thêm game", active == null, null) { onSelect(null) }
            tabs.forEach { t -> TabItem(t.label, active == t.id, { onClose(t.id) }) { onSelect(t.id) } }
        }
        if (active != null) {
            TextButton(onClick = onRotate) { Text("⟳") }
            TextButton(onClick = onSettings) { Text("⚙") }
        }
    }
}

@Composable
private fun TabItem(label: String, selected: Boolean, onClose: (() -> Unit)?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxHeight()
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, maxLines = 1, style = MaterialTheme.typography.labelLarge)
        if (onClose != null) Text("  ✕", Modifier.clickable(onClick = onClose))
    }
}
