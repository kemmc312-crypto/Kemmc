package com.gamebox.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gamebox.display.DisplayConfig
import com.gamebox.display.DisplayHost
import com.gamebox.game.AppInfo
import com.gamebox.game.AppRepository
import com.gamebox.game.GameLauncher
import com.gamebox.shizuku.ShizukuManager
import com.gamebox.shizuku.ShizukuState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val shizuku = ShizukuManager.state
    val lost = ShizukuManager.lost
    val denied = ShizukuManager.denied
    val alive = DisplayHost.alive

    val cfg = MutableStateFlow(DisplayConfig())
    val query = MutableStateFlow("")
    val selected = MutableStateFlow<AppInfo?>(null)
    val msg = MutableStateFlow("")
    val inGame = MutableStateFlow(false)

    private val apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val list = combine(apps, query) { a, q ->
        if (q.isBlank()) a else a.filter { it.label.contains(q, true) || it.pkg.contains(q, true) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init { viewModelScope.launch { apps.value = AppRepository.load(app) } }

    fun requestPermission() = ShizukuManager.requestPermission()
    fun openGame() { inGame.value = true }
    fun leaveGame() { inGame.value = false }

    fun start() {
        val a = selected.value ?: return
        if (ShizukuManager.state.value != ShizukuState.READY) { msg.value = "Shizuku chưa sẵn sàng"; return }
        viewModelScope.launch {
            val app = getApplication<Application>()
            msg.value = "Đang tạo display…"
            val id = try { DisplayHost.create(app, cfg.value) }
            catch (e: Throwable) { msg.value = "Lỗi tạo display: ${e.message}"; return@launch }
            DisplayHost.pkg = a.pkg
            val (ok, out) = GameLauncher.launch(app, a.pkg, id)
            msg.value = "display $id · ${out.take(300)}"
            if (!ok) return@launch
            inGame.value = true
            delay(2500)
            msg.value = if (GameLauncher.isRunning(a.pkg)) "Game đang chạy (display $id)"
            else "Không thấy tiến trình game — xem output am start"
        }
    }

    fun stop() {
        viewModelScope.launch {
            DisplayHost.pkg?.let { GameLauncher.stop(it) }
            DisplayHost.release()
            inGame.value = false
            msg.value = "Đã dừng"
        }
    }
}
