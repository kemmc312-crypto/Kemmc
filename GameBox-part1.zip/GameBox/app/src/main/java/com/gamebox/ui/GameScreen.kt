package com.gamebox.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.gamebox.display.DisplayConfig
import com.gamebox.display.DisplayHost
import com.gamebox.display.InputInjector

/** Back = thoát về GameBox, game vẫn chạy trên display ảo. */
@Composable
fun GameScreen(cfg: DisplayConfig, onExit: () -> Unit) {
    BackHandler(onBack = onExit)
    val act = LocalContext.current as Activity

    DisposableEffect(cfg.landscape) {
        val old = act.requestedOrientation
        act.requestedOrientation = if (cfg.landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            act.requestedOrientation = old
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        AndroidView(
            modifier = Modifier.aspectRatio(cfg.width.toFloat() / cfg.height),
            factory = { ctx ->
                SurfaceView(ctx).apply {
                    keepScreenOn = true
                    holder.setFixedSize(cfg.width, cfg.height)
                    holder.addCallback(object : SurfaceHolder.Callback {
                        override fun surfaceCreated(h: SurfaceHolder) = DisplayHost.attach(h.surface)
                        override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
                        override fun surfaceDestroyed(h: SurfaceHolder) = DisplayHost.detach()
                    })
                    setOnTouchListener { v, ev ->
                        if (v.width > 0 && v.height > 0)
                            InputInjector.send(
                                ev, DisplayHost.displayId,
                                cfg.width / v.width.toFloat(), cfg.height / v.height.toFloat()
                            )
                        true
                    }
                }
            }
        )
    }
}
