package com.gamebox.display

import android.annotation.SuppressLint
import android.content.AttributionSource
import android.content.Context
import android.content.ContextWrapper
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Log
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import android.view.Surface
import com.gamebox.IDisplayService
import org.lsposed.hiddenapibypass.HiddenApiBypass
import kotlin.system.exitProcess

/**
 * Chạy trong process shell (Shizuku UserService).
 * Tạo VirtualDisplay TRUSTED để app game khác được phép mở lên (display do app thường tạo bị Android chặn).
 */
class DisplayService() : IDisplayService.Stub() {
    constructor(ctx: Context) : this() { base = ctx }

    private var base: Context? = null
    private class Entry(val vd: VirtualDisplay, val reader: ImageReader, val thread: HandlerThread)

    private val map = HashMap<Int, Entry>()
    private var err = ""

    init { try { HiddenApiBypass.addHiddenApiExemptions("L") } catch (_: Throwable) {} }

    // Context giả mang tên package com.android.shell (khớp uid 2000)
    @SuppressLint("NewApi", "Override")
    private class ShellContext(b: Context) : ContextWrapper(b) {
        override fun getPackageName() = "com.android.shell"
        override fun getOpPackageName(): String = "com.android.shell"
        override fun getApplicationContext(): Context = this
        override fun getAttributionSource(): AttributionSource =
            AttributionSource.Builder(2000).setPackageName("com.android.shell").build()
    }

    private fun systemContext(): Context {
        val at = Class.forName("android.app.ActivityThread")
        val cur = at.getMethod("currentActivityThread").invoke(null) ?: at.getMethod("systemMain").invoke(null)
        return at.getMethod("getSystemContext").invoke(cur) as Context
    }

    private val dm: DisplayManager by lazy {
        DisplayManager::class.java.getDeclaredConstructor(Context::class.java)
            .apply { isAccessible = true }
            .newInstance(ShellContext(base ?: systemContext()))
    }

    private val im: Any by lazy {
        val b = Class.forName("android.os.ServiceManager").getMethod("getService", String::class.java)
            .invoke(null, "input") as IBinder
        Class.forName("android.hardware.input.IInputManager\$Stub")
            .getMethod("asInterface", IBinder::class.java).invoke(null, b)!!
    }
    private val injectM by lazy {
        Class.forName("android.hardware.input.IInputManager")
            .getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
    }
    private val setDisplayIdM by lazy {
        InputEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType)
    }

    private fun flagSets(): List<Int> {
        val base = 1 or 2 or (1 shl 6) or (1 shl 7) or (1 shl 8) // PUBLIC|PRESENTATION|SUPPORTS_TOUCH|ROTATES_WITH_CONTENT|DESTROY_CONTENT_ON_REMOVAL
        val sdk = Build.VERSION.SDK_INT
        val trusted = if (sdk >= 33) (1 shl 10) else 0              // TRUSTED
        val group = if (sdk >= 33) (1 shl 11) or (1 shl 12) or (1 shl 13) else 0 // OWN_DISPLAY_GROUP|ALWAYS_UNLOCKED|TOUCH_FEEDBACK_DISABLED
        val focus = if (sdk >= 34) (1 shl 14) else 0                // OWN_FOCUS
        return listOf(base or trusted or group or focus, base or trusted, base).distinct()
    }

    @Synchronized
    override fun createDisplay(name: String, width: Int, height: Int, dpi: Int): Int {
        val t = HandlerThread("gb-sink").apply { start() }
        val r = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2).apply {
            setOnImageAvailableListener({ it.acquireLatestImage()?.close() }, Handler(t.looper))
        }
        val log = StringBuilder()
        var vd: VirtualDisplay? = null
        for (f in flagSets()) {
            try {
                vd = dm.createVirtualDisplay(name, width, height, dpi, r.surface, f)
                if (vd != null) { log.append("OK flags=0x${f.toString(16)}"); break }
                log.append("flags=0x${f.toString(16)} -> null\n")
            } catch (e: Throwable) {
                log.append("flags=0x${f.toString(16)} -> ${e.cause ?: e}\n")
            }
        }
        err = log.toString().trim()
        Log.i(TAG, err)
        if (vd == null) { r.close(); t.quitSafely(); return -1 }
        val id = vd.display.displayId
        map[id] = Entry(vd, r, t)
        return id
    }

    @Synchronized
    override fun attachSurface(displayId: Int, surface: Surface) { map[displayId]?.vd?.surface = surface }

    @Synchronized
    override fun detachSurface(displayId: Int) {
        map[displayId]?.let { it.vd.surface = it.reader.surface }
    }

    @Synchronized
    override fun releaseDisplay(displayId: Int) {
        map.remove(displayId)?.let { it.vd.release(); it.reader.close(); it.thread.quitSafely() }
    }

    override fun inject(event: MotionEvent, displayId: Int) {
        try {
            setDisplayIdM.invoke(event, displayId)
            event.source = InputDevice.SOURCE_TOUCHSCREEN
            injectM.invoke(im, event, 0) // 0 = ASYNC
        } catch (t: Throwable) { Log.w(TAG, "inject", t) }
    }

    override fun lastError(): String = err

    override fun destroy() {
        synchronized(this) { map.keys.toList().forEach { releaseDisplay(it) } }
        exitProcess(0)
    }

    private companion object { const val TAG = "GameBoxSvc" }
}
