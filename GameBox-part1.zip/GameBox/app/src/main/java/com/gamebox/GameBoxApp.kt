package com.gamebox

import android.app.Application
import com.gamebox.shizuku.ShizukuManager
import org.lsposed.hiddenapibypass.HiddenApiBypass

class GameBoxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        HiddenApiBypass.addHiddenApiExemptions("L")
        ShizukuManager.init(this)
    }
}
