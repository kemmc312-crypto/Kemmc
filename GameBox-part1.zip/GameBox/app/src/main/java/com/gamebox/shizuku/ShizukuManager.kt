package com.gamebox.shizuku

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState { NOT_INSTALLED, NOT_RUNNING, NO_PERMISSION, READY }

object ShizukuManager {
    private const val PKG = "moe.shizuku.privileged.api"
    private const val REQ = 1001
    private lateinit var ctx: Context

    private val _state = MutableStateFlow(ShizukuState.NOT_RUNNING)
    val state: StateFlow<ShizukuState> = _state.asStateFlow()

    /** true khi Shizuku đang READY rồi bị ngắt -> UI hiện cảnh báo */
    private val _lost = MutableStateFlow(false)
    val lost: StateFlow<Boolean> = _lost.asStateFlow()

    private val _denied = MutableStateFlow(false)
    val denied: StateFlow<Boolean> = _denied.asStateFlow()

    fun init(c: Context) {
        ctx = c.applicationContext
        Shizuku.addBinderReceivedListenerSticky { refresh() }
        Shizuku.addBinderDeadListener { refresh() }
        Shizuku.addRequestPermissionResultListener { _, r ->
            _denied.value = r != PackageManager.PERMISSION_GRANTED
            refresh()
        }
        refresh()
    }

    fun refresh() {
        val next = when {
            Shizuku.pingBinder() ->
                if (Shizuku.isPreV11() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED)
                    ShizukuState.NO_PERMISSION else ShizukuState.READY
            installed() -> ShizukuState.NOT_RUNNING
            else -> ShizukuState.NOT_INSTALLED
        }
        if (_state.value == ShizukuState.READY && next != ShizukuState.READY) _lost.value = true
        if (next == ShizukuState.READY) { _lost.value = false; _denied.value = false }
        _state.value = next
    }

    fun requestPermission() {
        if (Shizuku.pingBinder()) Shizuku.requestPermission(REQ)
    }

    private fun installed() = try {
        ctx.packageManager.getPackageInfo(PKG, 0); true
    } catch (_: Exception) { false }

    // Shizuku.newProcess là private từ API 13 -> gọi qua reflection
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
    }

    /** Chạy lệnh shell (uid shell). Trả về (exitCode, stdout+stderr). */
    suspend fun sh(cmd: String): Pair<Int, String> = withContext(Dispatchers.IO) {
        try {
            val p = newProcess.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor() to out.trim()
        } catch (e: Throwable) {
            -1 to ((e.cause ?: e).message ?: e.toString())
        }
    }
}
