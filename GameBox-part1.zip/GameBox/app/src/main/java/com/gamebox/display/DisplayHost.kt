package com.gamebox.display

import android.content.Context
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** shortSide: 480/720/1080. Cạnh dài theo tỉ lệ 20:9. */
data class DisplayConfig(
    val shortSide: Int = 720,
    val dpi: Int = 320,
    val landscape: Boolean = true,
) {
    private val longSide get() = shortSide * 20 / 9 / 2 * 2
    val width get() = if (landscape) longSide else shortSide
    val height get() = if (landscape) shortSide else longSide
}

/**
 * Giữ VirtualDisplay sống độc lập với Activity.
 * Khi SurfaceView mất, chuyển sang Surface giả (ImageReader) để display không bị OFF
 * (display OFF => game bị pause/stop).
 */
object DisplayHost {
    private const val FLAGS =
        DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC or DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY

    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var viewSurface: Surface? = null

    var cfg: DisplayConfig? = null
        private set
    var pkg: String? = null

    private val _alive = MutableStateFlow(false)
    val alive: StateFlow<Boolean> = _alive.asStateFlow()

    val displayId: Int get() = vd?.display?.displayId ?: -1

    @Synchronized
    fun create(ctx: Context, c: DisplayConfig): Int {
        if (vd != null && cfg == c) return displayId
        release()
        val t = HandlerThread("gb-sink").apply { start() }
        val r = ImageReader.newInstance(c.width, c.height, PixelFormat.RGBA_8888, 2).apply {
            setOnImageAvailableListener({ it.acquireLatestImage()?.close() }, Handler(t.looper))
        }
        try {
            val dm = ctx.getSystemService(DisplayManager::class.java)
            vd = dm.createVirtualDisplay(
                "GameBox", c.width, c.height, c.dpi, viewSurface ?: r.surface, FLAGS
            ) ?: error("createVirtualDisplay trả về null")
        } catch (e: Throwable) {
            r.close(); t.quitSafely(); throw e
        }
        thread = t; reader = r; cfg = c
        _alive.value = true
        return displayId
    }

    @Synchronized
    fun attach(s: Surface) { viewSurface = s; vd?.surface = s }

    @Synchronized
    fun detach() { viewSurface = null; vd?.surface = reader?.surface }

    @Synchronized
    fun release() {
        vd?.release(); vd = null
        reader?.close(); reader = null
        thread?.quitSafely(); thread = null
        cfg = null; pkg = null
        _alive.value = false
    }
}
