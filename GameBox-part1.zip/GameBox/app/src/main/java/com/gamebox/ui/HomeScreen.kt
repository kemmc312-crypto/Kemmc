package com.gamebox.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.gamebox.shizuku.ShizukuState

private fun openShizuku(ctx: Context) {
    val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
    if (i != null) ctx.startActivity(i) else Toast.makeText(ctx, "Chưa cài Shizuku", Toast.LENGTH_SHORT).show()
}

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val st by vm.shizuku.collectAsState()
    val lost by vm.lost.collectAsState()
    val denied by vm.denied.collectAsState()
    val alive by vm.alive.collectAsState()
    val cfg by vm.cfg.collectAsState()
    val q by vm.query.collectAsState()
    val list by vm.list.collectAsState()
    val sel by vm.selected.collectAsState()
    val msg by vm.msg.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("GameBox", style = MaterialTheme.typography.headlineSmall)

        if (lost) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
            Text(
                "⚠ Shizuku đã ngắt kết nối. Game trên display ảo có thể lỗi — mở Shizuku và chạy lại.",
                Modifier.padding(12.dp)
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                when (st) {
                    ShizukuState.NOT_INSTALLED -> "Shizuku: chưa cài"
                    ShizukuState.NOT_RUNNING -> "Shizuku: chưa chạy"
                    ShizukuState.NO_PERMISSION -> "Shizuku: chưa cấp quyền"
                    ShizukuState.READY -> "Shizuku: sẵn sàng ✓"
                },
                Modifier.weight(1f)
            )
            when (st) {
                ShizukuState.NO_PERMISSION -> Button(onClick = vm::requestPermission) { Text("Cấp quyền") }
                ShizukuState.NOT_RUNNING -> Button(onClick = { openShizuku(ctx) }) { Text("Mở Shizuku") }
                else -> {}
            }
        }
        if (denied && st == ShizukuState.NO_PERMISSION)
            Text("Đã từ chối: vào Shizuku → ứng dụng được ủy quyền → bật GameBox.", style = MaterialTheme.typography.bodySmall)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf(480, 720, 1080).forEach { s ->
                FilterChip(
                    selected = cfg.shortSide == s,
                    onClick = { vm.cfg.value = cfg.copy(shortSide = s, dpi = s * 4 / 9) },
                    label = { Text("${s}p") }
                )
            }
            Text("Ngang", Modifier.padding(start = 8.dp))
            Switch(checked = cfg.landscape, onCheckedChange = { vm.cfg.value = cfg.copy(landscape = it) })
        }

        if (alive) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = vm::openGame) { Text("Xem game") }
            OutlinedButton(onClick = vm::stop) { Text("Dừng") }
        }

        OutlinedTextField(
            value = q, onValueChange = { vm.query.value = it },
            modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Tìm app") }
        )
        LazyColumn(Modifier.weight(1f)) {
            items(list, key = { it.pkg }) { a ->
                ListItem(
                    headlineContent = { Text(a.label) },
                    supportingContent = { Text(a.pkg, style = MaterialTheme.typography.bodySmall) },
                    colors = ListItemDefaults.colors(
                        containerColor = if (sel?.pkg == a.pkg) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                    ),
                    modifier = Modifier.clickable { vm.selected.value = a }
                )
            }
        }

        Button(
            onClick = vm::start,
            enabled = sel != null && st == ShizukuState.READY,
            modifier = Modifier.fillMaxWidth()
        ) { Text(sel?.let { "Chạy ${it.label}" } ?: "Chọn game ở trên") }
        if (msg.isNotBlank()) Text(msg, style = MaterialTheme.typography.bodySmall)
    }
}
