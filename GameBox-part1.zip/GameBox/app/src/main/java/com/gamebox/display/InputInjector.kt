package com.gamebox.display

import android.graphics.Matrix
import android.os.IBinder
import android.util.Log
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.util.concurrent.Executors

/** Chuyển touch từ SurfaceView vào display ảo qua IInputManager (quyền shell qua Shizuku). */
object InputInjector {
    private const val TAG = "GameBoxInput"
    private val pool = Executors.newSingleThreadExecutor()

    private val im: Any by lazy {
        val binder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
        Class.forName("android.hardware.input.IInputManager\$Stub")
            .getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
    }
    private val inject by lazy {
        Class.forName("android.hardware.input.IInputManager")
            .getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
    }
    private val setDisplayId by lazy {
        InputEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType)
    }

    /** sx, sy: tỉ lệ displayPx / viewPx */
    fun send(ev: MotionEvent, displayId: Int, sx: Float, sy: Float) {
        if (displayId < 0) return
        val e = MotionEvent.obtain(ev)
        e.source = InputDevice.SOURCE_TOUCHSCREEN
        e.transform(Matrix().apply { setScale(sx, sy) })
        setDisplayId.invoke(e, displayId)
        pool.execute {
            try { inject.invoke(im, e, 0) } // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
            catch (t: Throwable) { Log.w(TAG, "inject fail", t) }
            finally { e.recycle() }
        }
    }
}
