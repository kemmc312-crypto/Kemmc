package com.gamebox.game

import android.content.Context
import android.content.Intent
import com.gamebox.shizuku.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppInfo(val label: String, val pkg: String)

object AppRepository {
    suspend fun load(ctx: Context): List<AppInfo> = withContext(Dispatchers.IO) {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }
}

object GameLauncher {
    /** @return (thành công, output của am) */
    suspend fun launch(ctx: Context, pkg: String, displayId: Int, freshStart: Boolean = true): Pair<Boolean, String> {
        val comp = ctx.packageManager.getLaunchIntentForPackage(pkg)?.component
            ?: return false to "Không tìm thấy activity chính của $pkg"
        // best effort: cho phép activity non-resizable chạy trên display phụ
        ShizukuManager.sh("settings put global force_resizable_activities 1")
        if (freshStart) ShizukuManager.sh("am force-stop $pkg")
        val (code, out) = ShizukuManager.sh("am start --display $displayId -n ${comp.flattenToShortString()}")
        return (code == 0 && !out.contains("Error", ignoreCase = true)) to out
    }

    suspend fun isRunning(pkg: String): Boolean =
        ShizukuManager.sh("pidof $pkg").let { it.first == 0 && it.second.isNotBlank() }

    suspend fun stop(pkg: String) = ShizukuManager.sh("am force-stop $pkg")
}
