package com.example.touchboostlab

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var p: Prefs
    private lateinit var root: LinearLayout
    private lateinit var statusTv: TextView
    private val updaters = ArrayList<() -> Unit>()
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(56))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        build()
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
    }

    // ---------------------------------------------------------------- UI

    private fun build() {
        header("TouchBoostLab")
        note("Bật TỪNG thứ một, bấm “Áp dụng & chạy”, rồi sang app khác vuốt thử để xem thứ nào làm nhạy hơn. Đổi thông số xong phải bấm “Áp dụng & chạy” lại.")

        header("Quyền cần cấp (3)")
        permRow(
            "Thông báo",
            { Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED }
        ) {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
        permRow(
            "Bỏ tối ưu hoá pin",
            { getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName) }
        ) {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        permRow(
            "Hiển thị trên ứng dụng khác",
            { Settings.canDrawOverlays(this) }
        ) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        note("Tuỳ chọn, chỉ cho mục 5 (lệnh hệ thống):")
        permRow("Shizuku", { Shell.available() }) {
            try {
                if (Shizuku.pingBinder()) {
                    Shizuku.requestPermission(100)
                } else {
                    toast("Hãy bật Shizuku trước")
                }
            } catch (e: Throwable) {
                toast("Không gọi được Shizuku")
            }
        }

        btn("▶ Áp dụng & chạy") {
            startForegroundService(Intent(this, BoostService::class.java))
        }
        btn("■ Dừng") {
            stopService(Intent(this, BoostService::class.java))
        }
        btn("Khôi phục cài đặt hệ thống (nếu bị kẹt)") {
            Thread {
                ShellSettings.restoreAll(p)
                runOnUiThread { toast("Đã khôi phục") }
            }.start()
        }

        statusTv = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setPadding(0, dp(10), 0, dp(6))
        }
        root.addView(statusTv)

        header("1. Giữ CPU thức")
        sw("Wake lock (PARTIAL_WAKE_LOCK)", K.WAKE)

        header("2. Cảm biến tốc độ tối đa (như SwiftSense)")
        sw("Bật mục này", K.SENS)
        sw("Gia tốc kế", K.S_ACC, true)
        sw("Con quay (gyro)", K.S_GYR, true)
        sw("Từ trường", K.S_MAG, true)
        sw("Rotation vector", K.S_ROT, true)
        sw("Trọng lực", K.S_GRA, true)
        sw("Gia tốc tuyến tính", K.S_LIN, true)
        seek("Độ trễ lấy mẫu", K.DELAY, 0, 40, 0) { v -> if (v == 0) "0 = nhanh nhất" else "${v * 500} µs" }
        seek("Ưu tiên luồng cảm biến", K.PRIO, 0, 8, 4) { v -> "nice -$v" }

        header("3. Tải CPU nền (thử giả thuyết: giữ xung CPU cao)")
        note("Tốn pin và làm máy nóng. Chỉ để thử, nhớ tắt sau khi test.")
        sw("Bật tải CPU nền", K.CPU)
        seek("Mức bận", K.DUTY, 1, 50, 10) { v -> "$v %" }
        seek("Số luồng", K.THREADS, 1, 4, 1) { v -> "$v" }

        header("4. Overlay 1×1 điểm ảnh")
        note("Giả thuyết: có cửa sổ hiển thị thì tiến trình được ưu tiên cao hơn. Cần quyền hiển thị trên ứng dụng khác.")
        sw("Bật overlay", K.OVERLAY)

        header("5. Lệnh hệ thống (cần Shizuku)")
        note("Giá trị gốc được lưu và tự khôi phục khi bấm Dừng.")
        sw("pointer_speed", K.PTR)
        seek("Giá trị pointer_speed", K.PTRV, 0, 14, 7) { v -> "${v - 7}" }
        sw("Tốc độ animation (3 thông số scale)", K.ANIM)
        seek("Animation scale", K.ANIMV, 0, 10, 10) { v -> "${v / 10.0}x" }
        sw("long_press_timeout", K.LONGP)
        seek("Thời gian nhấn giữ", K.LPV, 0, 40, 30) { v -> "${100 + v * 10} ms" }
    }

    private fun refresh() {
        for (u in updaters) u()
        statusTv.text = BoostService.status
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun header(t: String) {
        root.addView(TextView(this).apply {
            text = t
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(22), 0, dp(6))
        })
    }

    private fun note(t: String) {
        root.addView(TextView(this).apply {
            text = t
            textSize = 12f
            alpha = 0.7f
            setPadding(0, 0, 0, dp(4))
        })
    }

    private fun sw(label: String, key: String, def: Boolean = false) {
        root.addView(Switch(this).apply {
            text = label
            isChecked = p.b(key, def)
            setOnCheckedChangeListener { _, c -> p.setB(key, c) }
        })
    }

    private fun seek(label: String, key: String, lo: Int, hi: Int, def: Int, fmt: (Int) -> String) {
        val cur = p.i(key, def)
        val tv = TextView(this).apply {
            text = "$label: ${fmt(cur)}"
            textSize = 13f
            setPadding(0, dp(6), 0, 0)
        }
        val bar = SeekBar(this).apply {
            max = hi - lo
            progress = cur - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    val value = lo + v
                    p.setI(key, value)
                    tv.text = "$label: ${fmt(value)}"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(tv)
        root.addView(bar)
    }

    private fun btn(label: String, onClick: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        })
    }

    private fun permRow(title: String, granted: () -> Boolean, action: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tv = TextView(this).apply { textSize = 15f }
        row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply {
            text = "Cấp"
            setOnClickListener { action() }
        })
        root.addView(row)
        updaters.add {
            val ok = try { granted() } catch (e: Throwable) { false }
            tv.text = (if (ok) "✓ " else "✗ ") + title
        }
    }
}
