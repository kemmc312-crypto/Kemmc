package com.example.touchboostlab

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import java.util.concurrent.Executors

class BoostService : Service(), SensorEventListener {

    companion object {
        @Volatile var status: String = "Dịch vụ: đang dừng"
        @Volatile var shellMsg: String = ""
        private const val CH = "tbl"
        private const val NID = 1
    }

    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()

    private var sm: SensorManager? = null
    private var sensorThread: HandlerThread? = null
    private var wl: PowerManager.WakeLock? = null
    private var overlay: View? = null

    @Volatile private var cpuRun = false
    private val cpuThreads = ArrayList<Thread>()
    @Volatile private var sink = 0L

    private val counts = IntArray(64)
    private val activeTypes = ArrayList<Int>()
    private var featureLines = ""

    private val hzTick = object : Runnable {
        override fun run() {
            publish()
            main.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        teardown()
        setup()
        main.removeCallbacks(hzTick)
        main.post(hzTick)
        return START_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacks(hzTick)
        teardown()
        val p = Prefs(this)
        exec.execute { ShellSettings.restoreAll(p) }
        exec.shutdown()
        shellMsg = ""
        status = "Dịch vụ: đang dừng"
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "TouchBoostLab", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("TouchBoostLab đang chạy")
            .setContentText("Chạm để mở")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NID, n)
        }
    }

    private fun setup() {
        val p = Prefs(this)
        val sb = StringBuilder()

        // 1. Wake lock
        if (p.b(K.WAKE)) {
            try {
                val pm = getSystemService(PowerManager::class.java)
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TouchBoostLab:wl").apply {
                    setReferenceCounted(false)
                    acquire()
                }
                sb.append("• Wake lock: BẬT\n")
            } catch (e: Exception) {
                sb.append("• Wake lock: lỗi ").append(e.message).append('\n')
            }
        }

        // 2. Cảm biến tốc độ tối đa
        if (p.b(K.SENS)) {
            val mgr = getSystemService(SENSOR_SERVICE) as SensorManager
            sm = mgr
            val prio = p.i(K.PRIO, 4).coerceIn(0, 8)
            val t = HandlerThread("TBL-sensor", -prio)
            t.start()
            sensorThread = t
            val h = Handler(t.looper)
            val delay = p.i(K.DELAY, 0) * 500
            val list = listOf(
                K.S_ACC to Sensor.TYPE_ACCELEROMETER,
                K.S_GYR to Sensor.TYPE_GYROSCOPE,
                K.S_MAG to Sensor.TYPE_MAGNETIC_FIELD,
                K.S_ROT to Sensor.TYPE_ROTATION_VECTOR,
                K.S_GRA to Sensor.TYPE_GRAVITY,
                K.S_LIN to Sensor.TYPE_LINEAR_ACCELERATION
            )
            for ((key, type) in list) {
                if (!p.b(key, true)) continue
                val s = mgr.getDefaultSensor(type) ?: continue
                if (mgr.registerListener(this, s, delay, h)) activeTypes.add(type)
            }
            sb.append("• Cảm biến: BẬT (delay ")
                .append(if (delay == 0) "FASTEST" else "${delay}µs")
                .append(", ưu tiên -").append(prio).append(")\n")
        }

        // 3. Tải CPU nền (thử giả thuyết giữ xung CPU)
        if (p.b(K.CPU)) {
            val duty = p.i(K.DUTY, 10).coerceIn(1, 50)
            val n = p.i(K.THREADS, 1).coerceIn(1, 4)
            cpuRun = true
            repeat(n) { idx ->
                val th = Thread({
                    val periodNs = 20_000_000L
                    val busyNs = periodNs * duty / 100
                    while (cpuRun) {
                        val t0 = System.nanoTime()
                        var x = 1L
                        while (System.nanoTime() - t0 < busyNs) {
                            x = x * 6364136223846793005L + 1442695040888963407L
                        }
                        sink = x
                        val sleepMs = ((periodNs - busyNs) / 1_000_000L).coerceAtLeast(1L)
                        try {
                            Thread.sleep(sleepMs)
                        } catch (e: InterruptedException) {
                            break
                        }
                    }
                }, "TBL-cpu-$idx")
                th.start()
                cpuThreads.add(th)
            }
            sb.append("• Tải CPU: BẬT ($duty% x $n luồng)\n")
        }

        // 4. Overlay 1x1 điểm ảnh
        if (p.b(K.OVERLAY)) {
            if (Settings.canDrawOverlays(this)) {
                try {
                    val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                    val v = View(this)
                    val lp = WindowManager.LayoutParams(
                        1, 1,
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                        PixelFormat.TRANSLUCENT
                    )
                    lp.gravity = Gravity.TOP or Gravity.START
                    wm.addView(v, lp)
                    overlay = v
                    sb.append("• Overlay 1x1: BẬT\n")
                } catch (e: Exception) {
                    sb.append("• Overlay: lỗi ").append(e.message).append('\n')
                }
            } else {
                sb.append("• Overlay: THIẾU quyền hiển thị trên ứng dụng khác\n")
            }
        }

        // 5. Lệnh hệ thống qua Shizuku
        shellMsg = ""
        exec.execute {
            val r = ShellSettings.apply(p)
            shellMsg = if (r.isNotEmpty()) "Lệnh hệ thống:\n$r" else ""
        }

        featureLines = if (sb.isEmpty()) "(chưa bật tính năng nào)\n" else sb.toString()
    }

    private fun teardown() {
        cpuRun = false
        for (t in cpuThreads) t.interrupt()
        cpuThreads.clear()

        sm?.unregisterListener(this)
        sm = null
        sensorThread?.quitSafely()
        sensorThread = null
        activeTypes.clear()
        java.util.Arrays.fill(counts, 0)

        wl?.let { if (it.isHeld) it.release() }
        wl = null

        overlay?.let {
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)
            } catch (e: Exception) {
                // bỏ qua
            }
        }
        overlay = null
    }

    private fun typeName(t: Int) = when (t) {
        Sensor.TYPE_ACCELEROMETER -> "ACC"
        Sensor.TYPE_GYROSCOPE -> "GYR"
        Sensor.TYPE_MAGNETIC_FIELD -> "MAG"
        Sensor.TYPE_ROTATION_VECTOR -> "ROT"
        Sensor.TYPE_GRAVITY -> "GRA"
        Sensor.TYPE_LINEAR_ACCELERATION -> "LIN"
        else -> "S$t"
    }

    private fun publish() {
        val hz = StringBuilder()
        for (t in activeTypes) {
            hz.append(typeName(t)).append(' ').append(counts[t]).append("Hz  ")
            counts[t] = 0
        }
        status = "Dịch vụ: ĐANG CHẠY\n" + featureLines +
            (if (hz.isNotEmpty()) "Tần số thực: $hz\n" else "") + shellMsg
    }

    override fun onSensorChanged(event: SensorEvent) {
        val t = event.sensor.type
        if (t < counts.size) counts[t]++
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
