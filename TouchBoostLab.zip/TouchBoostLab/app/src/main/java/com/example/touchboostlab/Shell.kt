package com.example.touchboostlab

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Chạy lệnh shell qua Shizuku (dùng reflection vì newProcess là private ở API 13). */
object Shell {
    fun available(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun run(cmd: String): String {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val proc = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = proc.inputStream.bufferedReader().readText().trim()
            proc.waitFor()
            out
        } catch (e: Throwable) {
            "ERR: " + (e.cause?.message ?: e.message)
        }
    }
}

/** Các thông số hệ thống thay đổi qua Shizuku; luôn lưu giá trị gốc để khôi phục. */
object ShellSettings {
    private val ANIM_KEYS = listOf(
        "window_animation_scale",
        "transition_animation_scale",
        "animator_duration_scale"
    )

    fun anyEnabled(p: Prefs) = p.b(K.PTR) || p.b(K.ANIM) || p.b(K.LONGP)

    fun apply(p: Prefs): String {
        if (!Shell.available()) {
            return if (anyEnabled(p)) "Shizuku: CHƯA sẵn sàng (hãy chạy Shizuku và cấp quyền)\n" else ""
        }
        val log = StringBuilder()
        toggle(p, "system", "pointer_speed", p.b(K.PTR), (p.i(K.PTRV, 7) - 7).toString(), log)
        val scale = (p.i(K.ANIMV, 10) / 10.0).toString()
        for (k in ANIM_KEYS) toggle(p, "global", k, p.b(K.ANIM), scale, log)
        toggle(p, "secure", "long_press_timeout", p.b(K.LONGP), (100 + p.i(K.LPV, 30) * 10).toString(), log)
        return log.toString()
    }

    fun restoreAll(p: Prefs) {
        if (!Shell.available()) return
        restore(p, "system", "pointer_speed")
        for (k in ANIM_KEYS) restore(p, "global", k)
        restore(p, "secure", "long_press_timeout")
    }

    private fun toggle(p: Prefs, ns: String, key: String, on: Boolean, value: String, log: StringBuilder) {
        if (on) {
            saveOrig(p, ns, key)
            val r = Shell.run("settings put $ns $key $value")
            log.append("$ns $key=$value ").append(if (r.startsWith("ERR")) r else "OK").append('\n')
        } else {
            restore(p, ns, key)
        }
    }

    private fun saveOrig(p: Prefs, ns: String, key: String) {
        val k = "orig_${ns}_$key"
        if (!p.sp.contains(k)) {
            p.sp.edit().putString(k, Shell.run("settings get $ns $key")).apply()
        }
    }

    private fun restore(p: Prefs, ns: String, key: String) {
        val k = "orig_${ns}_$key"
        val v = p.sp.getString(k, null) ?: return
        if (v.isEmpty() || v == "null" || v.startsWith("ERR")) {
            Shell.run("settings delete $ns $key")
        } else {
            Shell.run("settings put $ns $key $v")
        }
        p.sp.edit().remove(k).apply()
    }
}
