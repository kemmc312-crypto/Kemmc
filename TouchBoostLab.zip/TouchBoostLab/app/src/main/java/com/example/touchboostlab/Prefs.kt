package com.example.touchboostlab

import android.content.Context
import android.content.SharedPreferences

/** Khoá cấu hình. */
object K {
    const val WAKE = "wake"

    const val SENS = "sens"
    const val S_ACC = "s_acc"
    const val S_GYR = "s_gyr"
    const val S_MAG = "s_mag"
    const val S_ROT = "s_rot"
    const val S_GRA = "s_gra"
    const val S_LIN = "s_lin"
    const val DELAY = "delay"      // x500 micro giây, 0 = FASTEST
    const val PRIO = "prio"        // 0..8 -> nice âm

    const val CPU = "cpu"
    const val DUTY = "duty"        // % thời gian bận, 1..50
    const val THREADS = "threads"  // 1..4

    const val OVERLAY = "overlay"

    const val PTR = "ptr"
    const val PTRV = "ptrv"        // 0..14 -> -7..7
    const val ANIM = "anim"
    const val ANIMV = "animv"      // 0..10 -> 0.0..1.0
    const val LONGP = "longp"
    const val LPV = "lpv"          // 0..40 -> 100..500 ms
}

class Prefs(ctx: Context) {
    val sp: SharedPreferences = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun b(key: String, def: Boolean = false): Boolean = sp.getBoolean(key, def)
    fun setB(key: String, v: Boolean) = sp.edit().putBoolean(key, v).apply()
    fun i(key: String, def: Int): Int = sp.getInt(key, def)
    fun setI(key: String, v: Int) = sp.edit().putInt(key, v).apply()
}
