# TouchBoostLab

App thử nghiệm để tìm xem thứ gì làm vuốt nhạy hơn. Mỗi tính năng có công tắc và thông số riêng.

## Quyền
App xin 3 quyền (giống màn hình quyền của SwiftSense): **Thông báo**, **Bỏ tối ưu hoá pin**, **Hiển thị trên ứng dụng khác**.
Shizuku là tuỳ chọn, chỉ cần cho mục 5 (lệnh hệ thống).

## Build bằng GitHub Actions (không cần máy tính)
1. Tạo repo GitHub mới, upload toàn bộ nội dung đã giải nén.
2. Nếu thư mục `.github` không được upload: bấm **Add file → Create new file**, gõ tên `.github/workflows/build.yml`, dán nội dung từ file `build-workflow.yml`.
3. Vào tab **Actions → Build APK → Run workflow**.
4. Chạy xong, mở lần chạy đó, tải **TouchBoostLab-debug** ở mục Artifacts, giải nén ra `app-debug.apk` rồi cài.
5. Nếu build lỗi, mở log của bước "Build debug APK" và gửi dòng lỗi.

## Cách test (A/B)
Chỉ bật MỘT thứ mỗi lần, bấm "Áp dụng & chạy", sang app khác (Chrome, Facebook...) vuốt thử, rồi ghi lại.
1. Không bật gì (mốc so sánh).
2. Chỉ Wake lock.
3. Chỉ Cảm biến (delay 0, ưu tiên -4). Xem dòng "Tần số thực" trong app để biết cảm biến chạy bao nhiêu Hz.
4. Chỉ Tải CPU nền (mức bận 10%).
5. Chỉ Overlay 1×1.
6. Từng lệnh hệ thống: pointer_speed, animation, long_press.
Thứ nào làm nhạy rõ thì thử tăng/giảm thông số của nó.

## Lưu ý
- Tải CPU nền và Wake lock tốn pin; nhớ bấm Dừng sau khi test.
- Mục 5 đổi cài đặt hệ thống; bấm Dừng sẽ trả về giá trị gốc. Nếu bị kẹt, dùng nút "Khôi phục cài đặt hệ thống".
- Mã nguồn tự viết bằng API công khai của Android, không chứa code của SwiftSense hay SpeedX.
