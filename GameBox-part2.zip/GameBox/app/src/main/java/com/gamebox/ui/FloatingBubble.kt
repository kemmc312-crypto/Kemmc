package com.gamebox.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * Nút tròn nổi (kiểu VMOS) hiện khi toàn màn hình. Kéo để di chuyển, chạm để mở menu.
 * Lớp phủ không chặn cảm ứng: chỉ nút tròn và menu nhận chạm, còn lại xuống game.
 */
@Composable
fun FloatingBubble(
    stretch: Boolean,
    onExitFullscreen: () -> Unit,
    onToggleStretch: () -> Unit,
    onRotate: () -> Unit,
    onSettings: () -> Unit,
    onHome: () -> Unit,
) {
    val sizePx = with(LocalDensity.current) { 44.dp.toPx() }
    var x by remember { mutableFloatStateOf(24f) }
    var y by remember { mutableFloatStateOf(96f) }
    var open by remember { mutableStateOf(false) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val maxX = (constraints.maxWidth - sizePx).coerceAtLeast(0f)
        val maxY = (constraints.maxHeight - sizePx).coerceAtLeast(0f)
        val menuOnLeft = x > maxX / 2

        Row(
            Modifier.offset { IntOffset(x.roundToInt(), y.roundToInt()) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (open && menuOnLeft) Menu(stretch, onExitFullscreen, onToggleStretch, onRotate, onSettings, onHome) { open = false }
            Box(
                Modifier.size(44.dp).alpha(if (open) 1f else 0.55f)
                    .clip(CircleShape).background(Color(0xFF2B2B2B))
                    .pointerInput(Unit) { detectTapGestures(onTap = { open = !open }) }
                    .pointerInput(maxX, maxY) {
                        detectDragGestures { change, d ->
                            change.consume()
                            x = (x + d.x).coerceIn(0f, maxX)
                            y = (y + d.y).coerceIn(0f, maxY)
                        }
                    },
                contentAlignment = Alignment.Center
            ) { Text("🎮", fontSize = 20.sp) }
            if (open && !menuOnLeft) Menu(stretch, onExitFullscreen, onToggleStretch, onRotate, onSettings, onHome) { open = false }
        }
    }
}

@Composable
private fun Menu(
    stretch: Boolean,
    onExit: () -> Unit, onStretch: () -> Unit, onRotate: () -> Unit, onSettings: () -> Unit, onHome: () -> Unit,
    close: () -> Unit,
) {
    Row(
        Modifier.padding(horizontal = 6.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xE6202020)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Item("Thoát full") { close(); onExit() }
        Item(if (stretch) "Kéo dãn ✓" else "Giữ tỉ lệ") { onStretch() }
        Item("⟳") { onRotate() }
        Item("⚙") { close(); onSettings() }
        Item("≡") { close(); onHome() }
    }
}

@Composable
private fun Item(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick) { Text(label, color = Color.White, fontSize = 12.sp, maxLines = 1) }
}
