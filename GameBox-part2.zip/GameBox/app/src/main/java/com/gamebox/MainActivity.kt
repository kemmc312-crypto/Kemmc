package com.gamebox

import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.Modifier
import com.gamebox.display.DisplayClient
import com.gamebox.game.TabManager
import com.gamebox.shizuku.ShizukuManager
import com.gamebox.ui.MainScreen
import com.gamebox.ui.MainViewModel

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MainScreen(vm)
                }
            }
        }
    }

    /** Bàn phím vật lý: khi đang xem tab game thì chuyển phím vào display ảo (trừ phím hệ thống). */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val did = TabManager.activeDisplayId()
        if (did != null && event.keyCode !in SYSTEM_KEYS) {
            DisplayClient.injectKey(event, did)
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private companion object {
        val SYSTEM_KEYS = setOf(
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_HOME, KeyEvent.KEYCODE_APP_SWITCH, KeyEvent.KEYCODE_POWER,
            KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_VOLUME_MUTE
        )
    }

    override fun onResume() {
        super.onResume()
        ShizukuManager.refresh()
        TabManager.onForeground()
    }

    override fun onStop() {
        super.onStop()
        TabManager.onBackground() // trả lại Hz mặc định khi rời app
    }
}
