package com.gamebox.game

import android.content.Context
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min

/** dpi = 0 -> tự động. lockRatio: chiều cao tự tính theo tỉ lệ màn hình thật. */
data class TabConfig(
    val width: Int = 1280,
    val height: Int = 576,
    val dpi: Int = 0,
    val landscape: Boolean = true,
    val lockRatio: Boolean = true,
    val hz: Int = 60,
) {
    val effDpi get() = if (dpi > 0) dpi else (min(width, height) * 4 / 9).coerceAtLeast(120)
}

data class GameTab(
    val id: Int,
    val pkg: String,
    val label: String,
    val cfg: TabConfig,
    val displayId: Int = -1,
    val running: Boolean = false,
    /** true = người dùng tự xoay bằng nút ⟳ -> tắt tự nhận hướng game */
    val manual: Boolean = false,
)

/** cạnh dài / cạnh ngắn của màn hình thật */
@Suppress("DEPRECATION")
fun screenRatio(ctx: Context): Float {
    val m = DisplayMetrics()
    ctx.getSystemService(WindowManager::class.java).defaultDisplay.getRealMetrics(m)
    return max(m.widthPixels, m.heightPixels).toFloat() / min(m.widthPixels, m.heightPixels)
}

/** width = cạnh ngang. Ngang: h = w / ratio. Dọc: h = w * ratio. Làm tròn xuống số chẵn. */
fun lockedHeight(w: Int, landscape: Boolean, ratio: Float): Int =
    ((if (landscape) w / ratio else w * ratio).toInt() / 2) * 2
