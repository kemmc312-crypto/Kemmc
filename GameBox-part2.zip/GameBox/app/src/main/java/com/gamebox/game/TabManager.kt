package com.gamebox.game

import android.content.Context
import com.gamebox.display.DisplayClient
import com.gamebox.shizuku.ShizukuManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Giữ danh sách tab game (mỗi tab = 1 display ảo + 1 game). Sống theo process. */
object TabManager {
    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _tabs = MutableStateFlow<List<GameTab>>(emptyList())
    val tabs: StateFlow<List<GameTab>> = _tabs.asStateFlow()

    /** null = tab "Thêm game" (trang chủ) */
    private val _active = MutableStateFlow<Int?>(null)
    val active: StateFlow<Int?> = _active.asStateFlow()

    /** Toàn màn hình: ẩn thanh tab, game kéo dãn phủ kín màn hình */
    val fullscreen = MutableStateFlow(false)
    /** true = kéo dãn cho đầy màn hình (hơi méo), false = giữ đúng tỉ lệ (có viền đen) */
    val stretch = MutableStateFlow(true)

    /** displayId của tab đang xem nếu đang chạy, ngược lại null (dùng để chuyển phím vào game) */
    fun activeDisplayId(): Int? {
        val t = _active.value?.let { tab(it) } ?: return null
        return if (t.running && t.displayId >= 0) t.displayId else null
    }

    val status = MutableStateFlow("")
    private var statusJob: Job? = null
    private var nextId = 1

    fun init(c: Context) { app = c.applicationContext }

    private fun say(s: String) { status.value = s }
    fun clearStatus() { status.value = "" }
    fun post(s: String) = say(s)

    private fun tab(id: Int) = _tabs.value.firstOrNull { it.id == id }
    private fun mutate(id: Int, f: (GameTab) -> GameTab) {
        _tabs.value = _tabs.value.map { if (it.id == id) f(it) else it }
    }

    fun addAndStart(a: AppInfo, cfg: TabConfig) {
        val t = GameTab(nextId++, a.pkg, a.label, cfg)
        _tabs.value = _tabs.value + t
        start(t.id)
    }

    fun start(id: Int) {
        scope.launch {
            val t = tab(id) ?: return@launch
            if (t.running) { select(id); return@launch }
            if (!DisplayClient.connected.value) { say("Dịch vụ display chưa kết nối — kiểm tra Shizuku"); return@launch }
            say("Tạo display ${t.cfg.width}×${t.cfg.height}…")
            val did = withContext(Dispatchers.IO) {
                DisplayClient.createDisplay("GameBox-${t.id}", t.cfg.width, t.cfg.height, t.cfg.effDpi)
            }
            val info = withContext(Dispatchers.IO) { DisplayClient.lastError() }
            if (did < 0) { say("Lỗi tạo display:\n$info"); return@launch }
            mutate(id) { it.copy(displayId = did, running = true) }
            select(id) // hiện SurfaceView, gắn surface vào display
            val (ok, out) = GameLauncher.launch(app, t.pkg, did)
            if (!ok) { say("am start lỗi: ${out.take(200)}"); return@launch }
            delay(3000)
            val d = GameLauncher.displayOf(t.pkg)
            if (d != null && d != did) {
                // Android chặn -> game rơi ra màn hình thật: tắt luôn, không để game chạy ngoài app
                GameLauncher.stop(t.pkg)
                say("⚠ Android chặn: game bị mở ở display $d (màn hình thật) nên đã tắt.\ndisplay $did tạo bằng: $info")
                return@launch
            }
            say(
                when {
                    d == null -> "Không thấy game đang chạy · $info"
                    d == did -> "Game chạy trong display $did ✓ · $info"
                    else -> "⚠ Game nằm ở display $d, không phải $did · $info"
                }
            )
            watchers.remove(id)?.cancel()
            watchers[id] = scope.launch { watchOrient(id) }
        }
    }

    // ---- Hướng: display luôn khớp hướng game (không dải đen, chạm 1:1) ----
    private val watchers = HashMap<Int, Job>()

    private suspend fun watchOrient(id: Int) {
        var last: Boolean? = null
        while (true) {
            delay(2000)
            val t = tab(id) ?: return
            if (!t.running) return
            if (t.manual) continue
            val l = GameLauncher.isLandscape(t.pkg)
            if (l != null && l != t.cfg.landscape && l == last) setOrientation(id, l) // 2 lần liên tiếp mới đổi
            last = l
        }
    }

    private suspend fun setOrientation(id: Int, land: Boolean) {
        val t = tab(id) ?: return
        if (t.cfg.landscape == land) return
        val c = t.cfg.copy(width = t.cfg.height, height = t.cfg.width, landscape = land)
        withContext(Dispatchers.IO) { DisplayClient.resize(t.displayId, c.width, c.height, c.effDpi) }
        mutate(id) { it.copy(cfg = c) }
    }

    fun rotate(id: Int) {
        scope.launch {
            val t = tab(id) ?: return@launch
            mutate(id) { it.copy(manual = true) }
            setOrientation(id, !t.cfg.landscape)
        }
    }

    private var diag = 0
    /** Gọi khi nhấc tay: 2 lần đầu hiện kết quả inject để chẩn đoán cảm ứng. */
    fun touchDiag() {
        if (diag++ >= 2) return
        scope.launch {
            delay(300)
            say("Chạm: " + withContext(Dispatchers.IO) { DisplayClient.injectStatus() })
        }
    }

    fun select(id: Int?) {
        _active.value = id
        if (id == null) fullscreen.value = false
        scope.launch {
            val t = id?.let { tab(it) }
            if (t != null && t.running) applyHz(t.cfg.hz) else restoreHz()
        }
    }

    fun close(id: Int) {
        scope.launch {
            val t = tab(id) ?: return@launch
            watchers.remove(id)?.cancel()
            GameLauncher.stop(t.pkg)
            if (t.displayId >= 0) withContext(Dispatchers.IO) { DisplayClient.release(t.displayId) }
            _tabs.value = _tabs.value.filter { it.id != id }
            if (_active.value == id) select(null)
        }
    }

    /** Đổi độ phân giải/DPI/Hz: dừng game, tạo lại display rồi chạy lại. */
    fun reconfigure(id: Int, cfg: TabConfig) {
        scope.launch {
            val t = tab(id) ?: return@launch
            if (t.running) {
                GameLauncher.stop(t.pkg)
                withContext(Dispatchers.IO) { DisplayClient.release(t.displayId) }
            }
            mutate(id) { it.copy(cfg = cfg, running = false, displayId = -1) }
            start(id)
        }
    }

    fun onServiceLost() {
        _tabs.value = _tabs.value.map { it.copy(running = false, displayId = -1) }
    }

    // ---- Hz (best effort): đổi tần số quét thật của màn hình khi đang xem tab ----
    private val hzKeys = listOf("peak_refresh_rate", "min_refresh_rate")
    private var savedHz: Map<String, String>? = null

    private suspend fun applyHz(hz: Int) {
        if (savedHz == null) savedHz = hzKeys.associateWith { ShizukuManager.sh("settings get system $it").second.trim() }
        hzKeys.forEach { ShizukuManager.sh("settings put system $it $hz.0") }
    }

    private suspend fun restoreHz() {
        val s = savedHz ?: return
        s.forEach { (k, v) ->
            ShizukuManager.sh(if (v.isBlank() || v == "null") "settings delete system $k" else "settings put system $k $v")
        }
        savedHz = null
    }

    fun onBackground() { scope.launch { restoreHz() } }
    fun onForeground() {
        scope.launch {
            val t = _active.value?.let { tab(it) }
            if (t != null && t.running) applyHz(t.cfg.hz)
        }
    }
}
